#!/bin/sh
echo "Post command: Ident: $1  Filename: $2" >&2
