/**
 ** @file yafMeta2Pcap
 *
 * This program takes the pcap meta file created by YAF
 * and a flow key hash and start time and creates the pcap file
 * for the flow.
 * Use the getFlowKeyHash program to calculate the flow key hash.
 *
 ** ------------------------------------------------------------------------
 ** Copyright (C) 2006-2014 Carnegie Mellon University.
 ** All Rights Reserved.
 **
 ** ------------------------------------------------------------------------
 ** Author: Emily Sarneso
 ** ------------------------------------------------------------------------
 ** @OPENSOURCE_HEADER_START@
 ** Use of the YAF system and related source code is subject to the terms
 ** of the following licenses:
 **
 ** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
 ** Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 **
 ** NO WARRANTY
 **
 ** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
 ** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
 ** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
 ** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
 ** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
 ** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
 ** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
 ** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
 ** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
 ** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
 ** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
 ** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
 ** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
 ** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
 ** DELIVERABLES UNDER THIS LICENSE.
 **
 ** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
 ** Mellon University, its trustees, officers, employees, and agents from
 ** all claims or demands made against them (and any related losses,
 ** expenses, or attorney's fees) arising out of, or relating to Licensee's
 ** and/or its sub licensees' negligent use or willful misuse of or
 ** negligent conduct or willful misconduct regarding the Software,
 ** facilities, or other rights or assistance granted by Carnegie Mellon
 ** University under this License, including, but not limited to, any
 ** claims of product liability, personal injury, death, damage to
 ** property, or violation of any laws or regulations.
 **
 ** Carnegie Mellon University Software Engineering Institute authored
 ** documents are sponsored by the U.S. Department of Defense under
 ** Contract FA8721-05-C-0003. Carnegie Mellon University retains
 ** copyrights in all material produced under this contract. The U.S.
 ** Government retains a non-exclusive, royalty-free license to publish or
 ** reproduce these documents, or allow others to do so, for U.S.
 ** Government purposes only pursuant to the copyright license under the
 ** contract clause at 252.227.7013.
 **
 ** @OPENSOURCE_HEADER_END@
 ** ------------------------------------------------------------------------
 */


#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <libgen.h>
#include <glib.h>
#include <string.h>
#include <pcap.h>

#define MAX_LINE 4096

static char ** meta_file = NULL;
static char * out_file = NULL;
static char * flowkeyhash = NULL;
static char * flowstarttime = NULL;
static char ** pcap = NULL;
static gboolean yaf_out = FALSE;
static char * caplist = NULL;
static char * metalist = NULL;
static gboolean list = FALSE;
static gboolean verbose = FALSE;

static GOptionEntry md_core_option[] = {
    {"pcap-meta-file", 'f', 0, G_OPTION_ARG_FILENAME_ARRAY, &meta_file,
     "Pcap meta file created by YAF. Required. \n\t\t\t\tThis option may be"
     " listed more than once.", "file" },
    {"pcap", 'p', 0, G_OPTION_ARG_FILENAME_ARRAY, &pcap,
     "Pcap file to read if full path is not specified "
     "\n\t\t\t\tin pcap_meta_file. This option may be "
     "\n\t\t\t\tlisted more than once.", "file" },
    {"caplist", 'c', 0, G_OPTION_ARG_STRING, &caplist,
     "Ordered List of pcap files [--caplist] given to "
     "\n\t\t\t\tyaf with full paths to pcaps.", "file" },
    {"metalist", 'm', 0, G_OPTION_ARG_STRING, &metalist,
     "Ordered List of meta files created by yaf "
     "\n\t\t\t\twith full paths to files.", "file"},
    {"out", 'o', 0, G_OPTION_ARG_STRING, &out_file,
     "Pcap output file.", "file" },
    {"hash", 'h', 0, G_OPTION_ARG_STRING, &flowkeyhash,
     "Flow Key Hash. Required.", "hash" },
    {"time", 't', 0, G_OPTION_ARG_STRING, &flowstarttime,
     "Time in milliseconds. Suggested, but not required.", "ms" },
    {"full-path", 'y', 0, G_OPTION_ARG_NONE, &yaf_out,
     "Use if format of pcap_meta_file has full path "
     "\n\t\t\t\tname to file", NULL },
    {"list-files", 'l', 0, G_OPTION_ARG_NONE, &list,
     "List the pcap files that contain the flow with "
     "\n\t\t\t\tthe given hash, start time, and meta file(s)", NULL },
    {"verbose", 'v', 0, G_OPTION_ARG_NONE, &verbose,
     "Print debug information to stdout.", NULL },
    { NULL }
};



static void yfPcapWrite(
    pcap_dumper_t *file,
    const struct pcap_pkthdr *hdr,
    const uint8_t *pkt)
{
    pcap_dump((u_char *)file, hdr, pkt);
}

/**
 * main
 *
 */
int
main (int argc, char *argv[]) {

    GOptionContext *ctx = NULL;
    GError *err = NULL;
    uint64_t start = 0;
    uint32_t key_hash = 0;
    FILE *fp = NULL;
    int pcap_files_num = 0;
    int meta_files_num = 0;
    int caplist_num = 0;
    char line[MAX_LINE];
    char old_file_path[500];
    char *capfiles[MAX_LINE];
    unsigned long long int offset;
    unsigned long long int rstart;
    uint32_t rhash;
    gboolean do_once = TRUE;
    int file, pfile, i;
    int counter = 0;
    pcap_t *pcap_in = NULL;
    static char pcap_errbuf[PCAP_ERRBUF_SIZE];
    pcap_dumper_t *dump = NULL;
    int rv;

    ctx = g_option_context_new(" - yafMeta2Pcap Options");

    g_option_context_add_main_entries(ctx, md_core_option, NULL);

    g_option_context_set_help_enabled(ctx, TRUE);

    if (!g_option_context_parse(ctx, &argc, &argv, &err)) {
        fprintf(stderr, "option parsing failed: %s\n", err->message);
        exit(-1);
    }

    /*    if (flowstarttime == NULL) {
        fprintf(stderr, "Error: --time is required.\n");
        fprintf(stderr, "Use --help for usage.\n");
        exit(-1);
        }*/

    if (flowkeyhash == NULL) {
        fprintf(stderr, "Error: --hash is required\n");
        fprintf(stderr, "Use --help for usage.\n");
        exit(-1);
    }

    if (meta_file == NULL && metalist == NULL) {
        fprintf(stderr,"Error: --pcap-meta-file or --metalist  is required\n");
        fprintf(stderr, "Use --help for usage.\n");
        exit(-1);
    }

    if (!list) {

        if (pcap == NULL && !yaf_out) {
            if (!caplist) {
                fprintf(stderr, "Error: --pcap, --caplist, or --list-files "
                        "is required, unless pcap-meta-file contains "
                        "full path (use -y)\n");
                fprintf(stderr, "Use --help for usage.\n");
                exit(-1);
            }
        }

        if (yaf_out && pcap) {
            fprintf(stderr, "Warning: Ignoring option --pcap\n");
            pcap = NULL;
        }

        if (out_file == NULL) {
            fprintf(stderr, "Error: --out is required\n");
            fprintf(stderr, "Use --help for usage.\n");
            exit(-1);
        }
    } else {
        if (pcap) {
            if (verbose) {
                fprintf(stderr, "Warning: Ignoring --pcap\n");
            }
            pcap = NULL;
        }
        if (caplist) {
            if (verbose) {
                fprintf(stderr, "Warning: Ignoring --caplist\n");
            }
            caplist = NULL;
        }
        if (out_file) {
            if (verbose) {
                fprintf(stderr, "Warning: Ignoring --out\n");
            }
            out_file = NULL;
        }
        if (yaf_out) {
            if (verbose) {
                fprintf(stderr, "warning: Ignoring --full-path\n");
            }
            yaf_out = FALSE;
        }
    }

    if (flowstarttime) {
        start = strtoull(flowstarttime, NULL, 10);
    } else {
        start = 0;
    }

    key_hash = strtoul(flowkeyhash, NULL, 10);

    if (verbose) {
        fprintf(stdout, "Looking for hash: %u at start time: %llu\n",
                key_hash, (long long unsigned int)start);
    }

    if (metalist) {
        /* read list of meta files */
        fp = fopen(metalist, "r");
        if (fp == NULL) {
            fprintf(stderr, "Can't open metalist file %s\n", metalist);
            exit(-1);
        }
        meta_file = (char **)calloc(MAX_LINE, sizeof(char *));
        while (fgets(line, MAX_LINE, fp) && meta_files_num < MAX_LINE) {
            meta_file[meta_files_num] = (char *)calloc(1, MAX_LINE);
            strncpy(meta_file[meta_files_num], line, strlen(line)-1);
            meta_files_num++;
        }
        fclose(fp);
        fp = NULL;
    } else {
        while (meta_file[meta_files_num]) {
            meta_files_num++;
        }
    }

    if (caplist) {
        /* read list of capture files */
        fp = fopen(caplist, "r");
        if (fp == NULL) {
            fprintf(stderr, "Can't open caplist file %s\n", caplist);
            exit(-1);
        }

        while (fgets(line, MAX_LINE, fp)) {
            capfiles[caplist_num] = (char *)calloc(1, MAX_LINE);
            strncpy(capfiles[caplist_num], line, (strlen(line)-1));
            caplist_num++;
        }
        fclose(fp);
        fp = NULL;
    } else {
        if (!yaf_out && !list) {
            while (pcap[pcap_files_num]) {
                pcap_files_num++;
            }
        }
    }

    pfile = -1;

    for (i = 0; i < meta_files_num; i++) {

        if (fp) {
            fclose(fp);
        }

        if (verbose) {
            fprintf(stdout, "Opening PCAP Meta File: %s\n", meta_file[i]);
        }

        fp = fopen(meta_file[i], "r");
        if (fp == NULL) {
            fprintf(stderr, "Can't open PCAP Meta file %s\n", meta_file[i]);
            exit(-1);
        }

        while (fgets(line, MAX_LINE, fp)) {

            /* output has full path: meta file should look like:
               hash|stime|path_to_pcap|offset|length */
            if (yaf_out) {

                gchar **tok = NULL;
                tok = g_strsplit(line, "|", -1);
                rhash = strtoul(tok[0], NULL, 10);
                rstart = strtoull(tok[1], NULL, 10);
                if (tok[3]) {
                    offset = strtoull(tok[3], NULL, 10);
                } else {
                    fprintf(stderr, "Error: Invalid Pcap Meta File Format.\n");
                    fprintf(stderr, "Expecting: hash|stime|file_name|offset|length\n");
                    exit(-1);
                }

                if (rhash != key_hash) continue;
                if (start) {
                    if (start != rstart) continue;
                }

                if (strcmp(tok[2], old_file_path)) {
                    if (verbose) {
                        fprintf(stdout, "Now reading PCAP file: %s\n", tok[2]);
                    }

                    if (pcap_in) {
                        pcap_close(pcap_in);
                    }

                    strcpy(old_file_path, tok[2]);
                    pcap_in = pcap_open_offline(tok[2], pcap_errbuf);

                    if (!pcap_in) {
                        fprintf(stderr, "Could not open PCAP file %s: %s\n",
                                tok[2], pcap_errbuf);
                        exit(-1);
                    }

                    if (do_once) {
                        if (verbose) {
                            fprintf(stdout, "Opening output file %s\n",
                                    out_file);
                        }
                        dump = pcap_dump_open(pcap_in, out_file);

                        if (dump == NULL) {
                            fprintf(stderr,
                                    "Could not open output file: %s\n",
                                    pcap_geterr(pcap_in));
                            exit(-1);
                        }

                        do_once = FALSE;
                    }
                }
                g_strfreev(tok);

            } else if (list) {
                /* output of meta_file should look like:
                   hash|stime|pcap_file */

                sscanf(line, "%u|%llu|%s", &rhash, &rstart, old_file_path);

                if (rhash != key_hash) continue;
                if (start) {
                    if (start != rstart) continue;
                }

                fprintf(stdout, "%s\n", old_file_path);
                continue;

            } else {
                /* output of meta file should look like:
                   hash|stime|file_no|offset|length */

                sscanf(line, "%u|%llu|%d|%llu|", &rhash, &rstart, &file,
                       &offset);

                if (rhash != key_hash) continue;
                if (start) {
                    if (start != rstart) continue;
                }

                if (offset == 0) {
                    fprintf(stderr, "Error: Invalid Pcap Meta File Format.\n");
                    fprintf(stderr, "Expecting: hash|stime|file_number|offset|length\n");
                    exit(-1);
                }

                if (caplist_num) {

                    if (file != pfile && (file < caplist_num)) {

                        if (pcap_in) {
                            pcap_close(pcap_in);
                        }
                        if (verbose) {
                            fprintf(stdout, "Opening PCAP File: %s\n",
                                    capfiles[file]);
                        }
                        pcap_in = pcap_open_offline(capfiles[file],
                                                    pcap_errbuf);
                        if (!pcap_in) {
                            fprintf(stderr,
                                    "could not open PCAP file %s: %s\n",
                                    capfiles[file], pcap_errbuf);
                            exit(-1);
                        }

                        if (do_once) {
                            if (verbose) {
                                fprintf(stdout, "Opening output file %s\n",
                                        out_file);
                            }
                            dump = pcap_dump_open(pcap_in, out_file);

                            if (dump == NULL) {
                                fprintf(stderr,
                                        "Could not open output file: %s\n",
                                        pcap_geterr(pcap_in));
                                exit(-1);
                            }

                            do_once = FALSE;
                        }

                        pfile = file;
                    }
                } else {
                    if (file != pfile && (file < pcap_files_num)) {

                        if (pcap_in) {
                            pcap_close(pcap_in);
                        }

                        if (verbose) {
                            fprintf(stdout, "Opening PCAP File %s\n",
                                    pcap[file]);
                        }

                        pcap_in = pcap_open_offline(pcap[file], pcap_errbuf);
                        if (!pcap_in) {
                            fprintf(stderr,"could not open PCAP file %s: %s\n",
                                    pcap[file], pcap_errbuf);
                            exit(-1);
                        }

                        if (do_once) {
                            if (verbose) {
                                fprintf(stdout, "Opening output file %s\n",
                                        out_file);
                            }
                            dump = pcap_dump_open(pcap_in, out_file);

                            if (dump == NULL) {
                                fprintf(stderr,
                                        "Could not open output file: %s\n",
                                        pcap_geterr(pcap_in));
                                exit(-1);
                            }

                            do_once = FALSE;
                        }


                        pfile = file;
                    }
                }
            }

            counter++;
            fseek(pcap_file(pcap_in), offset, SEEK_SET);

            rv = pcap_dispatch(pcap_in, 1, (pcap_handler)yfPcapWrite,
                               (void *)dump);
            if (rv <= 0) {

                fprintf(stderr, "RV %d Error writing packet: %s\n",
                        rv, pcap_geterr(pcap_in));
                break;
            }
        }
    }


    if (!list) {

        fprintf(stdout, "Found %d packets that match criteria.\n", counter);

        if (fp) {
            fclose(fp);
        }

        if (dump) {
            pcap_dump_flush(dump);
            pcap_dump_close(dump);
        }

        if (pcap_in) {
            pcap_close(pcap_in);
        }
    }

    if (caplist_num) {
        for (i = 0; i < caplist_num; i++) {
            free(capfiles[i]);
        }
    }

    if (metalist) {
        for (i = 0; i < meta_files_num; i++) {
            free(meta_file[i]);
        }
    }

    g_option_context_free(ctx);

    return 0;
}
