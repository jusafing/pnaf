/**
 ** @file yaf_silk_mysql_mediator.c
 * *
 * This program reads from an IPFIX file or listens for connections
 * from YAF on a given port.  It will parse flow data and make inserts
 * into a MySQL Database as long as tables have been created (use yafMySQL.c).
 * After it inserts all flow data into MySQL database, it will export
 * a SiLK flow Record to SiLK on the given export port/host.
 *
 *
 * @Author: Emily Sarneso <netsa-help@cert.org>
 * @Date: 9.17.12 Updated
 *
 ** @OPENSOURCE_HEADER_START@
 ** Use of the YAF system and related source code is subject to the terms
 ** of the following licenses:
 **
 ** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
 ** Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 **
 ** NO WARRANTY
 **
 ** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
 ** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
 ** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
 ** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
 ** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
 ** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
 ** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
 ** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
 ** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
 ** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
 ** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
 ** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
 ** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
 ** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
 ** DELIVERABLES UNDER THIS LICENSE.
 **
 ** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
 ** Mellon University, its trustees, officers, employees, and agents from
 ** all claims or demands made against them (and any related losses,
 ** expenses, or attorney's fees) arising out of, or relating to Licensee's
 ** and/or its sub licensees' negligent use or willful misuse of or
 ** negligent conduct or willful misconduct regarding the Software,
 ** facilities, or other rights or assistance granted by Carnegie Mellon
 ** University under this License, including, but not limited to, any
 ** claims of product liability, personal injury, death, damage to
 ** property, or violation of any laws or regulations.
 **
 ** Carnegie Mellon University Software Engineering Institute authored
 ** documents are sponsored by the U.S. Department of Defense under
 ** Contract FA8721-05-C-0003. Carnegie Mellon University retains
 ** copyrights in all material produced under this contract. The U.S.
 ** Government retains a non-exclusive, royalty-free license to publish or
 ** reproduce these documents, or allow others to do so, for U.S.
 ** Government purposes only pursuant to the copyright license under the
 ** contract clause at 252.227.7013.
 **
 ** @OPENSOURCE_HEADER_END@
 ** ------------------------------------------------------------------------
 */




#include "yafDBInsert.h"
#define STRING_SIZE 150
#define YAF_STATS 0xD000
#define INSERT_FLOW "INSERT INTO flows(srcip4, dstip4, srcport, dstport, "\
    "protocol, vlan, flowStartMilliseconds, flowEndMilliseconds, "\
    "octetTotalCount, reverseOctetTotalCount, packetTotalCount, "\
    "reversePacketTotalCount, silkAppLabel, flowEndReason, ObservationDomain,"\
    "flowAttributes,reverseFlowAttributes, ingressInterface, egressInterface)"\
    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

/* number of ?'s */
#define PARAM_COUNT 19
#define FBSTMLNEXT(a, b) fbSubTemplateMultiListEntryNextDataPtr(a, b)
#define FBSTMLNEXTENTRY(a, b) fbSubTemplateMultiListGetNextEntry(a, b)

static char * md_iport = "18000";
static char * md_eport = "18001";
static char * md_logfile = NULL;
static char * md_ehost = NULL;
static char * md_myhost = NULL;
static char * md_ihost = "localhost";
static char * md_mysql_name = "root";
static char * md_mysql_pass = "";
static char * md_mysql_db = "eflows";
static char * md_inputfile = NULL;
FILE *mdlog = NULL;
FILE *mdinput = NULL;

static GOptionEntry md_core_option[] = {
    {"in-port", 0, 0, G_OPTION_ARG_STRING, &md_iport,
     "Select IPFIX Import port [18000]", "port"},
    {"out-port", 0, 0, G_OPTION_ARG_STRING, &md_eport,
     "Select IPFIX Export port [18001]", "eport"},
    {"out-host", 'o', 0, G_OPTION_ARG_STRING, &md_ehost,
     "Select Hostname/IP to export SiLK Records \n\t\t\t\t to [none]",
     "hostname"},
    {"mysql-host", 'm', 0, G_OPTION_ARG_STRING, &md_myhost,
     "Select Host/IP of MySQL DB [localhost]", "hostname"},
    {"in-host", 'i', 0, G_OPTION_ARG_STRING, &md_ihost,
     "Select Host/I.P. to listen to [localhost]", "host"},
    {"log", 'l', 0, G_OPTION_ARG_STRING, &md_logfile,
     "specify the name of the file to log errors, \n\t\t\t\tmessages, "
     "etc [stdout]", "logfile"},
    {"name", 'n', 0, G_OPTION_ARG_STRING, &md_mysql_name,
     "Specify MySQL user name [root]", "user name"},
    {"pass", 'p', 0, G_OPTION_ARG_STRING, &md_mysql_pass,
     "Specify MySQL password []", "password"},
    {"database", 'd', 0, G_OPTION_ARG_STRING, &md_mysql_db,
     "Name of the database to use to import"
     "\n\t\t\t\t - tables must already exist [eflows]", "database"},
    {"in-file", 'f', 0, G_OPTION_ARG_STRING, &md_inputfile,
     "Specify the Name of the IPFIX \n\t\t\t\t file to read [none]",
     "input file"},
    { NULL }
};



/* YAF default template */
static fbInfoElementSpec_t yaf_flow_spec[] = {
    /* Millisecond start and end (epoch) (native time) */
    { "flowStartMilliseconds",              0, 0 },
    { "flowEndMilliseconds",                0, 0 },
    /* Counters */
    { "octetTotalCount",                    0, 0 },
    { "reverseOctetTotalCount",             0, 0 },
    { "packetTotalCount",                   0, 0 },
    { "reversePacketTotalCount",            0, 0 },
    /* 5-tuple and flow status */
    { "sourceIPv6Address",                  0, 0 },
    { "destinationIPv6Address",             0, 0 },
    { "sourceIPv4Address",                  0, 0 },
    { "destinationIPv4Address",             0, 0 },
    { "sourceTransportPort",                0, 0 },
    { "destinationTransportPort",           0, 0 },
    { "flowAttributes",                     0, 0 },
    { "reverseFlowAttributes",              0, 0 },
    { "protocolIdentifier",                 0, 0 },
    { "flowEndReason",                      0, 0 },
    { "silkAppLabel",                       0, 0 },
    /* Round-trip time */
    { "reverseFlowDeltaMilliseconds",       0, 0 },
    { "tcpSequenceNumber",                  0, 0 },
    { "reverseTcpSequenceNumber",           0, 0 },
    { "initialTCPFlags",                    0, 0 },
    { "unionTCPFlags",                      0, 0 },
    { "reverseInitialTCPFlags",             0, 0 },
    { "reverseUnionTCPFlags",               0, 0 },
    { "vlanId",                             0, 0 },
    { "reverseVlanId",                      0, 0 },
    { "ingressInterface",                   0, 0 },
    { "egressInterface",                    0, 0 },
    { "subTemplateMultiList",               0, 0 },
    FB_IESPEC_NULL
};

static fbInfoElementSpec_t silkTemplate[] = {
    {"flowStartMilliseconds",               0, 0 },
    {"flowEndMilliseconds",                 0, 0 },
    {"octetTotalCount",                     0, 0 },
    {"reverseOctetTotalCount",              0, 0 },
    {"packetTotalCount",                    0, 0 },
    {"reversePacketTotalCount",             0, 0 },
    {"sourceIPv6Address",                   0, 0 },
    {"destinationIPv6Address",              0, 0 },
    {"sourceIPv4Address",                   0, 0 },
    {"destinationIPv4Address",              0, 0 },
    {"sourceTransportPort",                 0, 0 },
    {"destinationTransportPort",            0, 0 },
    {"flowAttributes",                      0, 0 },
    {"reverseFlowAttributes",               0, 0 },
    {"protocolIdentifier",                  0, 0 },
    {"flowEndReason",                       0, 0 },
    {"silkAppLabel",                        0, 0 },
    {"reverseFlowDeltaMilliseconds",        0, 0 },
    {"tcpSequenceNumber",                   0, 0 },
    {"reverseTcpSequenceNumber",            0, 0 },
    { "initialTCPFlags",                    0, 0 },
    { "unionTCPFlags",                      0, 0 },
    { "reverseInitialTCPFlags",             0, 0 },
    { "reverseUnionTCPFlags",               0, 0 },
/* MAC-specific information */
    { "vlanId",                             0, 0 },
    { "reverseVlanId",                      0, 0 },
    { "ingressInterface",                   0, 0 },
    { "egressInterface",                    0, 0 },
    FB_IESPEC_NULL
};

static fbInfoElementSpec_t yaf_stats_option_spec[] = {
    { "exportedFlowRecordTotalCount",       0, 0 },
    { "packetTotalCount",                   0, 0 },
    { "droppedPacketTotalCount",            0, 0 },
    { "ignoredPacketTotalCount",            0, 0 },
    { "expiredFragmentCount",               0, 0 },
    { "assembledFragmentCount",             0, 0 },
    { "flowTableFlushEventCount",           0, 0 },
    { "flowTablePeakCount",                 0, 0 },
    { "exporterIPv4Address",                0, 0 },
    { "exportingProcessId",                 0, 0 },
    { "meanFlowRate",                       0, 0 },
    { "meanPacketRate",                     0, 0 },
    FB_IESPEC_NULL
};

typedef struct silkRecord_st {
    uint64_t    flowStartMilliseconds;
    uint64_t    flowEndMilliseconds;
    uint64_t    octetTotalCount;
    uint64_t    reverseOctetTotalCount;
    uint64_t    packetTotalCount;
    uint64_t    reversePacketTotalCount;

    uint8_t     sourceIPv6Address[16];
    uint8_t     destinationIPv6Address[16];

    uint32_t    sourceIPv4Address;
    uint32_t    destinationIPv4Address;

    uint16_t    sourceTransportPort;
    uint16_t    destinationTransportPort;
    uint16_t    flowAttributes;
    uint16_t    reverseFlowAttributes;

    uint8_t     protocolIdentifier;
    uint8_t     flowEndReason;
    uint16_t    silkAppLabel;
    int32_t     reverseFlowDeltaMilliseconds;

    uint32_t    tcpSequenceNumber;
    uint32_t    reverseTcpSequenceNumber;

    uint8_t     initialTCPFlags;
    uint8_t     unionTCPFlags;
    uint8_t     reverseInitialTCPFlags;
    uint8_t     reverseUnionTCPFlags;
    uint16_t    vlanId;
    uint16_t    reverseVlanId;
    uint32_t    ingress;
    uint32_t    egress;
} silkRecord_t;

typedef struct yfIpfixStats_st {
    uint64_t    exportedFlowTotalCount;
    uint64_t    packetTotalCount;
    uint64_t    droppedPacketTotalCount;
    uint64_t    ignoredPacketTotalCount;
    uint32_t    expiredFragmentCount;
    uint32_t    assembledFragmentCount;
    uint32_t    flowTableFlushEvents;
    uint32_t    flowTablePeakCount;
    uint32_t    exporterIPv4Address;
    uint32_t    exportingProcessId;
    uint32_t    meanFlowRate;
    uint32_t    meanPacketRate;
} yfIpfixStats_t;

/**
 * prototypes
 *
 */
void sigHandler(int signalNumber);

void fillSiLKRecord(
    yfIpfixFlow_t *rec,
    silkRecord_t *silk,
    yfTcpFlow_t *tcp);

static void mdParseOptions (
    int *argc,
    char **argv[]);

gboolean mdSetExportTemplate(
    fBuf_t  *fbuf,
    uint16_t tid,
    GError  **err);

void statsPrint(
    yfIpfixStats_t *stats,
    FILE *outputFile);

static fbInfoModel_t *mdInfoModel();

static fbSession_t *mdInitExporterSession(
    GError **err,
    uint16_t *exporterTemplateID);

/**
 * main
 *
 */
int
main (int argc, char *argv[]) {

    GError *err = NULL;
    gboolean rc;
    fbSession_t *session = NULL;
    fbSession_t *exporterSession = NULL;
    MYSQL *conn = NULL;
    MYSQL_STMT *stmt = NULL;
    MYSQL_BIND bind[PARAM_COUNT];
    MYSQL_RES *result = NULL;
    MYSQL_ROW row;
    int num_fields, i, length;
    uint64_t flowID;
    int param_count;
    int flowCount = 0, silkFlowCount = 0, statscount = 0;
    int flowCountAdded = 0;
    FILE *dataFile;
    fbInfoModel_t *infoModel = NULL;
    fbTemplate_t *yaf_default_template = NULL;
    fbTemplate_t *yaf_stats_template = NULL;
    fbTemplate_t *next_template = NULL;
    fbCollector_t *collector = NULL;
    fBuf_t *buf = NULL;
    fBuf_t *exporterBuf = NULL;
    fbExporter_t *exporter = NULL;
    size_t len;
    yfTcpFlow_t tcpSiLKRec;
    yfIpfixFlow_t rec;
    yfIpfixStats_t statsrec;
    silkRecord_t silkRec;
    uint16_t tid, etid, exporterTemplateID;
    struct fbConnSpec_st socketDef;
    struct fbConnSpec_st eSocketDef;
    fbSubTemplateMultiListEntry_t *stml = NULL;
    fbListener_t *collectorListener = NULL;
    uint32_t observationDomain = 0;
    yfTcpFlow_t *tcprec = NULL;
    uint64_t start_secs, end_secs;
    struct tm time_tm;
    MYSQL_TIME ts, ets;

    signal(SIGINT, sigHandler);
    signal(SIGQUIT, sigHandler);
    signal(SIGABRT, sigHandler);
    signal(SIGKILL, sigHandler);

    /* Parse Command Line Options */
    mdParseOptions(&argc, &argv);

    /* Allocate Information Model with Elements from CERT_IE.h */
    infoModel = mdInfoModel();

    /* Allocate Incoming YAF Template */
    yaf_default_template = fbTemplateAlloc(infoModel);

    /* Add necessary elements */
    rc = fbTemplateAppendSpecArray(yaf_default_template, yaf_flow_spec,
                                   0xffffffff, &err);
    if (!rc) {
        fprintf(stderr, "Fatal: Error Building Template %s\n", err->message);
        exit(-1);
    }

    /* Allocate Session */
    session = fbSessionAlloc(infoModel);

    /* Add Template to Session */
    tid = fbSessionAddTemplate(session, TRUE, FB_TID_AUTO,
                               yaf_default_template, &err);
    if (!tid) {
        fprintf(stderr, "Fatal: Template can't associate with session %s\n",
                err->message);
        exit(-1);
    }

    /* Allocate Incoming Stats Template */
    yaf_stats_template = fbTemplateAlloc(infoModel);

    /* Add Stats Elements */
    rc = fbTemplateAppendSpecArray(yaf_stats_template, yaf_stats_option_spec,
                                   0xffffffff, &err);
    if (!rc) {
        fprintf(stderr, "fatal: error building stats tmpl %s\n", err->message);
        exit(-1);
    }

    /* Add Stats Template to Session */
    fbSessionAddTemplate(session, TRUE, YAF_STATS, yaf_stats_template, &err);

    conn = mysql_init(NULL);
    if (conn == NULL) {
        printf("MYSQL Conn Error %u: %s\n",
               mysql_errno(conn), mysql_error(conn));
        exit(1);
    }

    if (mysql_real_connect(conn, md_myhost, md_mysql_name, md_mysql_pass,
                           md_mysql_db, 0, NULL, 0) == NULL)
    {
        printf("MySQL Error %u: %s\n", mysql_errno(conn), mysql_error(conn));
        exit(1);
    }

    stmt = mysql_stmt_init(conn);
    if (!stmt) {
        printf("MySQL Out of Memory Error\n");
        exit(0);
    }

    /* Prepared Statement for Regular Flow Info */
    if (mysql_stmt_prepare(stmt, INSERT_FLOW, strlen(INSERT_FLOW))) {
        printf("MySQL INSERT FAILED %s\n", mysql_stmt_error(stmt));
        exit(0);
    }

    param_count = mysql_stmt_param_count(stmt);
    if (param_count != PARAM_COUNT) {
        printf("Invalid Param Count Returned by MySQL\n");
        exit(0);
    }

    memset(bind, 0, sizeof(bind));

    for (i=0; i < PARAM_COUNT; i++) {
        bind[i].is_null = 0;
        bind[i].is_unsigned = 1;
        bind[i].length = 0;
    }

    bind[0].buffer_type = MYSQL_TYPE_LONG;
    bind[0].buffer= (char *)&(rec.sourceIPv4Address);
    bind[1].buffer_type = MYSQL_TYPE_LONG;
    bind[1].buffer= (char *)&(rec.destinationIPv4Address);
    bind[2].buffer_type = MYSQL_TYPE_SHORT;
    bind[2].buffer= (char *)&(rec.sourceTransportPort);
    bind[3].buffer_type = MYSQL_TYPE_SHORT;
    bind[3].buffer= (char *)&(rec.destinationTransportPort);
    bind[4].buffer_type = MYSQL_TYPE_TINY;
    bind[4].buffer= (char *)&(rec.protocolIdentifier);
    bind[5].buffer_type = MYSQL_TYPE_SHORT;
    bind[5].buffer= (char *)&(rec.vlanId);
    bind[6].buffer_type = MYSQL_TYPE_DATETIME;
    bind[6].buffer= (char *)&(ts);
    bind[7].buffer_type = MYSQL_TYPE_DATETIME;
    bind[7].buffer= (char *)&(ets);
    bind[8].buffer_type = MYSQL_TYPE_LONGLONG;
    bind[8].buffer= (char *)&(rec.octetTotalCount);
    bind[9].buffer_type = MYSQL_TYPE_LONGLONG;
    bind[9].buffer= (char *)&(rec.reverseOctetTotalCount);
    bind[10].buffer_type = MYSQL_TYPE_LONGLONG;
    bind[10].buffer= (char *)&(rec.packetTotalCount);
    bind[11].buffer_type = MYSQL_TYPE_LONGLONG;
    bind[11].buffer= (char *)&(rec.reversePacketTotalCount);
    bind[12].buffer_type = MYSQL_TYPE_SHORT;
    bind[12].buffer= (char *)&(rec.silkAppLabel);
    bind[13].buffer_type = MYSQL_TYPE_TINY;
    bind[13].buffer= (char *)&(rec.flowEndReason);
    bind[14].buffer_type = MYSQL_TYPE_LONG;
    bind[14].buffer = (char *)&(observationDomain);
    bind[15].buffer_type = MYSQL_TYPE_SHORT;
    bind[15].buffer = (char *)&(rec.flowAttributes);
    bind[16].buffer_type = MYSQL_TYPE_SHORT;
    bind[16].buffer = (char *)&(rec.reverseFlowAttributes);
    bind[17].buffer_type = MYSQL_TYPE_LONG;
    bind[17].buffer = (char *)&(rec.ingress);
    bind[18].buffer_type = MYSQL_TYPE_LONG;
    bind[18].buffer = (char *)&(rec.egress);

    /* Bind the buffers */
    if (mysql_stmt_bind_param(stmt, bind)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf( " %s\n", mysql_stmt_error(stmt));
        exit(-1);
    }

    if (mdinput == NULL) {
        printf("Listening on host %s port %s\n", md_ihost, md_iport);
        socketDef.transport = FB_TCP;
        socketDef.host = md_ihost;
        socketDef.svc = md_iport;
        socketDef.ssl_ca_file = NULL;
        socketDef.ssl_cert_file = NULL;
        socketDef.ssl_key_file = NULL;
        socketDef.ssl_key_pass = NULL;
        socketDef.vai = NULL;
        socketDef.vssl_ctx = NULL;

        collectorListener = fbListenerAlloc(&socketDef, session,
                                            NULL, NULL, &err);
    } else {
        fbCollector_t *collector = fbCollectorAllocFP(NULL, mdinput);
        buf = fBufAllocForCollection(session, collector);
        printf("Reading from file %s\n", md_inputfile);
    }

    /* create exporter */

    if (md_ehost != NULL){
        /* Initialize Exporter Session */
        if (!(exporterSession = mdInitExporterSession(&err,
                                                      &exporterTemplateID)))
        {
            fprintf(stderr, "fatal: couldn't initialize exporter session "
                    "and template\n");
            fprintf(stderr, "\t%s\n", err->message);
            exit(-1);
        }

        eSocketDef.transport = FB_TCP;
        eSocketDef.host = md_ehost;
        eSocketDef.svc = md_eport;

        eSocketDef.ssl_ca_file = NULL;
        eSocketDef.ssl_cert_file = NULL;
        eSocketDef.ssl_key_file = NULL;
        eSocketDef.ssl_key_pass = NULL;
        eSocketDef.vai = NULL;
        eSocketDef.vssl_ctx = NULL;

        exporter = fbExporterAllocNet(&eSocketDef);

        exporterBuf = fBufAllocForExport(exporterSession, exporter);

        if (!fbSessionExportTemplates(exporterSession, &err)) {
           fprintf(stderr,"fatal: couldn't set export templates on session\n");
           exit(-1);
        }

        if (!fBufSetInternalTemplate(exporterBuf,exporterTemplateID, &err)) {
            fprintf(stderr,"fatal:couldn't set internal template on "
                    "exporter\n");
            fprintf(stderr, "\t%s\n", err->message);
            exit(-1);
        }

        if (!mdSetExportTemplate(exporterBuf, exporterTemplateID, &err)) {
            fprintf(stderr,"fatal: couldn't set external template on "
                    "exporter\n");
            fprintf(stderr, "\t%s\n", err->message);
            exit(-1);
        }
    }

    while (1) {

        /* If listening on an interface - run forever */
        if (collectorListener) {
            buf = fbListenerWait(collectorListener, &err);
        }

        if (!buf) {
            fprintf(stderr, "fatal: No Input Buffer \n");
            fprintf(stderr, "\t%s\n", err->message);
            exit(-1);
        }


        rc = fBufSetInternalTemplate(buf, tid, &err);
        if (!rc) {
            fprintf(stderr, "fatal: couldn't set internal template %s\n",
                    err->message);
            exit(-1);
        }

        while (1) {

            next_template = fBufNextCollectionTemplate(buf, &etid, &err);
            if (next_template) {
                if (fbTemplateGetOptionsScope(next_template)) {
                    if (!fBufSetInternalTemplate(buf, YAF_STATS, &err)) {
                        fprintf(stderr, "problem setting optins tmpl on "
                                "buffer %s", err->message);
                        exit(-1);
                    }
                    /* Get past stats template */
                    len = sizeof(statsrec);
                    rc = fBufNext(buf, (uint8_t *)&statsrec, &len, &err);
                    if (FALSE == rc) {
                        g_clear_error(&err);
                        continue;
                    }
                    statscount++;
                    statsPrint(&statsrec, mdlog);
                    rc = fBufSetInternalTemplate(buf, tid, &err);
                    if (!rc) {
                        fprintf(stderr, "fatal: couldn't set internal "
                                "template %s\n", err->message);
                        exit(-1);
                    }
                    continue;
                }
            } else {
                if (strncmp(err->message, "End of file",
                            strlen("End of file")) == 0)
                {
                    fBufFree(buf);
                    g_clear_error(&err);
                    break;
                }
                g_clear_error(&err);
                continue;
            }

            len = sizeof(rec);

            rc = fBufNext(buf, (uint8_t *)&rec, &len, &err);

            if (FALSE == rc) {
                if (!strncmp(err->message, "End of file",
                             strlen("End of file")))
                {
                    fBufFree(buf);
                    g_clear_error(&err);
                    break;
                }
                g_clear_error(&err);
                continue;
            }

            flowCount++;

            observationDomain = fbSessionGetDomain(session);
            /* get time situated */
            start_secs = rec.flowStartMilliseconds / 1000;
            end_secs = rec.flowEndMilliseconds / 1000;

            gmtime_r((time_t *)(&start_secs), &time_tm);
            ts.year = time_tm.tm_year + 1900;
            ts.month = time_tm.tm_mon + 1;
            ts.day = time_tm.tm_mday;
            ts.hour = time_tm.tm_hour;
            ts.minute = time_tm.tm_min;
            ts.second = time_tm.tm_sec;
            gmtime_r((time_t *)(&end_secs), &time_tm);
            ets.year = time_tm.tm_year + 1900;
            ets.month = time_tm.tm_mon + 1;
            ets.day = time_tm.tm_mday;
            ets.hour = time_tm.tm_hour;
            ets.minute = time_tm.tm_min;
            ets.second = time_tm.tm_sec;

            /* import flow record */
            if (mysql_stmt_execute(stmt)) {
                fprintf(stderr, " mysql_stmt_execute, 2 failed\n");
                fprintf(stderr, " %s\n", mysql_stmt_error(stmt));
                exit(0);
            }

            flowID = mysql_insert_id(conn);

            flowCountAdded++;

            /* if YAf was run with --silk - rec will have tcp flow data */
            if (rec.tcpSeqNo || rec.revTcpSeqNo || rec.uflags) {
                tcpSiLKRec.tcpSequenceNumber = rec.tcpSeqNo;
                tcpSiLKRec.reverseTcpSequenceNumber = rec.revTcpSeqNo;
                tcpSiLKRec.initialTCPFlags = rec.iflags;
                tcpSiLKRec.reverseInitialTCPFlags = rec.riflags;
                tcpSiLKRec.unionTCPFlags = rec.uflags;
                tcpSiLKRec.reverseUnionTCPFlags = rec.ruflags;
                yfMyTCPInsert(conn, &tcpSiLKRec, YTF_REV, flowID);
            }


            while ((stml = FBSTMLNEXTENTRY(&(rec.subTemplateMultiList), stml)))
            {
                switch ((stml->tmplID & YTF_BIF)) {
                  case YAF_TCP_FLOW_TID:
                    {
                        tcprec = (yfTcpFlow_t *)FBSTMLNEXT(stml, tcprec);
                        yfMyTCPInsert(conn, tcprec, stml->tmplID, flowID);
                        tcprec = NULL;
                    }
                    break;
                  case YAF_P0F_FLOW_TID:
                    {
                        yfP0fFlow_t *p0frec = NULL;
                        p0frec = (yfP0fFlow_t *)FBSTMLNEXT(stml, p0frec);
                        yfMyP0FInsert(conn, p0frec, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_HTTP_FLOW_TID:
                    {
                        yfHTTPFlow_t *httprec = NULL;
                        httprec = (yfHTTPFlow_t *)FBSTMLNEXT(stml, httprec);
                        yfMyHTTPInsert(conn, httprec, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_POP3_FLOW_TID:
                    {
                        yfPOP3Flow_t *pop3flow = NULL;
                        pop3flow = (yfPOP3Flow_t *)FBSTMLNEXT(stml, pop3flow);
                        yfMyPOP3Insert(conn, pop3flow, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_IRC_FLOW_TID:
                    {
                        yfIRCFlow_t *ircflow = NULL;
                        ircflow = (yfIRCFlow_t *)FBSTMLNEXT(stml, ircflow);
                        yfMyIRCInsert(conn, ircflow, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_TFTP_FLOW_TID:
                    {
                        yfTFTPFlow_t *tftpflow = NULL;
                        tftpflow = (yfTFTPFlow_t *)FBSTMLNEXT(stml, tftpflow);
                        yfMyTFTPInsert(conn, tftpflow, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_SLP_FLOW_TID:
                    {
                        yfSLPFlow_t *slpflow = NULL;
                        slpflow = (yfSLPFlow_t *)FBSTMLNEXT(stml, slpflow);
                        yfMySLPInsert(conn, slpflow, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_FTP_FLOW_TID:
                    {
                        yfFTPFlow_t *ftpflow = NULL;
                        ftpflow = (yfFTPFlow_t *)FBSTMLNEXT(stml, ftpflow);
                        yfMyFTPInsert(conn, ftpflow, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_IMAP_FLOW_TID:
                    {
                        yfIMAPFlow_t *imapflow = NULL;
                        imapflow = (yfIMAPFlow_t *)FBSTMLNEXT(stml, imapflow);
                        yfMyIMAPInsert(conn, imapflow, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_SIP_FLOW_TID:
                    {
                        yfSIPFlow_t *sipflow = NULL;
                        sipflow = (yfSIPFlow_t *)FBSTMLNEXT(stml, sipflow);
                        yfMySIPInsert(conn, sipflow, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_SMTP_FLOW_TID:
                    {
                        yfSMTPFlow_t *smtpflow = NULL;
                        smtpflow = (yfSMTPFlow_t *)FBSTMLNEXT(stml, smtpflow);
                        yfMySMTPInsert(conn, smtpflow, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_SSH_FLOW_TID:
                    {
                        yfSSHFlow_t *sshflow = NULL;
                        sshflow = (yfSSHFlow_t *)FBSTMLNEXT(stml, sshflow);
                        yfMySSHInsert(conn, sshflow, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_NNTP_FLOW_TID:
                    {
                        yfNNTPFlow_t *nntpflow = NULL;
                        nntpflow = (yfNNTPFlow_t *)FBSTMLNEXT(stml, nntpflow);
                        yfMyNNTPInsert(conn, nntpflow, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_SSL_FLOW_TID:
                    {
                        yfSSLFlow_t *sslflow = NULL;
                        sslflow = (yfSSLFlow_t *)FBSTMLNEXT(stml, sslflow);
                        yfMySSLInsert(conn, sslflow, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_SSL_CERT_FLOW_TID:
                    {
                        yfSSLCertFlow_t *cert = NULL;
                        int certChain = 0;
                        while ((cert=(yfSSLCertFlow_t *)FBSTMLNEXT(stml,cert)))
                        {
                            yfMySSLCertInsert(conn, cert, stml->tmplID, flowID,
                                              certChain);
                            certChain++;
                        }
                    }
                    break;
                  case YAF_NEW_SSL_FLOW_TID:
                    {
                        yfSSL2Flow_t *ssl = NULL;
                        ssl = (yfSSL2Flow_t *)FBSTMLNEXT(stml, ssl);
                        yfMyNewSSLInsert(conn, ssl, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_DNS_FLOW_TID:
                    {
                        yfDNSFlow_t *dnsflow = NULL;
                        dnsflow = (yfDNSFlow_t *)FBSTMLNEXT(stml, dnsflow);
                        yfMyDNSInsert(conn, dnsflow, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_RTSP_FLOW_TID:
                    {
                        yfRTSPFlow_t *rtspflow = NULL;
                        rtspflow = (yfRTSPFlow_t *)FBSTMLNEXT(stml, rtspflow);
                        yfMyRTSPInsert(conn, rtspflow, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_MYSQL_FLOW_TID:
                    {
                        yfMySQLFlow_t *mysqlflow = NULL;
                        mysqlflow = (yfMySQLFlow_t*)FBSTMLNEXT(stml, mysqlflow);
                        yfMySQLInsert(conn, mysqlflow, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_STATS_FLOW_TID:
                    {
                        yfFlowStats_t *fs = NULL;
                        fs = (yfFlowStats_t *)FBSTMLNEXT(stml, fs);
                        yfFlowStatsInsert(conn, fs, stml->tmplID, flowID);
                    }
                    break;
                  case YAF_DHCP_FLOW_TID:
                    {
                        yfDHCP_FP_Flow_t *dhcp = NULL;
                        dhcp = (yfDHCP_FP_Flow_t *)FBSTMLNEXT(stml, dhcp);
                        yfDHCPInsert(conn, dhcp, stml->tmplID, flowID);
                    }
                    break;
                default:
                    FBSTMLNEXT(stml, NULL);
                    break;
                }
            }

            /* Export SiLK Record */
            if (md_ehost != NULL) {
                fillSiLKRecord(&rec, &silkRec, tcprec);
                silkFlowCount++;
                if (!mdSetExportTemplate(exporterBuf,exporterTemplateID,&err))
                {
                    fprintf(mdlog, "fatal: couldn't set external template "
                            "on exporter\n");
                    fprintf(mdlog, "\t%s\n", err->message);
                    break;
                }
                if (!fBufAppend(exporterBuf, (uint8_t *)&silkRec,
                                sizeof(silkRec), &err))
                {
                    fprintf(stderr,"Error with Export, %s\n", err->message);
                    fBufFree(exporterBuf);
                    break;
                }
            }

            fbSubTemplateMultiListClear(&(rec.subTemplateMultiList));
        }

        fprintf(mdlog, "*** Processed %d Flows ***\n", flowCount);
        fprintf(mdlog,"*** Exported %d Flows to SiLK ***\n", silkFlowCount);
        fprintf(mdlog, "*** Imported %d Flow to the MySQL Database ***\n",
                flowCountAdded);
        fprintf(mdlog, "*** Processed %d Stats Records ***\n", statscount);

        if (!collectorListener || (err != NULL)) {
            fprintf(mdlog, "Mediator Finished Reading File\n");
            break;
        }

        if (exporterBuf) {
            if (!fBufEmit(exporterBuf, &err)) {
                fprintf(mdlog, "fBufEmit failed: %s\n", err->message);
                fprintf(mdlog, "Continuing...\n", err->message);
                g_clear_error(&err);
            }
        }

    }

    mysql_stmt_close(stmt);
    fclose(mdlog);
    mysql_close(conn);

    if (exporterBuf) {
        /* Free Buffer Before Exit */
        fBufFree(exporterBuf);
    }

    return 0;
}

/**
 * fillSiLKRecord
 *
 * take data from YAF Record and export in SiLK Record Format
 *
 */
void fillSiLKRecord (
    yfIpfixFlow_t *rec,
    silkRecord_t *silk,
    yfTcpFlow_t *tcp)
{

    silk->flowStartMilliseconds = rec->flowStartMilliseconds;
    silk->flowEndMilliseconds = rec->flowEndMilliseconds;
    silk->octetTotalCount = rec->octetTotalCount;
    silk->reverseOctetTotalCount = rec->reverseOctetTotalCount;
    silk->packetTotalCount = rec->packetTotalCount;
    silk->reversePacketTotalCount = rec->reversePacketTotalCount;
    if (rec->sourceIPv6Address) {
        memcpy(silk->sourceIPv6Address, rec->sourceIPv6Address,
               sizeof(rec->sourceIPv6Address));
    }
    if (rec->destinationIPv6Address) {
        memcpy(silk->destinationIPv6Address, rec->destinationIPv6Address,
               sizeof(rec->destinationIPv6Address));
    }
    silk->sourceIPv4Address = rec->sourceIPv4Address;
    silk->destinationIPv4Address = rec->destinationIPv4Address;
    silk->sourceTransportPort = rec->sourceTransportPort;
    silk->destinationTransportPort = rec->destinationTransportPort;
    silk->protocolIdentifier = rec->protocolIdentifier;
    silk->flowEndReason = rec->flowEndReason;
    silk->silkAppLabel = rec->silkAppLabel;
    silk->reverseFlowDeltaMilliseconds = rec->reverseFlowDeltaMilliseconds;
    if (tcp) {
        silk->tcpSequenceNumber = tcp->tcpSequenceNumber;
        silk->reverseTcpSequenceNumber = tcp->reverseTcpSequenceNumber;
        silk->initialTCPFlags = tcp->initialTCPFlags;
        silk->reverseInitialTCPFlags = tcp->reverseInitialTCPFlags;
        silk->unionTCPFlags = tcp->unionTCPFlags;
        silk->reverseUnionTCPFlags = tcp->reverseUnionTCPFlags;
    } else {
        /* if YAF was run with --silk */
        silk->tcpSequenceNumber = rec->tcpSeqNo;
        silk->reverseTcpSequenceNumber = rec->revTcpSeqNo;
        silk->initialTCPFlags = rec->iflags;
        silk->reverseInitialTCPFlags = rec->riflags;
        silk->unionTCPFlags = rec->uflags;
        silk->reverseUnionTCPFlags = rec->ruflags;
    }

    silk->vlanId = rec->vlanId;
    silk->reverseVlanId = rec->reverseVlanId;

}


/**
 * sigHandler
 *
 * this gets called from various system signal handlers.  It is used to
 * provide a way to exit this program cleanly when the user wants to
 * kill this program
 *
 * @param signalNumber the number of the signal that this handler is
 *        getting called for
 *
 */
void
 sigHandler (int signalNumber)
{
    fprintf(stderr, "Received signal %d, time to die...\n", signalNumber);

    fclose(mdlog);

    /** exit the system cleanly */
    exit(-1*signalNumber);
}


/**
 * mdParseOptions
 *
 * parses the command line options
 *
 */
static void mdParseOptions (
    int *argc,
    char **argv[])
{

    GOptionContext *ctx = NULL;
    GError *err = NULL;

    ctx = g_option_context_new(" - Mediator Options");

    g_option_context_add_main_entries(ctx, md_core_option, NULL);

    g_option_context_set_help_enabled(ctx, TRUE);

    if (!g_option_context_parse(ctx, argc, argv, &err)) {
        fprintf(stderr, "option parsing failed: %s\n", err->message);
        exit(1);
    }


    if (md_inputfile != NULL) {
        mdinput = fopen(md_inputfile, "r");
        if (mdinput == NULL) {
            fprintf(stderr, "Can't open input file %s for reading\n",
                    md_inputfile);
            fprintf(stderr, "Use --help for usage.\n");
            exit(-1);
        }
    } else if (atoi(md_iport) < 1024) {
        fprintf(stderr, "Fatal: listening port for TCP traffic must be above"
                " 1024, %d is invalid\n", atoi(md_iport));
        fprintf(stderr, "Use --help for usage.\n");
        exit(-1);
    }

    if (atoi(md_eport) < 1024) {
        fprintf(stderr, "Fatal: exporting port for TCP traffic must be above"
                " 1024, %d is invalid\n", atoi(md_eport));
        fprintf(stderr, "Use --help for usage.\n");
        exit(-1);
    }

    if (md_logfile != NULL) {
        mdlog = fopen(md_logfile, "a+");
        if (mdlog == NULL) {
            fprintf(stderr, "Can not open log file %s for writing\n",
                    md_logfile);
            fprintf(stderr, "Use --help for usage.\n");
            exit(1);
        }
    } else {
        mdlog = stdout;
    }

    g_option_context_free(ctx);

}


/**
 * mdSetExportTemplate
 *
 */
gboolean mdSetExportTemplate(
    fBuf_t  *fbuf,
    uint16_t tid,
    GError  **err)
{

    fbSession_t *session = NULL;
    fbTemplate_t *tmpl = NULL;

    if (fBufSetExportTemplate(fbuf, tid, err)) {
        return TRUE;
    }

    if (!g_error_matches(*err, FB_ERROR_DOMAIN, FB_ERROR_TMPL)) {
        return FALSE;
    }

    g_clear_error (err);
    session = fBufGetSession(fbuf);
    tmpl = fbTemplateAlloc(mdInfoModel());

    if (!fbTemplateAppendSpecArray(tmpl, silkTemplate,
                                   0xffffffff, err)){
        return FALSE;
    }

    if (!fbSessionAddTemplate(session, FALSE, tid, tmpl, err)) {
        return FALSE;
    }

    return fBufSetExportTemplate(fbuf, tid, err);
}

/**
 * mdInfoModel
 *
 * create an appropriate info model  --- see CERT_IE.h
 * ================================
 * alloc the default (with IANA elements pre-populated) via fbInfoModelAlloc
 * add in the CERT/NetSA added elements using
 * fbInfoModelAddElement/fbInfoModelAddElementArray
 * need to add the FB_IE_INIT("silkAppLabel", 6871, 33, 2, FB_IE_F_ENDIAN)
 * information element to the model that creates a complete info model
 * for use through the rest of the app
 * (fbInfoModel_t)
 *
 */

static fbInfoModel_t *mdInfoModel()
{

    static fbInfoModel_t *md_info_model = NULL;

    if (!md_info_model){
        md_info_model = fbInfoModelAlloc();

        fbInfoModelAddElementArray(md_info_model, yaf_info_elements);
    }

    return md_info_model;
}

/**
 * mdInitExporterSession
 *
 *
 *
 **/
static fbSession_t *mdInitExporterSession(
    GError **err,
    uint16_t *exporterTemplateID)
{

    fbInfoModel_t *model = mdInfoModel();
    fbTemplate_t *tmpl = NULL;
    fbSession_t *session = NULL;

    /*Allocate the session */

    session = fbSessionAlloc(model);

    fbSessionSetDomain(session, 1);

    tmpl = fbTemplateAlloc(model);
    if (!fbTemplateAppendSpecArray(tmpl, silkTemplate, 0xffffffff, err)){
        return NULL;
    }
    if (!(*exporterTemplateID = fbSessionAddTemplate(session, TRUE,
                                                     FB_TID_AUTO, tmpl, err))){
        return NULL;
    }

    return session;
}


void statsPrint(
    yfIpfixStats_t *stats,
    FILE *outputFile)
{
    fprintf(outputFile, "----------OPTIONS - STATS----------\n");
    fprintf(outputFile, "Exported Flow Count is %llu\n",
            stats->exportedFlowTotalCount);
    fprintf(outputFile, "Packet Total Count is %llu\n",
            stats->packetTotalCount);
    fprintf(outputFile, "Dropped Packets %llu\n",
            stats->droppedPacketTotalCount);
    fprintf(outputFile, "Ignored Packets %llu\n",
            stats->ignoredPacketTotalCount);
    fprintf(outputFile, "Expired Fragment Count %u\n",
            stats->expiredFragmentCount);
    fprintf(outputFile, "Assembled Fragment Count %u\n",
            stats->assembledFragmentCount);
    fprintf(outputFile, "FlowTable Flush Events %u\n",
            stats->flowTableFlushEvents);
    fprintf(outputFile, "FlowTable Peak Count %u\n", stats->flowTablePeakCount);
    fprintf(outputFile, "Exporter IPv4 Address %u\n",
            stats->exporterIPv4Address);
    fprintf(outputFile, "Exporting Process ID %d\n", stats->exportingProcessId);
    fprintf(outputFile, "Mean Flow Rate %u\n", stats->meanFlowRate);
    fprintf(outputFile, "Mean Packet Rate %u\n\n", stats->meanPacketRate);
}
