/**
 * @file yafDBInsert.c
 *
 * Inserts DPI flow data into MySQL database
 *
 * @Author: Emily
 * @Date: 9.17.12
 *
 ** @OPENSOURCE_HEADER_START@
 ** Use of the YAF system and related source code is subject to the terms
 ** of the following licenses:
 **
 ** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
 ** Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 **
 ** NO WARRANTY
 **
 ** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
 ** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
 ** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
 ** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
 ** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
 ** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
 ** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
 ** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
 ** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
 ** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
 ** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
 ** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
 ** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
 ** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
 ** DELIVERABLES UNDER THIS LICENSE.
 **
 ** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
 ** Mellon University, its trustees, officers, employees, and agents from
 ** all claims or demands made against them (and any related losses,
 ** expenses, or attorney's fees) arising out of, or relating to Licensee's
 ** and/or its sub licensees' negligent use or willful misuse of or
 ** negligent conduct or willful misconduct regarding the Software,
 ** facilities, or other rights or assistance granted by Carnegie Mellon
 ** University under this License, including, but not limited to, any
 ** claims of product liability, personal injury, death, damage to
 ** property, or violation of any laws or regulations.
 **
 ** Carnegie Mellon University Software Engineering Institute authored
 ** documents are sponsored by the U.S. Department of Defense under
 ** Contract FA8721-05-C-0003. Carnegie Mellon University retains
 ** copyrights in all material produced under this contract. The U.S.
 ** Government retains a non-exclusive, royalty-free license to publish or
 ** reproduce these documents, or allow others to do so, for U.S.
 ** Government purposes only pursuant to the copyright license under the
 ** contract clause at 252.227.7013.
 **
 ** @OPENSOURCE_HEADER_END@
 ** ------------------------------------------------------------------------
 */

#include "yafDBInsert.h"

#define FBSTLNEXT(a, b) fbSubTemplateListGetNextPtr(a, b)
#define FBBLNEXT(a, b) fbBasicListGetIndexedDataPtr(a, b)

void printIPAddress(char *ipaddr_buf,
                    uint32_t ip) {

    uint32_t mask = 0xff000000U;
    uint8_t dqp[4];

    /* split the address */
    dqp[0] = (ip & mask) >> 24;
    mask >>= 8;
    dqp[1] = (ip & mask) >> 16;
    mask >>= 8;
    dqp[2] = (ip & mask) >> 8;
    mask >>= 8;
    dqp[3] = (ip & mask);

    /* print to it */
    snprintf(ipaddr_buf, 16,
             "%hhu.%hhu.%hhu.%hhu",dqp[0],dqp[1],dqp[2],dqp[3]);

}

void printIP6Address(
    char        *ipaddr_buf,
    uint8_t     *ipaddr)
{

    char            *cp = ipaddr_buf;
    uint16_t        *aqp = (uint16_t *)ipaddr;
    uint16_t        aq;
    gboolean        colon_start = FALSE;
    gboolean        colon_end = FALSE;


    for (; (uint8_t *)aqp < ipaddr + 16; aqp++) {
        aq = g_ntohs(*aqp);
        if (aq || colon_end) {
            if ((uint8_t *)aqp < ipaddr + 14) {
                snprintf(cp, 6, "%04hx:", aq);
                cp += 5;
            } else {
                snprintf(cp, 5, "%04hx", aq);
                cp += 4;
            }
            if (colon_start) {
                colon_end = TRUE;
            }
        } else if (!colon_start) {
            if ((uint8_t *)aqp == ipaddr) {
                snprintf(cp, 3, "::");
                cp += 2;
            } else {
                snprintf(cp, 2, ":");
                cp += 1;
            }
            colon_start = TRUE;
        }
    }
}

gboolean yfMyTCPInsert(
    MYSQL *conn,
    yfTcpFlow_t *tcpRecord,
    uint16_t tmplID,
    uint64_t flowID)
{
    static MYSQL_STMT *tcp_stmt;
    MYSQL_BIND tcp_bind[7];
    int pcount;
    char itcpflags[10], utcpflags[10], ritcpflags[10], rutcpflags[10];
    size_t iflagssize = 0;
    size_t uflagssize = 0;
    size_t riflagssize = 0;
    size_t ruflagssize = 0;
    int i;

    if (!tcp_stmt) {
        tcp_stmt = mysql_stmt_init(conn);
        if (!tcp_stmt) {
            printf("MySQL out of Memory Error for TCP\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(tcp_stmt, INSERT_TCP, strlen(INSERT_TCP))) {
            printf("MySQL Prepare TCP Statement Failed %s\n", mysql_stmt_error(tcp_stmt));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(tcp_stmt);
        if (pcount != 7) {
            printf("Invalid TCP Param Count returned by MySQL\n");
            return FALSE;
        }
    }

    memset(tcp_bind, 0, sizeof(tcp_bind));
    for (i = 0; i < 7; i++) {
        tcp_bind[i].is_null = 0;
        tcp_bind[i].is_unsigned = 1;
        tcp_bind[i].length = 0;
        tcp_bind[i].buffer = NULL;
    }

    tcp_bind[0].buffer_type = MYSQL_TYPE_LONGLONG;
    tcp_bind[0].buffer = (char *)&flowID;
    tcp_bind[1].buffer_type = MYSQL_TYPE_LONG;
    tcp_bind[1].buffer = (char *)&tcpRecord->tcpSequenceNumber;
    if (tmplID & YTF_REV) {
        tcp_bind[2].buffer_type = MYSQL_TYPE_LONG;
        tcp_bind[2].buffer = (char *)&tcpRecord->reverseTcpSequenceNumber;
    }
    tcp_bind[3].buffer_type = MYSQL_TYPE_STRING;
    tcp_bind[3].buffer = (char *)itcpflags;
    tcp_bind[3].length = (unsigned long *)&iflagssize;
    tcp_bind[4].buffer_type = MYSQL_TYPE_STRING;
    tcp_bind[4].buffer = (char *)utcpflags;
    tcp_bind[4].length = (unsigned long *)&uflagssize;
    if (tmplID & YTF_REV) {
        tcp_bind[5].buffer_type = MYSQL_TYPE_STRING;
        tcp_bind[5].buffer = (char *)ritcpflags;
        tcp_bind[5].length = (unsigned long *)&riflagssize;
        tcp_bind[6].buffer_type = MYSQL_TYPE_STRING;
        tcp_bind[6].buffer = (char *)rutcpflags;
        tcp_bind[6].length = (unsigned long *)&ruflagssize;
    }

    if (mysql_stmt_bind_param(tcp_stmt, tcp_bind)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(tcp_stmt));
        return FALSE;
    }

    printFlags(tcpRecord->initialTCPFlags, itcpflags);
    printFlags(tcpRecord->unionTCPFlags, utcpflags);
    iflagssize = strlen(itcpflags);
    uflagssize = strlen(utcpflags);

    if (tmplID & YTF_REV) {
        if (tcpRecord->reverseInitialTCPFlags) {
            printFlags(tcpRecord->reverseInitialTCPFlags, ritcpflags);
            riflagssize = strlen(ritcpflags);
        }

        if (tcpRecord->reverseUnionTCPFlags) {
            printFlags(tcpRecord->reverseUnionTCPFlags, rutcpflags);
            ruflagssize = strlen(rutcpflags);
        }
    }

    if (mysql_stmt_execute(tcp_stmt)) {
        fprintf(stderr, " mysql_stmt_execute failed tcp\n");
        fprintf(stderr, " %s\n", mysql_stmt_error(tcp_stmt));
        return FALSE;
    }

    return TRUE;
}

gboolean yfMyP0FInsert(
    MYSQL *conn,
    yfP0fFlow_t *p0frec,
    uint16_t tmplID,
    uint64_t flowID)
{
    static MYSQL_STMT *stmt_p0f;
    MYSQL_BIND bind_p0f[7];
    int pcount;
    size_t length;
    int i;

    if (!stmt_p0f) {
        stmt_p0f = mysql_stmt_init(conn);
        if (!stmt_p0f) {
            printf("MySQL out of Memory Error for P0F\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_p0f, INSERT_P0F, strlen(INSERT_P0F))) {
            printf("MySQL Prepare P0F Statement Failed %s\n", mysql_stmt_error(stmt_p0f));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_p0f);
        if (pcount != 7) {
            printf("Invalid P0F Param Count returned by MySQL\n");
            return FALSE;
        }

    }

    memset(bind_p0f, 0, sizeof(bind_p0f));

    for (i = 0; i < 7; i++) {
        bind_p0f[i].is_null = 0;
        bind_p0f[i].is_unsigned = 1;
        bind_p0f[i].buffer = NULL;
        bind_p0f[i].length = 0;
    }

    bind_p0f[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_p0f[0].buffer = (char *)&flowID;
    bind_p0f[0].length = 0;
    bind_p0f[1].buffer_type = MYSQL_TYPE_STRING;
    bind_p0f[1].buffer = (char *)p0frec->osName.buf;
    bind_p0f[1].length = (unsigned long *)&(p0frec->osName.len);
    bind_p0f[2].buffer_type = MYSQL_TYPE_STRING;
    bind_p0f[2].buffer = (char *)p0frec->osFingerPrint.buf;
    bind_p0f[2].length = (unsigned long *)&(p0frec->osFingerPrint.len);
    bind_p0f[3].buffer_type = MYSQL_TYPE_STRING;
    bind_p0f[3].buffer = (char *)p0frec->osVersion.buf;
    bind_p0f[3].length = (unsigned long *)&(p0frec->osVersion.len);
    if (tmplID & YTF_REV) {
        bind_p0f[4].buffer_type = MYSQL_TYPE_STRING;
        bind_p0f[4].buffer = (char *)p0frec->reverseOsName.buf;
        bind_p0f[4].length = (unsigned long *)&(p0frec->reverseOsName.len);
        bind_p0f[5].buffer_type = MYSQL_TYPE_STRING;
        bind_p0f[5].buffer = (char *)p0frec->reverseOsFingerPrint.buf;
        bind_p0f[5].length = (unsigned long *)&(p0frec->reverseOsFingerPrint.len);
        bind_p0f[6].buffer_type = MYSQL_TYPE_STRING;
        bind_p0f[6].buffer = (char *)p0frec->reverseOsVersion.buf;
        bind_p0f[6].length = (unsigned long *)&(p0frec->reverseOsVersion.len);
    }

    if (mysql_stmt_bind_param(stmt_p0f, bind_p0f)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_p0f));
        return FALSE;
    }

    p0frec->osName.len = (p0frec->osName.len > 100) ? 100 : p0frec->osName.len;
    p0frec->osFingerPrint.len = (p0frec->osFingerPrint.len > 100) ? 100 : p0frec->osFingerPrint.len;
    p0frec->osVersion.len = (p0frec->osVersion.len > 100) ? 100 : p0frec->osVersion.len;

    if (tmplID & YTF_REV) {
        p0frec->reverseOsName.len = (p0frec->reverseOsName.len > 100) ? 100 : p0frec->reverseOsName.len;
        p0frec->reverseOsFingerPrint.len = (p0frec->reverseOsFingerPrint.len > 100) ? 100 : p0frec->reverseOsFingerPrint.len;
        p0frec->reverseOsVersion.len = (p0frec->reverseOsVersion.len > 100) ? 100 : p0frec->reverseOsVersion.len;
    }
    if (mysql_stmt_execute(stmt_p0f)) {
        fprintf(stderr, " mysql_stmt_execute failed p0f\n");
        fprintf(stderr, " %s\n", mysql_stmt_error(stmt_p0f));
        return FALSE;
    }

    return TRUE;
}

gboolean yfMyHTTPInsert(
    MYSQL *conn,
    yfHTTPFlow_t *httprec,
    uint16_t httpTmplID,
    uint64_t flowID)
{

    int w, i;
    fbVarfield_t *httpVar = NULL;
    static MYSQL_STMT *stmt_http;
    MYSQL_BIND bind_http[3];
    int pcount;
    char varLenTemp[250];
    size_t length;
    uint16_t id;

    if (!stmt_http) {
        stmt_http = mysql_stmt_init(conn);
        if (!stmt_http) {
            printf("MySQL out of Memory Error for HTTP\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_http, INSERT_HTTP, strlen(INSERT_HTTP))) {
            printf("MySQL Prepare HTTP Statement Failed %s\n",
                   mysql_stmt_error(stmt_http));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_http);
        if (pcount != 3) {
            printf("Invalid HTTP Param Count returned by MySQL\n");
            return FALSE;
        }
    }

    memset(bind_http, 0, sizeof(bind_http));
    for (i = 0; i < 3; i++) {
        bind_http[i].is_null = 0;
        bind_http[i].is_unsigned = 1;
    }

    bind_http[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_http[0].buffer = (char *)&flowID;
    bind_http[0].length = 0;
    bind_http[1].buffer_type = MYSQL_TYPE_SHORT;
    bind_http[1].buffer = (char *)&id;
    bind_http[1].length = 0;
    bind_http[2].buffer_type = MYSQL_TYPE_STRING;
    bind_http[2].buffer = (char *)varLenTemp;
    bind_http[2].length = (unsigned long *)&length;

    if (mysql_stmt_bind_param(stmt_http, bind_http)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_http));
        return FALSE;
    }

    for (w = 0;(httpVar = (fbVarfield_t *)FBBLNEXT(&(httprec->server), w)); w++) {
        length = (httpVar->len > 150) ? 150 : httpVar->len;
        memcpy(varLenTemp, httpVar->buf, length);
        id = HTTPSERVER;
        if (mysql_stmt_execute(stmt_http)) {
            fprintf(stderr, " mysql_stmt_execute failed http\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_http));
            return FALSE;
        }
    }
    fbBasicListClear(&(httprec->server));

    for (w = 0;(httpVar = (fbVarfield_t *)FBBLNEXT(&(httprec->userAgent), w));w++) {
        length = (httpVar->len > 150) ? 150 : httpVar->len;
        memcpy(varLenTemp, httpVar->buf, length);
        id = HTTPUSERAGENT;
        if (mysql_stmt_execute(stmt_http)) {
            fprintf(stderr, " mysql_stmt_execute failed http\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_http));
            return FALSE;
        }
    }
    fbBasicListClear(&(httprec->userAgent));

    for (w = 0;(httpVar = (fbVarfield_t *)FBBLNEXT(&(httprec->get), w)); w++)
    {
        length = (httpVar->len > 150) ? 150 : httpVar->len;
        memcpy(varLenTemp, httpVar->buf, length);
        id = HTTPGET;
        if (mysql_stmt_execute(stmt_http)) {
            fprintf(stderr, " mysql_stmt_execute failed http\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_http));
            return FALSE;
        }
    }
    fbBasicListClear(&(httprec->get));

    for (w = 0;(httpVar = (fbVarfield_t *)FBBLNEXT(&(httprec->connection),w)); w++)
    {
        length = (httpVar->len > 150) ? 150 : httpVar->len;
        memcpy(varLenTemp, httpVar->buf, length);
        id = HTTPCONNECTION;
        if (mysql_stmt_execute(stmt_http)) {
            fprintf(stderr, " mysql_stmt_execute failed http\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_http));
            return FALSE;
        }
    }
    fbBasicListClear(&(httprec->connection));

    for (w = 0;(httpVar = (fbVarfield_t *)FBBLNEXT(&(httprec->version), w)); w++) {
        length = (httpVar->len > 150) ? 150 : httpVar->len;
        memcpy(varLenTemp, httpVar->buf, length);
        id = HTTPVERSION;
        if (mysql_stmt_execute(stmt_http)) {
            fprintf(stderr, " mysql_stmt_execute failed http\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_http));
            return FALSE;
        }
    }
    fbBasicListClear(&(httprec->version));

    for (w = 0;(httpVar = (fbVarfield_t *)FBBLNEXT(&(httprec->referer), w));w++)
    {
        length = (httpVar->len > 150) ? 150 : httpVar->len;
        memcpy(varLenTemp, httpVar->buf, length);
        id = HTTPREFERER;
        if (mysql_stmt_execute(stmt_http)) {
            fprintf(stderr, " mysql_stmt_execute failed http\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_http));
            return FALSE;
        }
    }
    fbBasicListClear(&(httprec->referer));

    for (w = 0;(httpVar = (fbVarfield_t *)FBBLNEXT(&(httprec->location), w)); w++) {
        length = (httpVar->len > 150) ? 150 : httpVar->len;
        memcpy(varLenTemp, httpVar->buf, length);
        id = HTTPLOCATION;
        if (mysql_stmt_execute(stmt_http)) {
            fprintf(stderr, " mysql_stmt_execute failed http\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_http));
            return FALSE;
        }
    }
    fbBasicListClear(&(httprec->location));

    for (w = 0;(httpVar = (fbVarfield_t *)FBBLNEXT(&(httprec->host), w));w++) {
        length = (httpVar->len > 150) ? 150 : httpVar->len;
        memcpy(varLenTemp, httpVar->buf, length);
        id = HTTPHOST;
        if (mysql_stmt_execute(stmt_http)) {
            fprintf(stderr, " mysql_stmt_execute failed http\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_http));
            return FALSE;
        }
    }
    fbBasicListClear(&(httprec->host));

    for (w = 0;(httpVar = (fbVarfield_t *)FBBLNEXT(&(httprec->contentLength), w)); w++) {
        length = (httpVar->len > 150) ? 150 : httpVar->len;
        memcpy(varLenTemp, httpVar->buf, length);
        id = HTTPCONNECTION;
        if (mysql_stmt_execute(stmt_http)) {
            fprintf(stderr, " mysql_stmt_execute failed http\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_http));
            return FALSE;
        }
    }
    fbBasicListClear(&(httprec->contentLength));

    for (w = 0;(httpVar = (fbVarfield_t *)FBBLNEXT(&(httprec->age), w)); w++) {
        length = (httpVar->len > 150) ? 150 : httpVar->len;
        memcpy(varLenTemp, httpVar->buf, length);
        id = HTTPAGE;
        if (mysql_stmt_execute(stmt_http)) {
            fprintf(stderr, " mysql_stmt_execute failed http\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_http));
            return FALSE;
        }
    }
    fbBasicListClear(&(httprec->age));

    for (w = 0;(httpVar = (fbVarfield_t *)FBBLNEXT(&(httprec->response), w));w++) {
        length = (httpVar->len > 150) ? 150 : httpVar->len;
        memcpy(varLenTemp, httpVar->buf, length);
        id = HTTPRESPONSE;
        if (mysql_stmt_execute(stmt_http)) {
            fprintf(stderr, " mysql_stmt_execute failed http\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_http));
            return FALSE;
        }
    }
    fbBasicListClear(&(httprec->response));

    for (w = 0;(httpVar = (fbVarfield_t *)FBBLNEXT(&(httprec->acceptLang), w)); w++) {
        length = (httpVar->len > 150) ? 150 : httpVar->len;
        memcpy(varLenTemp, httpVar->buf, length);
        id = HTTPACCEPTLANGUAGE;
        if (mysql_stmt_execute(stmt_http)) {
            fprintf(stderr, " mysql_stmt_execute failed http\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_http));
            return FALSE;
        }
    }
    fbBasicListClear(&(httprec->acceptLang));

    for (w = 0;(httpVar = (fbVarfield_t *)FBBLNEXT(&(httprec->accept), w)); w++) {
        length = (httpVar->len > 150) ? 150 : httpVar->len;
        memcpy(varLenTemp, httpVar->buf, length);
        id = HTTPACCEPT;
        if (mysql_stmt_execute(stmt_http)) {
            fprintf(stderr, " mysql_stmt_execute failed http\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_http));
            return FALSE;
        }
    }
    fbBasicListClear(&(httprec->accept));

    for (w = 0;(httpVar = (fbVarfield_t *)FBBLNEXT(&(httprec->contentType), w)); w++) {
        length = (httpVar->len > 150) ? 150 : httpVar->len;
        memcpy(varLenTemp, httpVar->buf, length);
        id = HTTPCONTENTTYPE;
        if (mysql_stmt_execute(stmt_http)) {
            fprintf(stderr, " mysql_stmt_execute failed http\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_http));
            return FALSE;
        }
    }
    fbBasicListClear(&(httprec->contentType));

    for (w = 0;(httpVar = (fbVarfield_t *)FBBLNEXT(&(httprec->httpCookie), w)); w++) {
        length = (httpVar->len > 150) ? 150 : httpVar->len;
        memcpy(varLenTemp, httpVar->buf, length);
        id = HTTPCOOKIE;
        if (mysql_stmt_execute(stmt_http)) {
            fprintf(stderr, " mysql_stmt_execute failed http\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_http));
            return FALSE;
        }
    }
    fbBasicListClear(&(httprec->httpCookie));

    for (w = 0;(httpVar = (fbVarfield_t *)FBBLNEXT(&(httprec->httpSetCookie), w)); w++) {
        length = (httpVar->len > 150) ? 150 : httpVar->len;
        memcpy(varLenTemp, httpVar->buf, length);
        id = HTTPSETCOOKIE;
        if (mysql_stmt_execute(stmt_http)) {
            fprintf(stderr, " mysql_stmt_execute failed http\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_http));
            return FALSE;
        }
    }
    fbBasicListClear(&(httprec->httpSetCookie));

    return TRUE;
}




gboolean yfMyPOP3Insert(
    MYSQL *conn,
    yfPOP3Flow_t *pop3flow,
    uint16_t tmplID,
    uint64_t flowID)
{


    fbVarfield_t *pop3Var = NULL;
    int w, i;
    static MYSQL_STMT *stmt_pop3;
    MYSQL_BIND bind_pop3[3];
    int pcount;
    char varLenTemp[250];
    size_t length;
    uint16_t id;

    if (!stmt_pop3) {
        stmt_pop3 = mysql_stmt_init(conn);
        if (!stmt_pop3) {
            printf("MySQL out of Memory Error for POP3\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_pop3, INSERT_POP3, strlen(INSERT_POP3))) {
            printf("MySQL Prepare POP3 Statement Failed %s\n",
                   mysql_stmt_error(stmt_pop3));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_pop3);
        if (pcount != 3) {
            printf("Invalid POP3 Param Count returned by MySQL\n");
            return FALSE;
        }

    }
    memset(bind_pop3, 0, sizeof(bind_pop3));
    for (i = 0; i < 3; i++) {
        bind_pop3[i].is_null = 0;
        bind_pop3[i].is_unsigned = 1;
    }

    bind_pop3[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_pop3[0].buffer = (char *)&flowID;
    bind_pop3[0].length = 0;
    bind_pop3[1].buffer_type = MYSQL_TYPE_SHORT;
    bind_pop3[1].buffer = (char *)&id;
    bind_pop3[1].length = 0;
    bind_pop3[2].buffer_type = MYSQL_TYPE_STRING;
    bind_pop3[2].buffer = (char *)varLenTemp;
    bind_pop3[2].length = (unsigned long *)&length;

    if (mysql_stmt_bind_param(stmt_pop3, bind_pop3)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_pop3));
        return FALSE;
    }

    for (w = 0;(pop3Var = (fbVarfield_t *)FBBLNEXT(&(pop3flow->pop3msg), w)); w++)
    {
        length = (pop3Var->len > 150) ? 150 : pop3Var->len;
        memcpy(varLenTemp, pop3Var->buf, length);
        id = POP3MSG;
        if (mysql_stmt_execute(stmt_pop3)) {
            fprintf(stderr, " mysql_stmt_execute failed pop3\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_pop3));
            return FALSE;
        }
    }
    fbBasicListClear(&(pop3flow->pop3msg));

    return TRUE;
}

gboolean yfMyIRCInsert(
    MYSQL *conn,
    yfIRCFlow_t *ircflow,
    uint16_t tmplID,
    uint64_t flowID)
{

    fbVarfield_t *ircVar = NULL;
    int w, i;
    static MYSQL_STMT *stmt_irc;
    MYSQL_BIND bind_irc[3];
    int pcount;
    char varLenTemp[250];
    size_t length;
    uint16_t id;

    if (!stmt_irc) {
        stmt_irc = mysql_stmt_init(conn);
        if (!stmt_irc) {
            printf("MySQL out of Memory Error for IRC\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_irc, INSERT_IRC, strlen(INSERT_IRC))) {
            printf("MySQL Prepare IRC Statement Failed %s\n",
                   mysql_stmt_error(stmt_irc));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_irc);
        if (pcount != 3) {
            printf("Invalid IRC Param Count returned by MySQL\n");
            return FALSE;
        }
    }

    memset(bind_irc, 0, sizeof(bind_irc));
    for (i = 0; i < 3; i++) {
        bind_irc[i].is_null = 0;
        bind_irc[i].is_unsigned = 1;
    }

    bind_irc[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_irc[0].buffer = (char *)&flowID;
    bind_irc[0].length = 0;
    bind_irc[1].buffer_type = MYSQL_TYPE_SHORT;
    bind_irc[1].buffer = (char *)&id;
    bind_irc[1].length = 0;
    bind_irc[2].buffer_type = MYSQL_TYPE_STRING;
    bind_irc[2].buffer = (char *)varLenTemp;
    bind_irc[2].length = (unsigned long *)&length;

    if (mysql_stmt_bind_param(stmt_irc, bind_irc)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_irc));
        return FALSE;
    }

    for (w = 0;(ircVar = (fbVarfield_t *)FBBLNEXT(&(ircflow->ircMsg), \
                                                                      w)); w++)
    {
        length = (ircVar->len > 150) ? 150 : ircVar->len;
        memcpy(varLenTemp, ircVar->buf, length);
        id = IRCMSG;
        if (mysql_stmt_execute(stmt_irc)) {
            fprintf(stderr, " mysql_stmt_execute failed irc\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_irc));
            return FALSE;
        }
    }
    fbBasicListClear(&(ircflow->ircMsg));

    return TRUE;
}

gboolean yfMyTFTPInsert(
    MYSQL *conn,
    yfTFTPFlow_t *tftpflow,
    uint16_t tmplID,
    uint64_t flowID)
{

    int w, i;
    static MYSQL_STMT *stmt_tftp;
    MYSQL_BIND bind_tftp[3];
    int pcount;
    char varLenTemp[100];
    char varLenMode[50];
    size_t length2;
    size_t length;

    if (!stmt_tftp) {
        stmt_tftp = mysql_stmt_init(conn);
        if (!stmt_tftp) {
            printf("MySQL out of Memory Error for TFTP\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_tftp, INSERT_TFTP, strlen(INSERT_TFTP))) {
            printf("MySQL Prepare TFTP Statement Failed %s\n",
                   mysql_stmt_error(stmt_tftp));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_tftp);
        if (pcount != 3) {
            printf("Invalid TFTP Param Count returned by MySQL\n");
            return FALSE;
        }
    }
    memset(bind_tftp, 0, sizeof(bind_tftp));
    for (i = 0; i < 3; i++) {
        bind_tftp[i].is_null = 0;
        bind_tftp[i].is_unsigned = 1;
    }

    bind_tftp[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_tftp[0].buffer = (char *)&flowID;
    bind_tftp[0].length = 0;
    bind_tftp[1].buffer_type = MYSQL_TYPE_STRING;
    bind_tftp[1].buffer = (char *)varLenTemp;
    bind_tftp[1].length = 0;
    bind_tftp[2].buffer_type = MYSQL_TYPE_STRING;
    bind_tftp[2].buffer = (char *)varLenMode;
    bind_tftp[2].length = (unsigned long *)&length;

    if (mysql_stmt_bind_param(stmt_tftp, bind_tftp)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_tftp));
        return FALSE;
    }

    if (tftpflow->tftpFilename.buf) {
        length = (tftpflow->tftpFilename.len > 50) ? 50 : tftpflow->tftpFilename.len;
        memcpy(varLenTemp, tftpflow->tftpFilename.buf, length);
    } else { length = 0; }
    if (tftpflow->tftpMode.buf) {
        length2 = (tftpflow->tftpMode.len > 25) ? 25: tftpflow->tftpMode.len;
        memcpy(varLenMode, tftpflow->tftpMode.buf, length2);
    } else { length2 = 0; }

    if (mysql_stmt_execute(stmt_tftp)) {
        fprintf(stderr, " mysql_stmt_execute failed tftp\n");
        fprintf(stderr, " %s\n", mysql_stmt_error(stmt_tftp));
        return FALSE;
    }

    return TRUE;
}

gboolean yfMySLPInsert(
    MYSQL *conn,
    yfSLPFlow_t *slpflow,
    uint16_t tmplID,
    uint64_t flowID)
{
    fbVarfield_t *slpVar = NULL;
    int w, i;
    static MYSQL_STMT *stmt_slp;
    MYSQL_BIND bind_slp[5];
    int pcount;
    char varLenTemp[250];
    size_t length;
    uint16_t id;

    if (!stmt_slp) {
        stmt_slp = mysql_stmt_init(conn);
        if (!stmt_slp) {
            printf("MySQL out of Memory Error for SLP\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_slp, INSERT_SLP, strlen(INSERT_SLP))) {
            printf("MySQL Prepare SLP Statement Failed %s\n",
                   mysql_stmt_error(stmt_slp));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_slp);
        if (pcount != 5) {
            printf("Invalid SLP Param Count returned by MySQL\n");
            return FALSE;
        }
    }

    memset(bind_slp, 0, sizeof(bind_slp));
    for (i = 0; i < 5; i++) {
        bind_slp[i].is_null = 0;
        bind_slp[i].is_unsigned = 1;
    }

    bind_slp[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_slp[0].buffer = (char *)&flowID;
    bind_slp[0].length = 0;
    bind_slp[1].buffer_type = MYSQL_TYPE_TINY;
    bind_slp[1].buffer = (char *)&(slpflow->slpVersion);
    bind_slp[1].length = 0;
    bind_slp[2].buffer_type = MYSQL_TYPE_TINY;
    bind_slp[2].buffer = (char *)&(slpflow->slpMessageType);
    bind_slp[2].length = 0;
    bind_slp[3].buffer_type = MYSQL_TYPE_SHORT;
    bind_slp[3].buffer = (char *)&id;
    bind_slp[3].length = 0;
    bind_slp[4].buffer_type = MYSQL_TYPE_STRING;
    bind_slp[4].buffer = (char *)varLenTemp;
    bind_slp[4].length = (unsigned long *)&length;


    if (mysql_stmt_bind_param(stmt_slp, bind_slp)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_slp));
        return FALSE;
    }

    for (w =0;(slpVar = (fbVarfield_t *)FBBLNEXT(&(slpflow->slpString),\
                                                                      w)); w++)
    {
        length = (slpVar->len > 150) ? 150 : slpVar->len;
        memcpy(varLenTemp, slpVar->buf, length);
        id = SLPSTRING;
        if (mysql_stmt_execute(stmt_slp)) {
            fprintf(stderr, " mysql_stmt_execute failed slp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_slp));
            return FALSE;
        }
    }

    fbBasicListClear(&(slpflow->slpString));

    return TRUE;
}

gboolean yfMyFTPInsert(
    MYSQL *conn,
    yfFTPFlow_t *ftpflow,
    uint16_t tmplID,
    uint64_t flowID)
{
    fbVarfield_t *ftpVar = NULL;
    int w, i;
    static MYSQL_STMT *stmt_ftp;
    MYSQL_BIND bind_ftp[3];
    int pcount;
    char varLenTemp[250];
    size_t length;
    uint16_t id;


    if (!stmt_ftp) {
        stmt_ftp = mysql_stmt_init(conn);
        if (!stmt_ftp) {
            printf("MySQL out of Memory Error for FTP\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_ftp, INSERT_FTP, strlen(INSERT_FTP))) {
            printf("MySQL Prepare FTP Statement Failed %s\n",
                   mysql_stmt_error(stmt_ftp));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_ftp);
        if (pcount != 3) {
            printf("Invalid FTP Param Count returned by MySQL\n");
            return FALSE;
        }
    }

    memset(bind_ftp, 0, sizeof(bind_ftp));
    for (i = 0; i < 3; i++) {
        bind_ftp[i].is_null = 0;
        bind_ftp[i].is_unsigned = 1;
    }

    bind_ftp[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_ftp[0].buffer = (char *)&flowID;
    bind_ftp[0].length = 0;
    bind_ftp[1].buffer_type = MYSQL_TYPE_SHORT;
    bind_ftp[1].buffer = (char *)&id;
    bind_ftp[1].length = 0;
    bind_ftp[2].buffer_type = MYSQL_TYPE_STRING;
    bind_ftp[2].buffer = (char *)varLenTemp;
    bind_ftp[2].length = (unsigned long *)&length;

    if (mysql_stmt_bind_param(stmt_ftp, bind_ftp)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_ftp));
        return FALSE;
    }

    for (w=0;(ftpVar = (fbVarfield_t *)FBBLNEXT(&(ftpflow->ftpReturn), w)); w++) {
        id = FTPRETURN;
        length = (ftpVar->len > 150) ? 150 : ftpVar->len;
        memcpy(varLenTemp, ftpVar->buf, length);
        if (mysql_stmt_execute(stmt_ftp)) {
            fprintf(stderr, " mysql_stmt_execute failed ftp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_ftp));
            return FALSE;
        }
    }
    fbBasicListClear(&(ftpflow->ftpReturn));

    for (w=0;(ftpVar = (fbVarfield_t *)FBBLNEXT(&(ftpflow->ftpUser), w));w++) {
        id = FTPUSER;
        length = (ftpVar->len > 150) ? 150 : ftpVar->len;
        memcpy(varLenTemp, ftpVar->buf, length);
        if (mysql_stmt_execute(stmt_ftp)) {
            fprintf(stderr, " mysql_stmt_execute failed ftp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_ftp));
            return FALSE;
        }
    }
    fbBasicListClear(&(ftpflow->ftpUser));

    for (w=0;(ftpVar = (fbVarfield_t *)FBBLNEXT(&(ftpflow->ftpPass), w));w++) {
        id = FTPPASS;
        length = (ftpVar->len > 150) ? 150 : ftpVar->len;
        memcpy(varLenTemp, ftpVar->buf, length);
        if (mysql_stmt_execute(stmt_ftp)) {
            fprintf(stderr, " mysql_stmt_execute failed ftp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_ftp));
            return FALSE;
        }
    }
    fbBasicListClear(&(ftpflow->ftpPass));

    for (w=0;(ftpVar = (fbVarfield_t *)FBBLNEXT(&(ftpflow->ftpType), w)); w++)
    {
        id = FTPTYPE;
        length = (ftpVar->len > 150) ? 150 : ftpVar->len;
        memcpy(varLenTemp, ftpVar->buf, length);
        if (mysql_stmt_execute(stmt_ftp)) {
            fprintf(stderr, " mysql_stmt_execute failed ftp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_ftp));
            return FALSE;
        }
    }
    fbBasicListClear(&(ftpflow->ftpType));

    for (w=0;(ftpVar = (fbVarfield_t *)FBBLNEXT(&(ftpflow->ftpRespCode), w)); w++) {
        id = FTPRESPCODE;
        length = (ftpVar->len > 150) ? 150 : ftpVar->len;
        memcpy(varLenTemp, ftpVar->buf, length);
        if (mysql_stmt_execute(stmt_ftp)) {
            fprintf(stderr, " mysql_stmt_execute failed ftp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_ftp));
            return FALSE;
        }
    }
    fbBasicListClear(&(ftpflow->ftpRespCode));

    return TRUE;
}

gboolean yfMyIMAPInsert(
    MYSQL *conn,
    yfIMAPFlow_t *imapflow,
    uint16_t tmplID,
    uint64_t flowID)
{
    fbVarfield_t *imapVar = NULL;
    int w, i;
    static MYSQL_STMT *stmt_imap;
    MYSQL_BIND bind_imap[3];
    int pcount;
    char varLenTemp[250];
    size_t length;
    uint16_t id;


    if (!stmt_imap) {
        stmt_imap = mysql_stmt_init(conn);
        if (!stmt_imap) {
            printf("MySQL out of Memory Error for IMAP\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_imap, INSERT_IMAP, strlen(INSERT_IMAP))) {
            printf("MySQL Prepare IMAP Statement Failed %s\n",
                   mysql_stmt_error(stmt_imap));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_imap);
        if (pcount != 3) {
            printf("Invalid IMAP Param Count returned by MySQL\n");
            return FALSE;
        }
    }

    memset(bind_imap, 0, sizeof(bind_imap));
    for (i = 0; i < 3; i++) {
        bind_imap[i].is_null = 0;
        bind_imap[i].is_unsigned = 1;
    }

    bind_imap[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_imap[0].buffer = (char *)&flowID;
    bind_imap[0].length = 0;
    bind_imap[1].buffer_type = MYSQL_TYPE_SHORT;
    bind_imap[1].buffer = (char *)&id;
    bind_imap[1].length = 0;
    bind_imap[2].buffer_type = MYSQL_TYPE_STRING;
    bind_imap[2].buffer = (char *)varLenTemp;
    bind_imap[2].length = (unsigned long *)&length;

    if (mysql_stmt_bind_param(stmt_imap, bind_imap)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_imap));
        return FALSE;

    }
    for (w=0;(imapVar = (fbVarfield_t *)FBBLNEXT(&(imapflow->imapCapability), w)); w++) {
        id = IMAPCAPABILITY;
        length = (imapVar->len > 150) ? 150 : imapVar->len;
        memcpy(varLenTemp, imapVar->buf, length);
        if (mysql_stmt_execute(stmt_imap)) {
            fprintf(stderr, " mysql_stmt_execute failed imap\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_imap));
            return FALSE;
        }
    }
    fbBasicListClear(&(imapflow->imapCapability));

    for (w=0;(imapVar = (fbVarfield_t *)FBBLNEXT(&(imapflow->imapLogin), w)); w++)
    {
        id = IMAPLOGIN;
        length = (imapVar->len > 150) ? 150 : imapVar->len;
        memcpy(varLenTemp, imapVar->buf, length);
        if (mysql_stmt_execute(stmt_imap)) {
            fprintf(stderr, " mysql_stmt_execute failed imap\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_imap));
            return FALSE;
        }
    }
    fbBasicListClear(&(imapflow->imapLogin));

    for (w=0;(imapVar = (fbVarfield_t *)FBBLNEXT(&(imapflow->imapStartTLS), w)); w++) {
        id = IMAPSTARTTLS;
        length = (imapVar->len > 150) ? 150 : imapVar->len;
        memcpy(varLenTemp, imapVar->buf, length);
        if (mysql_stmt_execute(stmt_imap)) {
            fprintf(stderr, " mysql_stmt_execute failed imap\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_imap));
            return FALSE;
        }
    }
    fbBasicListClear(&(imapflow->imapStartTLS));

    for (w=0;(imapVar = (fbVarfield_t *)FBBLNEXT(&(imapflow->imapAuthenticate), w)); w++) {
        id = IMAPAUTHENTICATE;
        length = (imapVar->len > 150) ? 150 : imapVar->len;
        memcpy(varLenTemp, imapVar->buf, length);
        if (mysql_stmt_execute(stmt_imap)) {
            fprintf(stderr, " mysql_stmt_execute failed imap\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_imap));
            return FALSE;
        }
    }
    fbBasicListClear(&(imapflow->imapAuthenticate));

    for (w=0;(imapVar = (fbVarfield_t *)FBBLNEXT(&(imapflow->imapCommand),w)); w++) {
        id = IMAPCOMMAND;
        length = (imapVar->len > 150) ? 150 : imapVar->len;
        memcpy(varLenTemp, imapVar->buf, length);
        if (mysql_stmt_execute(stmt_imap)) {
            fprintf(stderr, " mysql_stmt_execute failed imap\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_imap));
            return FALSE;
        }
    }

    fbBasicListClear(&(imapflow->imapCommand));
    for (w=0;(imapVar = (fbVarfield_t *)FBBLNEXT(&(imapflow->imapExists), w));w++)
    {
        id = IMAPEXISTS;
        length = (imapVar->len > 150) ? 150 : imapVar->len;
        memcpy(varLenTemp, imapVar->buf, length);
        if (mysql_stmt_execute(stmt_imap)) {
            fprintf(stderr, " mysql_stmt_execute failed imap\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_imap));
            return FALSE;
        }
    }
    fbBasicListClear(&(imapflow->imapExists));

    for (w=0;(imapVar = (fbVarfield_t *)FBBLNEXT(&(imapflow->imapRecent), w));w++)
    {
        id = IMAPRECENT;
        length = (imapVar->len > 150) ? 150 : imapVar->len;
        memcpy(varLenTemp, imapVar->buf, length);
        if (mysql_stmt_execute(stmt_imap)) {
            fprintf(stderr, " mysql_stmt_execute failed imap\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_imap));
            return FALSE;
        }
    }
    fbBasicListClear(&(imapflow->imapRecent));

    return TRUE;
}


gboolean yfMySIPInsert(
    MYSQL *conn,
    yfSIPFlow_t *sipflow,
    uint16_t tmplID,
    uint64_t flowID)
{
    int w, i;
    fbVarfield_t *sipVar = NULL;
    static MYSQL_STMT *stmt_sip;
    MYSQL_BIND bind_sip[3];
    int pcount;
    char varLenTemp[250];
    size_t length;
    uint16_t id;


    if (!stmt_sip) {
        stmt_sip = mysql_stmt_init(conn);
        if (!stmt_sip) {
            printf("MySQL out of Memory Error for SIP\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_sip, INSERT_SIP, strlen(INSERT_SIP))) {
            printf("MySQL Prepare SIP Statement Failed %s\n",
                   mysql_stmt_error(stmt_sip));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_sip);
        if (pcount != 3) {
            printf("Invalid SIP Param Count returned by MySQL\n");
            return FALSE;
        }
    }

    memset(bind_sip, 0, sizeof(bind_sip));
    for (i = 0; i < 3; i++) {
        bind_sip[i].is_null = 0;
        bind_sip[i].is_unsigned = 1;
    }

    bind_sip[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_sip[0].buffer = (char *)&flowID;
    bind_sip[0].length = 0;
    bind_sip[1].buffer_type = MYSQL_TYPE_SHORT;
    bind_sip[1].buffer = (char *)&id;
    bind_sip[1].length = 0;
    bind_sip[2].buffer_type = MYSQL_TYPE_STRING;
    bind_sip[2].buffer = (char *)varLenTemp;
    bind_sip[2].length = (unsigned long *)&length;

    if (mysql_stmt_bind_param(stmt_sip, bind_sip)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_sip));
        return FALSE;

    }

    for (w=0;(sipVar = (fbVarfield_t *)FBBLNEXT(&(sipflow->sipInvite), w)); w++) {
        id = SIPINVITE;
        length = (sipVar->len > 150) ? 150 : sipVar->len;
        memcpy(varLenTemp, sipVar->buf, length);
        if (mysql_stmt_execute(stmt_sip)) {
            fprintf(stderr, " mysql_stmt_execute failed sip\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_sip));
            return FALSE;
        }
    }

    fbBasicListClear(&(sipflow->sipInvite));
    for (w=0;(sipVar = (fbVarfield_t *)FBBLNEXT(&(sipflow->sipCommand), w)); w++) {
        id = SIPCOMMAND;
        length = (sipVar->len > 150) ? 150 : sipVar->len;
        memcpy(varLenTemp, sipVar->buf, length);
        if (mysql_stmt_execute(stmt_sip)) {
            fprintf(stderr, " mysql_stmt_execute failed sip\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_sip));
            return FALSE;
        }
    }
    fbBasicListClear(&(sipflow->sipCommand));

    for (w=0;(sipVar = (fbVarfield_t *)FBBLNEXT(&(sipflow->sipVia), w)); w++) {
        id = SIPVIA;
        length = (sipVar->len > 150) ? 150 : sipVar->len;
        memcpy(varLenTemp, sipVar->buf, length);
        if (mysql_stmt_execute(stmt_sip)) {
            fprintf(stderr, " mysql_stmt_execute failed sip\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_sip));
            return FALSE;
        }
    }
    fbBasicListClear(&(sipflow->sipVia));

    for (w=0;(sipVar = (fbVarfield_t *)FBBLNEXT(&(sipflow->sipMaxForwards), w)); w++) {
        id = SIPMAXFORWARDS;
        length = (sipVar->len > 150) ? 150 : sipVar->len;
        memcpy(varLenTemp, sipVar->buf, length);
        if (mysql_stmt_execute(stmt_sip)) {
            fprintf(stderr, " mysql_stmt_execute failed sip\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_sip));
            return FALSE;
        }
    }
    fbBasicListClear(&(sipflow->sipMaxForwards));

    for (w=0;(sipVar = (fbVarfield_t *)FBBLNEXT(&(sipflow->sipAddress), w)); w++) {
        id = SIPADDRESS;
        length = (sipVar->len > 150) ? 150 : sipVar->len;
        memcpy(varLenTemp, sipVar->buf, length);
        if (mysql_stmt_execute(stmt_sip)) {
            fprintf(stderr, " mysql_stmt_execute failed sip\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_sip));
            return FALSE;
        }
    }
    fbBasicListClear(&(sipflow->sipAddress));

    for (w=0;(sipVar = (fbVarfield_t *)FBBLNEXT(&(sipflow->sipContentLength), w)); w++) {
        id = SIPCONTENTLENGTH;
        length = (sipVar->len > 150) ? 150 : sipVar->len;
        memcpy(varLenTemp, sipVar->buf, length);
        if (mysql_stmt_execute(stmt_sip)) {
            fprintf(stderr, " mysql_stmt_execute failed sip\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_sip));
            return FALSE;
        }
    }
    fbBasicListClear(&(sipflow->sipContentLength));
    for (w=0;(sipVar = (fbVarfield_t *)FBBLNEXT(&(sipflow->sipUserAgent), w)); w++) {
        id = SIPUSERAGENT;
        length = (sipVar->len > 150) ? 150 : sipVar->len;
        memcpy(varLenTemp, sipVar->buf, length);
        if (mysql_stmt_execute(stmt_sip)) {
            fprintf(stderr, " mysql_stmt_execute failed sip\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_sip));
            return FALSE;
        }
    }
    fbBasicListClear(&(sipflow->sipUserAgent));

    return TRUE;
}

gboolean yfMySMTPInsert(
    MYSQL *conn,
    yfSMTPFlow_t *smtpflow,
    uint16_t tmplID,
    uint64_t flowID)
{

    int w, i;
    fbVarfield_t *smtpVar = NULL;
    static MYSQL_STMT *stmt_smtp;
    MYSQL_BIND bind_smtp[3];
    int pcount;
    char varLenTemp[250];
    size_t length;
    uint16_t id;


    if (!stmt_smtp) {
        stmt_smtp = mysql_stmt_init(conn);
        if (!stmt_smtp) {
            printf("MySQL out of Memory Error for SMTP\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_smtp, INSERT_SMTP, strlen(INSERT_SMTP))) {
            printf("MySQL Prepare SMTP Statement Failed %s\n",
                   mysql_stmt_error(stmt_smtp));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_smtp);
        if (pcount != 3) {
            printf("Invalid SMTP Param Count returned by MySQL\n");
            return FALSE;
        }
    }

    memset(bind_smtp, 0, sizeof(bind_smtp));
    for (i = 0; i < 3; i++) {
        bind_smtp[i].is_null = 0;
        bind_smtp[i].is_unsigned = 1;
    }

    bind_smtp[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_smtp[0].buffer = (char *)&flowID;
    bind_smtp[0].length = 0;
    bind_smtp[1].buffer_type = MYSQL_TYPE_SHORT;
    bind_smtp[1].buffer = (char *)&id;
    bind_smtp[1].length = 0;
    bind_smtp[2].buffer_type = MYSQL_TYPE_STRING;
    bind_smtp[2].buffer = (char *)varLenTemp;
    bind_smtp[2].length = (unsigned long *)&length;

    if (mysql_stmt_bind_param(stmt_smtp, bind_smtp)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_smtp));
        return FALSE;

    }


    for (w=0;(smtpVar = (fbVarfield_t *)FBBLNEXT(&(smtpflow->smtpHello), w)); w++) {
        id = SMTPHELLO;
        length = (smtpVar->len > 150) ? 150 : smtpVar->len;
        memcpy(varLenTemp, smtpVar->buf, length);
        if (mysql_stmt_execute(stmt_smtp)) {
            fprintf(stderr, " mysql_stmt_execute failed smtp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_smtp));
            return FALSE;
        }
    }
    fbBasicListClear(&(smtpflow->smtpHello));

    for (w=0;(smtpVar = (fbVarfield_t *)FBBLNEXT(&(smtpflow->smtpFrom), w)); w++) {
        id = SMTPFROM;
        length = (smtpVar->len > 150) ? 150 : smtpVar->len;
        memcpy(varLenTemp, smtpVar->buf, length);
        if (mysql_stmt_execute(stmt_smtp)) {
            fprintf(stderr, " mysql_stmt_execute failed smtp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_smtp));
            return FALSE;
        }
    }
    fbBasicListClear(&(smtpflow->smtpFrom));

    for (w=0;(smtpVar = (fbVarfield_t *)FBBLNEXT(&(smtpflow->smtpTo), w));w++) {
        id = SMTPTO;
        length = (smtpVar->len > 150) ? 150 : smtpVar->len;
        memcpy(varLenTemp, smtpVar->buf, length);
        if (mysql_stmt_execute(stmt_smtp)) {
            fprintf(stderr, " mysql_stmt_execute failed smtp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_smtp));
            return FALSE;
        }
    }
    fbBasicListClear(&(smtpflow->smtpTo));

    for (w=0;(smtpVar = (fbVarfield_t *)FBBLNEXT(&(smtpflow->smtpContentType), w)); w++) {
        id = SMTPCONTENTTYPE;
        length = (smtpVar->len > 150) ? 150 : smtpVar->len;
        memcpy(varLenTemp, smtpVar->buf, length);
        if (mysql_stmt_execute(stmt_smtp)) {
            fprintf(stderr, " mysql_stmt_execute failed smtp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_smtp));
            return FALSE;
        }
    }
    fbBasicListClear(&(smtpflow->smtpContentType));

    for (w=0;(smtpVar = (fbVarfield_t *)FBBLNEXT(&(smtpflow->smtpSubject),w)); w++) {
        id = SMTPSUBJECT;
        length = (smtpVar->len > 150) ? 150 : smtpVar->len;
        memcpy(varLenTemp, smtpVar->buf, length);
        if (mysql_stmt_execute(stmt_smtp)) {
            fprintf(stderr, " mysql_stmt_execute failed smtp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_smtp));
            return FALSE;
        }
    }
    fbBasicListClear(&(smtpflow->smtpSubject));

    for (w=0;(smtpVar = (fbVarfield_t *)FBBLNEXT(&(smtpflow->smtpFilename), w)); w++) {
        id = SMTPFILENAME;
        length = (smtpVar->len > 150) ? 150 : smtpVar->len;
        memcpy(varLenTemp, smtpVar->buf, length);
        if (mysql_stmt_execute(stmt_smtp)) {
            fprintf(stderr, " mysql_stmt_execute failed smtp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_smtp));
            return FALSE;
        }

    }
    fbBasicListClear(&(smtpflow->smtpFilename));

    for (w=0;(smtpVar = (fbVarfield_t *)FBBLNEXT(&(smtpflow->smtpContentDisposition), w)); w++) {
        id = SMTPCONTENTDISPOSITION;
        length = (smtpVar->len > 150) ? 150 : smtpVar->len;
        memcpy(varLenTemp, smtpVar->buf, length);
        if (mysql_stmt_execute(stmt_smtp)) {
            fprintf(stderr, " mysql_stmt_execute failed smtp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_smtp));
            return FALSE;
        }
    }
    fbBasicListClear(&(smtpflow->smtpContentDisposition));

    for (w=0;(smtpVar = (fbVarfield_t *)FBBLNEXT(&(smtpflow->smtpResponse), w)); w++) {
        id = SMTPRESPONSE;
        length = (smtpVar->len > 150) ? 150 : smtpVar->len;
        memcpy(varLenTemp, smtpVar->buf, length);
        if (mysql_stmt_execute(stmt_smtp)) {
            fprintf(stderr, " mysql_stmt_execute failed smtp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_smtp));
            return FALSE;
        }
    }
    fbBasicListClear(&(smtpflow->smtpResponse));

    for (w=0;(smtpVar = (fbVarfield_t *)FBBLNEXT(&(smtpflow->smtpEnhanced),w)); w++)
    {
        id = SMTPENHANCED;
        length = (smtpVar->len > 150) ? 150 : smtpVar->len;
        memcpy(varLenTemp, smtpVar->buf, length);
        if (mysql_stmt_execute(stmt_smtp)) {
            fprintf(stderr, " mysql_stmt_execute failed smtp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_smtp));
            return FALSE;
        }
    }
    fbBasicListClear(&(smtpflow->smtpEnhanced));

    return TRUE;
}

gboolean yfMySSHInsert(
    MYSQL *conn,
    yfSSHFlow_t *sshflow,
    uint16_t tmplID,
    uint64_t flowID)
{
    fbVarfield_t *sshVar = NULL;
    int w, i;
    static MYSQL_STMT *stmt_ssh;
    MYSQL_BIND bind_ssh[3];
    int pcount;
    char varLenTemp[150];
    size_t length;
    uint16_t id;


    if (!stmt_ssh) {
        stmt_ssh = mysql_stmt_init(conn);
        if (!stmt_ssh) {
            printf("MySQL out of Memory Error for SSH\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_ssh, INSERT_SSH, strlen(INSERT_SSH))) {
            printf("MySQL Prepare SSH Statement Failed %s\n",
                   mysql_stmt_error(stmt_ssh));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_ssh);
        if (pcount != 3) {
            printf("Invalid SSH Param Count returned by MySQL\n");
            return FALSE;
        }
    }

    memset(bind_ssh, 0, sizeof(bind_ssh));
    for (i = 0; i < 3; i++) {
        bind_ssh[i].is_null = 0;
        bind_ssh[i].is_unsigned = 1;
    }

    bind_ssh[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_ssh[0].buffer = (char *)&flowID;
    bind_ssh[0].length = 0;
    bind_ssh[1].buffer_type = MYSQL_TYPE_SHORT;
    bind_ssh[1].buffer = (char *)&id;
    bind_ssh[1].length = 0;
    bind_ssh[2].buffer_type = MYSQL_TYPE_STRING;
    bind_ssh[2].buffer = (char *)varLenTemp;
    bind_ssh[2].length = (unsigned long *)&length;

    if (mysql_stmt_bind_param(stmt_ssh, bind_ssh)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_ssh));
        return FALSE;

    }

    for (w=0;(sshVar = (fbVarfield_t *)FBBLNEXT(&(sshflow->sshVersion), w));w++)
    {
        id = SSHVERSION;
        length = (sshVar->len > 150) ? 150 : sshVar->len;
        memcpy(varLenTemp, sshVar->buf, length);
        if (mysql_stmt_execute(stmt_ssh)) {
            fprintf(stderr, " mysql_stmt_execute failed ssh\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_ssh));
            return FALSE;
        }
    }
    fbBasicListClear(&(sshflow->sshVersion));

    return TRUE;
}


gboolean yfMyNNTPInsert(
    MYSQL *conn,
    yfNNTPFlow_t *nntpflow,
    uint16_t tmplID,
    uint64_t flowID)
{
    int w, i;
    fbVarfield_t *nntpVar = NULL;
    static MYSQL_STMT *stmt_nntp;
    MYSQL_BIND bind_nntp[3];
    int pcount;
    char varLenTemp[250];
    size_t length;
    uint16_t id;


    if (!stmt_nntp) {
        stmt_nntp = mysql_stmt_init(conn);
        if (!stmt_nntp) {
            printf("MySQL out of Memory Error for NNTP\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_nntp, INSERT_NNTP, strlen(INSERT_NNTP))) {
            printf("MySQL Prepare NNTP Statement Failed %s\n",
                   mysql_stmt_error(stmt_nntp));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_nntp);
        if (pcount != 3) {
            printf("Invalid NNTP Param Count returned by MySQL\n");
            return FALSE;
        }
    }

    memset(bind_nntp, 0, sizeof(bind_nntp));
    for (i = 0; i < 3; i++) {
        bind_nntp[i].is_null = 0;
        bind_nntp[i].is_unsigned = 1;
    }

    bind_nntp[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_nntp[0].buffer = (char *)&flowID;
    bind_nntp[0].length = 0;
    bind_nntp[1].buffer_type = MYSQL_TYPE_SHORT;
    bind_nntp[1].buffer = (char *)&id;
    bind_nntp[1].length = 0;
    bind_nntp[2].buffer_type = MYSQL_TYPE_STRING;
    bind_nntp[2].buffer = (char *)varLenTemp;
    bind_nntp[2].length = (unsigned long *)&length;

    if (mysql_stmt_bind_param(stmt_nntp, bind_nntp)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_nntp));
        return FALSE;

    }

    for (w=0;(nntpVar = (fbVarfield_t *)FBBLNEXT(&(nntpflow->nntpResponse), w)); w++) {
        id = NNTPRESPONSE;
        length = (nntpVar->len > 150) ? 150 : nntpVar->len;
        memcpy(varLenTemp, nntpVar->buf, length);
        if (mysql_stmt_execute(stmt_nntp)) {
            fprintf(stderr, " mysql_stmt_execute failed nntp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_nntp));
            return FALSE;
        }
    }
    fbBasicListClear(&(nntpflow->nntpResponse));

    for (w=0;(nntpVar = (fbVarfield_t *)FBBLNEXT(&(nntpflow->nntpCommand),w)); w++) {
        id = NNTPCOMMAND;
        length = (nntpVar->len > 150) ? 150 : nntpVar->len;
        memcpy(varLenTemp, nntpVar->buf, length);
        if (mysql_stmt_execute(stmt_nntp)) {
            fprintf(stderr, " mysql_stmt_execute failed nttp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_nntp));
            return FALSE;
        }
    }
    fbBasicListClear(&(nntpflow->nntpCommand));

    return TRUE;
}


gboolean yfMySSLInsert(
    MYSQL *conn,
    yfSSLFlow_t *sslflow,
    uint16_t tmplID,
    uint64_t flowID)
{
    int w, i;
    static MYSQL_STMT *stmt_ssl;
    MYSQL_BIND bind_ssl[4];
    int pcount;

    if (!stmt_ssl) {
        stmt_ssl = mysql_stmt_init(conn);
        if (!stmt_ssl) {
            printf("MySQL out of Memory Error for SSL\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_ssl, INSERT_SSL, strlen(INSERT_SSL))) {
            printf("MySQL Prepare SSL Statement Failed %s\n",
                   mysql_stmt_error(stmt_ssl));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_ssl);
        if (pcount != 4) {
            printf("Invalid SSL Param Count returned by MySQL\n");
            return FALSE;
        }
    }

    memset(bind_ssl, 0, sizeof(bind_ssl));
    for (i = 0; i < 4; i++) {
        bind_ssl[i].is_null = 0;
        bind_ssl[i].is_unsigned = 1;
    }

    bind_ssl[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_ssl[0].buffer = (char *)&flowID;
    bind_ssl[0].length = 0;
    bind_ssl[1].buffer_type = MYSQL_TYPE_TINY;
    bind_ssl[1].buffer = (char *)&(sslflow->sslCompressionMethod);
    bind_ssl[1].length = 0;
    bind_ssl[2].buffer_type = MYSQL_TYPE_TINY;
    bind_ssl[2].buffer = (char *)&(sslflow->sslClientVersion);
    bind_ssl[2].length = 0;
    bind_ssl[3].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_ssl[3].buffer = (char *)&(sslflow->sslServerCipher);
    bind_ssl[3].length = 0;

    if (mysql_stmt_bind_param(stmt_ssl, bind_ssl)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_ssl));
        return FALSE;

    }

    if (mysql_stmt_execute(stmt_ssl)) {
        fprintf(stderr, "Fatal: mysql_stmt_execute() failled\n");
        fprintf(stderr, " %s\n", mysql_stmt_error(stmt_ssl));
        return FALSE;
    }

    return TRUE;

}

gboolean yfMySSLCertInsert(
    MYSQL *conn,
    yfSSLCertFlow_t *sslcert,
    uint16_t tmplID,
    uint64_t flowID,
    int w)
{

    int i;
    static MYSQL_STMT *stmt_sslcert;
    MYSQL_BIND bind_sslcert[20];
    int pcount;

    if (!stmt_sslcert) {
        stmt_sslcert = mysql_stmt_init(conn);
        if (!stmt_sslcert) {
            printf("MySQL out of Memory Error for SSLCERT\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_sslcert, INSERT_SSLCERT, strlen(INSERT_SSLCERT))) {
            printf("MySQL Prepare SSLCERT Statement Failed %s\n",
                   mysql_stmt_error(stmt_sslcert));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_sslcert);
        if (pcount != 20) {
            printf("Invalid SSLCERT Param Count returned by MySQL\n");
            return FALSE;
        }
    }

    memset(bind_sslcert, 0, sizeof(bind_sslcert));
    for (i = 0; i < 20; i++) {
        bind_sslcert[i].is_null = 0;
        bind_sslcert[i].is_unsigned = 1;
    }

    bind_sslcert[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_sslcert[0].buffer = (char *)&flowID;
    bind_sslcert[0].length = 0;
    bind_sslcert[1].buffer_type = MYSQL_TYPE_STRING;
    bind_sslcert[1].buffer = (char *)sslcert->sslSignature.buf;
    bind_sslcert[1].length = (unsigned long *)&(sslcert->sslSignature.len);
    bind_sslcert[2].buffer_type = MYSQL_TYPE_TINY;
    bind_sslcert[2].buffer = (char *)&(sslcert->sslVersion);
    bind_sslcert[2].length = 0;
    bind_sslcert[3].buffer_type = MYSQL_TYPE_TINY;
    bind_sslcert[3].buffer = (char *)&w;
    bind_sslcert[3].length = 0;
    bind_sslcert[4].buffer_type = MYSQL_TYPE_STRING;
    bind_sslcert[4].buffer = (char *)sslcert->sslICountryName.buf;
    bind_sslcert[4].length = (unsigned long *)&(sslcert->sslICountryName.len);
    bind_sslcert[5].buffer_type = MYSQL_TYPE_STRING;
    bind_sslcert[5].buffer = (char *)sslcert->sslIOrgName.buf;
    bind_sslcert[5].length = (unsigned long *)&(sslcert->sslIOrgName.len);
    bind_sslcert[6].buffer_type = MYSQL_TYPE_STRING;
    bind_sslcert[6].buffer = (char *)sslcert->sslIOrgUnitName.buf;
    bind_sslcert[6].length = (unsigned long *)&(sslcert->sslIOrgUnitName.len);
    bind_sslcert[7].buffer_type =MYSQL_TYPE_STRING;
    bind_sslcert[7].buffer = (char *)sslcert->sslIZipCode.buf;
    bind_sslcert[7].length = (unsigned long *)&(sslcert->sslIZipCode.len);
    bind_sslcert[8].buffer_type =MYSQL_TYPE_STRING;
    bind_sslcert[8].buffer = (char *)sslcert->sslIState.buf;
    bind_sslcert[8].length = (unsigned long *)&(sslcert->sslIState.len);
    bind_sslcert[9].buffer_type =MYSQL_TYPE_STRING;
    bind_sslcert[9].buffer = (char *)sslcert->sslICommonName.buf;
    bind_sslcert[9].length = (unsigned long *)&(sslcert->sslICommonName.len);
    bind_sslcert[10].buffer_type =MYSQL_TYPE_STRING;
    bind_sslcert[10].buffer = (char *)sslcert->sslILocalityName.buf;
    bind_sslcert[10].length = (unsigned long *)&(sslcert->sslILocalityName.len);
    bind_sslcert[11].buffer_type =MYSQL_TYPE_STRING;
    bind_sslcert[11].buffer = (char *)sslcert->sslIStreetAddress.buf;
    bind_sslcert[11].length = (unsigned long *)&(sslcert->sslIStreetAddress.len);
    bind_sslcert[12].buffer_type = MYSQL_TYPE_STRING;
    bind_sslcert[12].buffer = (char *)sslcert->sslSCountryName.buf;
    bind_sslcert[12].length = (unsigned long *)&(sslcert->sslSCountryName.len);
    bind_sslcert[13].buffer_type = MYSQL_TYPE_STRING;
    bind_sslcert[13].buffer = (char *)sslcert->sslSOrgName.buf;
    bind_sslcert[13].length = (unsigned long *)&(sslcert->sslSOrgName.len);
    bind_sslcert[14].buffer_type = MYSQL_TYPE_STRING;
    bind_sslcert[14].buffer = (char *)sslcert->sslSOrgUnitName.buf;
    bind_sslcert[14].length = (unsigned long *)&(sslcert->sslSOrgUnitName.len);
    bind_sslcert[15].buffer_type =MYSQL_TYPE_STRING;
    bind_sslcert[15].buffer = (char *)sslcert->sslSZipCode.buf;
    bind_sslcert[15].length = (unsigned long *)&(sslcert->sslSZipCode.len);
    bind_sslcert[16].buffer_type =MYSQL_TYPE_STRING;
    bind_sslcert[16].buffer = (char *)sslcert->sslSState.buf;
    bind_sslcert[16].length = (unsigned long *)&(sslcert->sslSState.len);
    bind_sslcert[17].buffer_type =MYSQL_TYPE_STRING;
    bind_sslcert[17].buffer = (char *)sslcert->sslSCommonName.buf;
    bind_sslcert[17].length = (unsigned long *)&(sslcert->sslSCommonName.len);
    bind_sslcert[18].buffer_type =MYSQL_TYPE_STRING;
    bind_sslcert[18].buffer = (char *)sslcert->sslSLocalityName.buf;
    bind_sslcert[18].length = (unsigned long *)&(sslcert->sslSLocalityName.len);
    bind_sslcert[19].buffer_type =MYSQL_TYPE_STRING;
    bind_sslcert[19].buffer = (char *)sslcert->sslSStreetAddress.buf;
    bind_sslcert[19].length = (unsigned long *)&(sslcert->sslSStreetAddress.len);


    if (mysql_stmt_bind_param(stmt_sslcert, bind_sslcert)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_sslcert));
        return FALSE;

    }


    if (mysql_stmt_execute(stmt_sslcert)) {
        printf("Fatal: mysql_stmt_execute() failed sslcert\n");
        printf(" %s\n", mysql_stmt_error(stmt_sslcert));
        return FALSE;
    }

    return TRUE;
}

gboolean yfMyDNSInsert(
    MYSQL *conn,
    yfDNSFlow_t *dnsflow,
    uint16_t tmplID,
    uint64_t flowID)
{
    char rrname[260];
    char rrval[260];
    size_t length;
    size_t val_len;
    yfDNSQRFlow_t *dnsqrflow = NULL;
    int i, w;
    static MYSQL_STMT *stmt_dns;
    MYSQL_BIND bind_dns[10];
    int pcount;
    uint16_t type;
    uint8_t  auth;
    uint8_t  nxdomain;
    uint8_t  section;
    uint32_t ttl;
    uint16_t tid;
    uint8_t  qr;

    if (!stmt_dns) {
        stmt_dns = mysql_stmt_init(conn);
        if (!stmt_dns) {
            printf("MySQL out of Memory Error for DNS\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_dns, INSERT_DNS, strlen(INSERT_DNS))) {
            printf("MySQL Prepare DNS Statement Failed %s\n",
                   mysql_stmt_error(stmt_dns));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_dns);
        if (pcount != 10) {
            printf("Invalid DNS Param Count returned by MySQL\n");
            return FALSE;
        }
    }

    memset(bind_dns, 0, sizeof(bind_dns));
    for (i = 0; i < 10; i++) {
        bind_dns[i].is_null = 0;
        bind_dns[i].is_unsigned = 1;
    }

    bind_dns[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_dns[0].buffer = (char *)&flowID;
    bind_dns[0].length = 0;
    bind_dns[1].buffer_type = MYSQL_TYPE_SHORT;
    bind_dns[1].buffer = (char *)&tid;
    bind_dns[1].length = 0;
    bind_dns[2].buffer_type = MYSQL_TYPE_TINY;
    bind_dns[2].buffer = (char *)&qr;
    bind_dns[2].length = 0;
    bind_dns[3].buffer_type = MYSQL_TYPE_SHORT;
    bind_dns[3].buffer = (char *)&type;
    bind_dns[3].length = 0;
    bind_dns[4].buffer_type = MYSQL_TYPE_TINY;
    bind_dns[4].buffer = (char *)&auth;
    bind_dns[4].length = 0;
    bind_dns[5].buffer_type = MYSQL_TYPE_TINY;
    bind_dns[5].buffer = (char *)&nxdomain;
    bind_dns[5].length = 0;
    bind_dns[6].buffer_type = MYSQL_TYPE_TINY;
    bind_dns[6].buffer = (char *)&section;
    bind_dns[6].length = 0;
    bind_dns[7].buffer_type = MYSQL_TYPE_LONG;
    bind_dns[7].buffer = (char *)&ttl;
    bind_dns[7].length = 0;
    bind_dns[8].buffer_type = MYSQL_TYPE_STRING;
    bind_dns[8].buffer = (char *)rrname;
    bind_dns[8].length = (unsigned long *)&length;
    bind_dns[9].buffer_type = MYSQL_TYPE_STRING;
    bind_dns[9].buffer = (char *)&rrval;
    bind_dns[9].length = (unsigned long *)&val_len;


    if (mysql_stmt_bind_param(stmt_dns, bind_dns)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_dns));
        return FALSE;

    }

    while ((dnsqrflow =
            (yfDNSQRFlow_t *)FBSTLNEXT(&(dnsflow->dnsQRList), dnsqrflow)))
    {
        type = (dnsqrflow->dnsQRType);
        auth = (dnsqrflow->dnsAuthoritative);
        nxdomain = (dnsqrflow->dnsNXDomain);
        section = (dnsqrflow->dnsRRSection);
        ttl = (dnsqrflow->dnsTTL);
        tid = (dnsqrflow->dnsID);
        qr = (dnsqrflow->dnsQueryResponse);
        val_len = 0;

        if (dnsqrflow->dnsQueryResponse) {
            length = dnsqrflow->dnsQName.len;
            memcpy(rrname, dnsqrflow->dnsQName.buf, length);
            if (dnsqrflow->dnsQRType == 1) {
                yfDNSAFlow_t *aflow = NULL;
                while ((aflow = (yfDNSAFlow_t *)
                        FBSTLNEXT(&(dnsqrflow->rrlist), aflow)))
                {
                    printIPAddress(rrval, aflow->ip);
                    val_len = strlen(rrval);
                }
                fbSubTemplateListClear(&(dnsqrflow->rrlist));
            } else if (dnsqrflow->dnsQRType == 2) {
                yfDNSNSFlow_t *nsflow  = NULL;
                while ((nsflow = (yfDNSNSFlow_t *)
                        FBSTLNEXT(&(dnsqrflow->rrlist), nsflow)))
                {
                    val_len = nsflow->nsdname.len;
                    memcpy(rrval, nsflow->nsdname.buf, val_len);
                }
                fbSubTemplateListClear(&(dnsqrflow->rrlist));
            } else if (dnsqrflow->dnsQRType == 5) {
                yfDNSCNameFlow_t *cflow = NULL;
                while ((cflow =
                        (yfDNSCNameFlow_t *)FBSTLNEXT(&(dnsqrflow->rrlist),
                                                      cflow)))
                {
                    val_len = cflow->cname.len;
                    memcpy(rrval, cflow->cname.buf, val_len);
                }
                fbSubTemplateListClear(&(dnsqrflow->rrlist));
            } else if (dnsqrflow->dnsQRType == 12) {
                yfDNSPTRFlow_t *ptrflow = NULL;
                while ((ptrflow =
                        (yfDNSPTRFlow_t *)FBSTLNEXT(&(dnsqrflow->rrlist),
                                                    ptrflow)))
                {
                    val_len = ptrflow->ptrdname.len;
                    memcpy(rrval, ptrflow->ptrdname.buf, val_len);
                }
                fbSubTemplateListClear(&(dnsqrflow->rrlist));
            } else if (dnsqrflow->dnsQRType == 15) {
                yfDNSMXFlow_t *mx = NULL;
                while ((mx =
                        (yfDNSMXFlow_t *)FBSTLNEXT(&(dnsqrflow->rrlist), mx)))
                {
                    val_len = mx->exchange.len;
                    memcpy(rrval, mx->exchange.buf, val_len);
                }
                fbSubTemplateListClear(&(dnsqrflow->rrlist));
            } else if (dnsqrflow->dnsQRType == 28) {
                yfDNSAAAAFlow_t *aa = NULL;
                char ipaddr_buf[40];
                while ((aa =
                       (yfDNSAAAAFlow_t *)FBSTLNEXT(&(dnsqrflow->rrlist), aa)))
                {
                    printIP6Address(rrval, aa->ip);
                    val_len = strlen(rrval);
                }
                fbSubTemplateListClear(&(dnsqrflow->rrlist));
            } else if (dnsqrflow->dnsQRType == 16) {
              yfDNSTXTFlow_t *txt = NULL;
              while ((txt =
                      (yfDNSTXTFlow_t *)FBSTLNEXT(&(dnsqrflow->rrlist), txt)))
              {
                  val_len = txt->txt_data.len;
                  memcpy(rrval, txt->txt_data.buf, txt->txt_data.len);
              }
              fbSubTemplateListClear(&(dnsqrflow->rrlist));
            } else if (dnsqrflow->dnsQRType == 33) {
                yfDNSSRVFlow_t *srv = NULL;
                while ((srv =
                       (yfDNSSRVFlow_t *)FBSTLNEXT(&(dnsqrflow->rrlist), srv)))
                {
                    val_len = srv->dnsTarget.len;
                    memcpy(rrval, srv->dnsTarget.buf, val_len);
                }
                fbSubTemplateListClear(&(dnsqrflow->rrlist));
            } else if (dnsqrflow->dnsQRType == 6) {
                yfDNSSOAFlow_t *soa = NULL;
                while ((soa =
                       (yfDNSSOAFlow_t *)FBSTLNEXT(&(dnsqrflow->rrlist), soa)))
                {
                    val_len = soa->mname.len;
                    memcpy(rrval, soa->mname.buf, val_len);
                }
                fbSubTemplateListClear(&(dnsqrflow->rrlist));
            } else {
                FBSTLNEXT(&(dnsqrflow->rrlist), NULL);
                fbSubTemplateListClear(&(dnsqrflow->rrlist));
            }


        } else {
            /* this is a query */
            if (dnsqrflow->dnsQName.buf) {
                length = dnsqrflow->dnsQName.len;
                memcpy(rrname, dnsqrflow->dnsQName.buf, length);
                val_len = 0;
            } else {
                length = 0;
                val_len = 0;
            }
        }

        if (mysql_stmt_execute(stmt_dns)) {
            fprintf(stderr, "mysql_stmt_execute failed for dns\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_dns));
            return FALSE;
        }

    }

    fbSubTemplateListClear(&(dnsflow->dnsQRList));
    dnsqrflow=NULL;

    return TRUE;
}

gboolean yfMyRTSPInsert(
    MYSQL *conn,
    yfRTSPFlow_t *rtspflow,
    uint16_t tmplID,
    uint64_t flowID)
{
    fbVarfield_t *rtspVar = NULL;
    int w, i;
    static MYSQL_STMT *stmt_rtsp;
    MYSQL_BIND bind_rtsp[3];
    int pcount;
    char varLenTemp[250];
    size_t length;
    uint16_t id;

    if (!stmt_rtsp) {
        stmt_rtsp = mysql_stmt_init(conn);
        if (!stmt_rtsp) {
            printf("MySQL out of Memory Error for RTSP\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_rtsp, INSERT_RTSP, strlen(INSERT_RTSP))) {
            printf("MySQL Prepare RTSP Statement Failed %s\n",
                   mysql_stmt_error(stmt_rtsp));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_rtsp);
        if (pcount != 3) {
            printf("Invalid RTSP Param Count returned by MySQL\n");
            return FALSE;
        }

    }
    memset(bind_rtsp, 0, sizeof(bind_rtsp));
    for (i = 0; i < 3; i++) {
        bind_rtsp[i].is_null = 0;
        bind_rtsp[i].is_unsigned = 1;
    }

    bind_rtsp[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_rtsp[0].buffer = (char *)&flowID;
    bind_rtsp[0].length = 0;
    bind_rtsp[1].buffer_type = MYSQL_TYPE_SHORT;
    bind_rtsp[1].buffer = (char *)&id;
    bind_rtsp[1].length = 0;
    bind_rtsp[2].buffer_type = MYSQL_TYPE_STRING;
    bind_rtsp[2].buffer = (char *)varLenTemp;
    bind_rtsp[2].length = (unsigned long *)&length;

    if (mysql_stmt_bind_param(stmt_rtsp, bind_rtsp)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_rtsp));
        return FALSE;
    }

    for (w=0;(rtspVar = (fbVarfield_t *)FBBLNEXT(&(rtspflow->rtspURL), w)); w++)
    {
        length = (rtspVar->len > 150) ? 150 : rtspVar->len;
        memcpy(varLenTemp, rtspVar->buf, length);
        id = RTSPURL;
        if (mysql_stmt_execute(stmt_rtsp)) {
            fprintf(stderr, " mysql_stmt_execute failed rtsp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_rtsp));
            return FALSE;
        }
    }
    fbBasicListClear(&(rtspflow->rtspURL));

    for (w=0;(rtspVar = (fbVarfield_t *)FBBLNEXT(&(rtspflow->rtspVersion), w)); w++)
    {
        length = (rtspVar->len > 150) ? 150 : rtspVar->len;
        memcpy(varLenTemp, rtspVar->buf, length);
        id = RTSPVERSION;
        if (mysql_stmt_execute(stmt_rtsp)) {
            fprintf(stderr, " mysql_stmt_execute failed rtsp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_rtsp));
            return FALSE;
        }
    }
    fbBasicListClear(&(rtspflow->rtspVersion));

    for (w=0;(rtspVar = (fbVarfield_t *)FBBLNEXT(&(rtspflow->rtspReturnCode), w)); w++)
    {
        length = (rtspVar->len > 150) ? 150 : rtspVar->len;
        memcpy(varLenTemp, rtspVar->buf, length);
        id = RTSPRETURNCODE;
        if (mysql_stmt_execute(stmt_rtsp)) {
            fprintf(stderr, " mysql_stmt_execute failed rtsp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_rtsp));
            return FALSE;
        }
    }
    fbBasicListClear(&(rtspflow->rtspReturnCode));

    for (w=0;(rtspVar = (fbVarfield_t *)FBBLNEXT(&(rtspflow->rtspContentLength), w)); w++)
    {
        length = (rtspVar->len > 150) ? 150 : rtspVar->len;
        memcpy(varLenTemp, rtspVar->buf, length);
        id = RTSPCONTENTLENGTH;
        if (mysql_stmt_execute(stmt_rtsp)) {
            fprintf(stderr, " mysql_stmt_execute failed rtsp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_rtsp));
            return FALSE;
        }
    }
    fbBasicListClear(&(rtspflow->rtspContentLength));

    for (w=0;(rtspVar = (fbVarfield_t *)FBBLNEXT(&(rtspflow->rtspReturn), w)); w++)
    {
        length = (rtspVar->len > 150) ? 150 : rtspVar->len;
        memcpy(varLenTemp, rtspVar->buf, length);
        id = RTSPRETURN;
        if (mysql_stmt_execute(stmt_rtsp)) {
            fprintf(stderr, " mysql_stmt_execute failed rtsp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_rtsp));
            return FALSE;
        }
    }
    fbBasicListClear(&(rtspflow->rtspReturn));

    for (w=0;(rtspVar = (fbVarfield_t *)FBBLNEXT(&(rtspflow->rtspContentType), w)); w++)
    {
        length = (rtspVar->len > 150) ? 150 : rtspVar->len;
        memcpy(varLenTemp, rtspVar->buf, length);
        id = RTSPCONTENTTYPE;
        if (mysql_stmt_execute(stmt_rtsp)) {
            fprintf(stderr, " mysql_stmt_execute failed rtsp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_rtsp));
            return FALSE;
        }
    }
    fbBasicListClear(&(rtspflow->rtspContentType));

    for (w=0;(rtspVar = (fbVarfield_t *)FBBLNEXT(&(rtspflow->rtspTransport), w)); w++)
    {
        length = (rtspVar->len > 150) ? 150 : rtspVar->len;
        memcpy(varLenTemp, rtspVar->buf, length);
        id = RTSPTRANSPORT;
        if (mysql_stmt_execute(stmt_rtsp)) {
            fprintf(stderr, " mysql_stmt_execute failed rtsp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_rtsp));
            return FALSE;
        }
    }
    fbBasicListClear(&(rtspflow->rtspTransport));

    for (w=0;(rtspVar = (fbVarfield_t *)FBBLNEXT(&(rtspflow->rtspCSeq), w)); w++)
    {
        length = (rtspVar->len > 150) ? 150 : rtspVar->len;
        memcpy(varLenTemp, rtspVar->buf, length);
        id = RTSPCSEQ;
        if (mysql_stmt_execute(stmt_rtsp)) {
            fprintf(stderr, " mysql_stmt_execute failed rtsp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_rtsp));
            return FALSE;
        }
    }
    fbBasicListClear(&(rtspflow->rtspCSeq));

    for (w=0;(rtspVar = (fbVarfield_t *)FBBLNEXT(&(rtspflow->rtspLocation), w)); w++)
    {
        length = (rtspVar->len > 150) ? 150 : rtspVar->len;
        memcpy(varLenTemp, rtspVar->buf, length);
        id = RTSPLOCATION;
        if (mysql_stmt_execute(stmt_rtsp)) {
            fprintf(stderr, " mysql_stmt_execute failed rtsp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_rtsp));
            return FALSE;
        }
    }
    fbBasicListClear(&(rtspflow->rtspLocation));

    for (w=0;(rtspVar = (fbVarfield_t *)FBBLNEXT(&(rtspflow->rtspPacketsReceived), w)); w++)
    {
        length = (rtspVar->len > 150) ? 150 : rtspVar->len;
        memcpy(varLenTemp, rtspVar->buf, length);
        id = RTSPPACKETSRECEIVED;
        if (mysql_stmt_execute(stmt_rtsp)) {
            fprintf(stderr, " mysql_stmt_execute failed rtsp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_rtsp));
            return FALSE;
        }
    }
    fbBasicListClear(&(rtspflow->rtspPacketsReceived));

    for (w=0;(rtspVar = (fbVarfield_t *)FBBLNEXT(&(rtspflow->rtspUserAgent), w)); w++)
    {
        length = (rtspVar->len > 150) ? 150 : rtspVar->len;
        memcpy(varLenTemp, rtspVar->buf, length);
        id = RTSPUSERAGENT;
        if (mysql_stmt_execute(stmt_rtsp)) {
            fprintf(stderr, " mysql_stmt_execute failed rtsp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_rtsp));
            return FALSE;
        }
    }
    fbBasicListClear(&(rtspflow->rtspUserAgent));

    for (w=0;(rtspVar = (fbVarfield_t *)FBBLNEXT(&(rtspflow->rtspJitter), w)); w++)
    {
        length = (rtspVar->len > 150) ? 150 : rtspVar->len;
        memcpy(varLenTemp, rtspVar->buf, length);
        id = RTSPJITTER;
        if (mysql_stmt_execute(stmt_rtsp)) {
            fprintf(stderr, " mysql_stmt_execute failed rtsp\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_rtsp));
            return FALSE;
        }
    }
    fbBasicListClear(&(rtspflow->rtspJitter));

    return TRUE;
}

gboolean yfMySQLInsert(
    MYSQL *conn,
    yfMySQLFlow_t *mysqlflow,
    uint16_t tmplID,
    uint64_t flowID)
{

    yfMySQLTxtFlow_t *mysql;
    int i;
    static MYSQL_STMT *stmt_mysql;
    MYSQL_BIND bind_mysql[4];
    int pcount;
    char varLenTemp[250];
    size_t length;
    uint8_t id;

    if (!stmt_mysql) {
        stmt_mysql = mysql_stmt_init(conn);
        if (!stmt_mysql) {
            printf("MySQL out of Memory Error for MYSQL\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_mysql, INSERT_MYSQL, strlen(INSERT_MYSQL))) {
            printf("MySQL Prepare MYSQL Statement Failed %s\n",
                   mysql_stmt_error(stmt_mysql));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_mysql);
        if (pcount != 4) {
            printf("Invalid MYSQL Param Count returned by MySQL\n");
            return FALSE;
        }

    }
    memset(bind_mysql, 0, sizeof(bind_mysql));
    for (i = 0; i < 4; i++) {
        bind_mysql[i].is_null = 0;
        bind_mysql[i].is_unsigned = 1;
    }

    bind_mysql[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_mysql[0].buffer = (char *)&flowID;
    bind_mysql[0].length = 0;
    bind_mysql[1].buffer_type = MYSQL_TYPE_STRING;
    bind_mysql[1].buffer = (char *)mysqlflow->mysqlUsername.buf;
    bind_mysql[1].length = (unsigned long *)&(mysqlflow->mysqlUsername.len);
    bind_mysql[2].buffer_type = MYSQL_TYPE_STRING;
    bind_mysql[2].buffer = (char *)varLenTemp;
    bind_mysql[2].length = (unsigned long *)&length;
    bind_mysql[3].buffer_type = MYSQL_TYPE_TINY;
    bind_mysql[3].buffer = (char *)&id;
    bind_mysql[3].length = 0;

    if (mysql_stmt_bind_param(stmt_mysql, bind_mysql)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_mysql));
        return FALSE;
    }

    while ((mysql = (yfMySQLTxtFlow_t *)FBSTLNEXT(&(mysqlflow->mysqlList), mysql)))
    {
        length = (mysql->mysqlCommandText.len > 250) ? 250 : mysql->mysqlCommandText.len;
        memcpy(varLenTemp, mysql->mysqlCommandText.buf, length);
        id = mysql->mysqlCommandCode;
        if (mysql_stmt_execute(stmt_mysql)) {
            fprintf(stderr, " mysql_stmt_execute failed mysql\n");
            fprintf(stderr, " %s\n", mysql_stmt_error(stmt_mysql));
            return FALSE;
        }
    }

    fbSubTemplateListClear(&(mysqlflow->mysqlList));
    mysql = NULL;

    return TRUE;
}

gboolean yfFlowStatsInsert(
    MYSQL *conn,
    yfFlowStats_t *fs,
    uint16_t tmplID,
    uint64_t flowID)
{
    static MYSQL_STMT *stmt_fs = NULL;
    MYSQL_BIND bind_fs[22];
    int pcount, i;

    if (!stmt_fs) {
        stmt_fs = mysql_stmt_init(conn);
        if (!stmt_fs) {
            printf("MySQL out of Memory Error for Flow Stats\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_fs, INSERT_FS, strlen(INSERT_FS))) {
            printf("MySQL Prepare Flow Stats Statement Failed %s\n",
                   mysql_stmt_error(stmt_fs));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_fs);
        if (pcount != 22) {
            printf("Invalid Flow Stats Param Count returned by MySQL\n");
            return FALSE;
        }

    }

    memset(bind_fs, 0, sizeof(bind_fs));
    for (i = 0; i < 22; i++) {
        bind_fs[i].is_null = 0;
        bind_fs[i].is_unsigned = 1;
        bind_fs[i].buffer = NULL;
        bind_fs[i].length = 0;
    }

    bind_fs[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_fs[0].buffer = (char *)&flowID;
    bind_fs[1].buffer_type = MYSQL_TYPE_LONG;
    bind_fs[1].buffer = (char *)&(fs->tcpUrgTotalCount);
    bind_fs[2].buffer_type = MYSQL_TYPE_LONG;
    bind_fs[2].buffer = (char *)&(fs->smallPacketCount);
    bind_fs[3].buffer_type = MYSQL_TYPE_LONG;
    bind_fs[3].buffer = (char *)&(fs->largePacketCount);
    bind_fs[4].buffer_type = MYSQL_TYPE_LONG;
    bind_fs[4].buffer = (char *)&(fs->nonEmptyPacketCount);
    bind_fs[5].buffer_type = MYSQL_TYPE_SHORT;
    bind_fs[5].buffer = (char *)&(fs->maxPacketSize);
    bind_fs[6].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_fs[6].buffer = (char *)&(fs->dataByteCount);
    bind_fs[7].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_fs[7].buffer = (char *)&(fs->averageInterarrivalTime);
    bind_fs[8].buffer_type = MYSQL_TYPE_SHORT;
    bind_fs[8].buffer = (char *)&(fs->firstNonEmptyPacketSize);
    bind_fs[9].buffer_type = MYSQL_TYPE_TINY;
    bind_fs[9].buffer = (char *)&(fs->firstEightNonEmptyPacketDirections);
    bind_fs[10].buffer_type = MYSQL_TYPE_SHORT;
    bind_fs[10].buffer = (char *)&(fs->standardDeviationPayloadLength);
    bind_fs[11].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_fs[11].buffer = (char *)&(fs->standardDeviationInterarrivalTime);
    if (tmplID & YTF_REV) {
        bind_fs[12].buffer_type = MYSQL_TYPE_LONG;
        bind_fs[12].buffer = (char *)&(fs->reverseTcpUrgTotalCount);
        bind_fs[13].buffer_type = MYSQL_TYPE_LONG;
        bind_fs[13].buffer = (char *)&(fs->reverseSmallPacketCount);
        bind_fs[14].buffer_type = MYSQL_TYPE_LONG;
        bind_fs[14].buffer = (char *)&(fs->reverseLargePacketCount);
        bind_fs[15].buffer_type = MYSQL_TYPE_LONG;
        bind_fs[15].buffer = (char *)&(fs->reverseNonEmptyPacketCount);
        bind_fs[16].buffer_type = MYSQL_TYPE_SHORT;
        bind_fs[16].buffer = (char *)&(fs->reverseMaxPacketSize);
        bind_fs[17].buffer_type = MYSQL_TYPE_LONGLONG;
        bind_fs[17].buffer = (char *)&(fs->reverseDataByteCount);
        bind_fs[18].buffer_type = MYSQL_TYPE_LONGLONG;
        bind_fs[18].buffer = (char *)&(fs->reverseAverageInterarrivalTime);
        bind_fs[19].buffer_type = MYSQL_TYPE_SHORT;
        bind_fs[19].buffer = (char *)&(fs->reverseFirstNonEmptyPacketSize);
        bind_fs[20].buffer_type = MYSQL_TYPE_SHORT;
        bind_fs[20].buffer = (char *)&(fs->reverseStandardDeviationPayloadLength);
        bind_fs[21].buffer_type = MYSQL_TYPE_LONGLONG;
        bind_fs[21].buffer = (char *)&(fs->reverseStandardDeviationInterarrivalTime);
    }

    if (mysql_stmt_bind_param(stmt_fs, bind_fs)) {
        printf("Fatal: mysql_stmt_bind_param() failed fs\n");
        printf(" %s\n", mysql_stmt_error(stmt_fs));
        return FALSE;
    }

    if (mysql_stmt_execute(stmt_fs)) {
        fprintf(stderr, " mysql_stmt_execute failed fs\n");
        fprintf(stderr, " %s\n", mysql_stmt_error(stmt_fs));
        return FALSE;
    }

    return TRUE;
}

gboolean yfDHCPInsert(
    MYSQL               *conn,
    yfDHCP_FP_Flow_t    *dhcp,
    uint16_t            tmplID,
    uint64_t            flowID)
{

    static MYSQL_STMT *stmt_dhcp;
    MYSQL_BIND bind_dhcp[5];
    int pcount, i;
    char prbuf[250];
    size_t length;

    if (!stmt_dhcp) {
        stmt_dhcp = mysql_stmt_init(conn);
        if (!stmt_dhcp) {
            printf("MySQL out of Memory Error for DHCP\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_dhcp, INSERT_DHCP, strlen(INSERT_DHCP))) {
            printf("MySQL Prepare MYSQL Statement Failed %s\n",
                   mysql_stmt_error(stmt_dhcp));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_dhcp);
        if (pcount != 5) {
            printf("Invalid MYSQL Param Count returned by MySQL\n");
            return FALSE;
        }

    }

    memset(bind_dhcp, 0, sizeof(bind_dhcp));
    for (i = 0; i < 5; i++) {
        bind_dhcp[i].is_null = 0;
        bind_dhcp[i].is_unsigned = 1;
        bind_dhcp[i].buffer = NULL;
        bind_dhcp[i].length = 0;
    }


    bind_dhcp[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_dhcp[0].buffer = (char *)&flowID;
    bind_dhcp[0].length = 0;
    bind_dhcp[1].buffer_type = MYSQL_TYPE_STRING;
    bind_dhcp[1].buffer = (char *)dhcp->dhcpFP.buf;
    bind_dhcp[1].length = (unsigned long *)&(dhcp->dhcpFP.len);
    bind_dhcp[2].buffer_type = MYSQL_TYPE_STRING;
    bind_dhcp[2].buffer = (char *)dhcp->dhcpVC.buf;
    bind_dhcp[2].length = (unsigned long *)&(dhcp->dhcpVC.len);
    if (tmplID & YTF_REV) {
        bind_dhcp[3].buffer_type = MYSQL_TYPE_STRING;
        bind_dhcp[3].buffer = (char *)dhcp->reverseDhcpFP.buf;
        bind_dhcp[3].length = (unsigned long *)&(dhcp->reverseDhcpFP.len);
        bind_dhcp[4].buffer_type = MYSQL_TYPE_STRING;
        bind_dhcp[4].buffer = (char *)dhcp->reverseDhcpVC.buf;
        bind_dhcp[4].length = (unsigned long *)&(dhcp->reverseDhcpVC.len);
    }
    if (mysql_stmt_bind_param(stmt_dhcp, bind_dhcp)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_dhcp));
        return FALSE;
    }

    if (mysql_stmt_execute(stmt_dhcp)) {
        fprintf(stderr, " mysql_stmt_execute failed ssl\n");
        fprintf(stderr, " %s\n", mysql_stmt_error(stmt_dhcp));
        return FALSE;
    }

    return TRUE;
}




gboolean yfMyNewSSLInsert(
    MYSQL *conn,
    yfSSL2Flow_t *sslflow,
    uint16_t tmplID,
    uint64_t flowID)
{
    static MYSQL_STMT *stmt_ssl;
    MYSQL_BIND bind_ssl[4];
    int pcount, i;
    char prbuf[250];
    size_t length;
    uint16_t id;
    yfSSL2CertFlow_t *cert = NULL;
    yfSSLObjValue_t *obj = NULL;
    int cert_no = 0;

    if (!stmt_ssl) {
        stmt_ssl = mysql_stmt_init(conn);
        if (!stmt_ssl) {
            printf("MySQL out of Memory Error for SSL\n");
            return FALSE;
        }
        if (mysql_stmt_prepare(stmt_ssl, INSERT_SSL2, strlen(INSERT_SSL2))) {
            printf("MySQL Prepare MYSQL Statement Failed %s\n",
                   mysql_stmt_error(stmt_ssl));
            return FALSE;
        }
        pcount = mysql_stmt_param_count(stmt_ssl);
        if (pcount != 4) {
            printf("Invalid MYSQL Param Count returned by MySQL\n");
            return FALSE;
        }

    }

    memset(bind_ssl, 0, sizeof(bind_ssl));
    for (i = 0; i < 4; i++) {
        bind_ssl[i].is_null = 0;
        bind_ssl[i].is_unsigned = 1;
    }

    bind_ssl[0].buffer_type = MYSQL_TYPE_LONGLONG;
    bind_ssl[0].buffer = (char *)&flowID;
    bind_ssl[0].length = 0;
    bind_ssl[1].buffer_type = MYSQL_TYPE_SHORT;
    bind_ssl[1].buffer = (char *)&id;
    bind_ssl[1].length = 0;
    bind_ssl[2].buffer_type = MYSQL_TYPE_SHORT;
    bind_ssl[2].buffer = (char *)&cert_no;
    bind_ssl[2].length = 0;
    bind_ssl[3].buffer_type = MYSQL_TYPE_STRING;
    bind_ssl[3].buffer = prbuf;
    bind_ssl[3].length = (unsigned long *)&length;

    if (mysql_stmt_bind_param(stmt_ssl, bind_ssl)) {
        printf("Fatal: mysql_stmt_bind_param() failed\n");
        printf(" %s\n", mysql_stmt_error(stmt_ssl));
        return FALSE;
    }

    while ((cert =
            (yfSSL2CertFlow_t *)FBSTLNEXT(&(sslflow->sslCertList),
                                          cert)))
    {
        while ((obj =
                (yfSSLObjValue_t *)FBSTLNEXT(&(cert->issuer),
                                             obj)))
        {
            if (obj->obj_value.len) {
                memcpy(prbuf, obj->obj_value.buf,
                       obj->obj_value.len);
                id = obj->obj_id;
                length = (obj->obj_value.len > 250) ? 250 : obj->obj_value.len;
                if (mysql_stmt_execute(stmt_ssl)) {
                    fprintf(stderr, " mysql_stmt_execute failed ssl\n");
                    fprintf(stderr, " %s\n", mysql_stmt_error(stmt_ssl));
                    return FALSE;
                }
            }
        }
        fbSubTemplateListClear(&(cert->issuer));
        while ((obj =
                (yfSSLObjValue_t *)FBSTLNEXT(&(cert->subject),
                                             obj)))
        {
            memcpy(prbuf, obj->obj_value.buf,
                   obj->obj_value.len);
            id = obj->obj_id;
            length = (obj->obj_value.len > 250) ? 250 : obj->obj_value.len;
            if (mysql_stmt_execute(stmt_ssl)) {
                fprintf(stderr, " mysql_stmt_execute failed ssl\n");
                fprintf(stderr, " %s\n", mysql_stmt_error(stmt_ssl));
                return FALSE;
            }
        }
        fbSubTemplateListClear(&(cert->subject));

        if (cert->not_before.len) {
            memcpy(prbuf, cert->not_before.buf,
                   cert->not_before.len);
            length = cert->not_before.len;
            id = 247;
            if (mysql_stmt_execute(stmt_ssl)) {
                fprintf(stderr, " mysql_stmt_execute failed ssl\n");
                fprintf(stderr, " %s\n", mysql_stmt_error(stmt_ssl));
                return FALSE;
            }
        }
        if (cert->not_after.len) {
            id = 248;
            memcpy(prbuf, cert->not_after.buf,
                   cert->not_after.len);
            length = cert->not_after.len;
            if (mysql_stmt_execute(stmt_ssl)) {
                fprintf(stderr, " mysql_stmt_execute failed ssl\n");
                fprintf(stderr, " %s\n", mysql_stmt_error(stmt_ssl));
                return FALSE;
            }
        }

        cert_no++;
    }

    fbSubTemplateListClear(&(sslflow->sslCertList));
    fbBasicListClear(&(sslflow->sslCipherList));

    return TRUE;
}



static void printFlags(uint8_t flags, char *out) {

    if (flags & 0x40) *out++ = 'E';
    if (flags & 0x80) *out++ = 'C';
    if (flags & 0x20) *out++ = 'U';
    if (flags & 0x10) *out++ = 'A';
    if (flags & 0x08) *out++ = 'P';
    if (flags & 0x04) *out++ = 'R';
    if (flags & 0x02) *out++ = 'S';
    if (flags & 0x01) *out++ = 'F';
    *out++ = '\0';
}
