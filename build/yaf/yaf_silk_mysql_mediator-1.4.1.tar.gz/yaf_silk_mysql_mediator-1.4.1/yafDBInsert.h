/**
 * @file yafDBInsert.h
 *
 *
 *
 * @Author: Emily
 * @Date: 5.4.11
 *
 ** @OPENSOURCE_HEADER_START@
 ** Use of the YAF system and related source code is subject to the terms
 ** of the following licenses:
 **
 ** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
 ** Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 **
 ** NO WARRANTY
 **
 ** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
 ** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
 ** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
 ** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
 ** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
 ** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
 ** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
 ** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
 ** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
 ** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
 ** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
 ** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
 ** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
 ** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
 ** DELIVERABLES UNDER THIS LICENSE.
 **
 ** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
 ** Mellon University, its trustees, officers, employees, and agents from
 ** all claims or demands made against them (and any related losses,
 ** expenses, or attorney's fees) arising out of, or relating to Licensee's
 ** and/or its sub licensees' negligent use or willful misuse of or
 ** negligent conduct or willful misconduct regarding the Software,
 ** facilities, or other rights or assistance granted by Carnegie Mellon
 ** University under this License, including, but not limited to, any
 ** claims of product liability, personal injury, death, damage to
 ** property, or violation of any laws or regulations.
 **
 ** Carnegie Mellon University Software Engineering Institute authored
 ** documents are sponsored by the U.S. Department of Defense under
 ** Contract FA8721-05-C-0003. Carnegie Mellon University retains
 ** copyrights in all material produced under this contract. The U.S.
 ** Government retains a non-exclusive, royalty-free license to publish or
 ** reproduce these documents, or allow others to do so, for U.S.
 ** Government purposes only pursuant to the copyright license under the
 ** contract clause at 252.227.7013.
 **
 ** @OPENSOURCE_HEADER_END@
 ** ------------------------------------------------------------------------
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <libgen.h>
#include <fixbuf/public.h>
#include <glib.h>
#include <signal.h>
#include "CERT_IE.h"
#include <my_global.h>
#include <mysql.h>

/* YAF TIDs */
#define YAF_ENTROPY_FLOW_TID   0xC002
#define YAF_TCP_FLOW_TID       0xC003
#define YAF_MAC_FLOW_TID       0xC004
#define YAF_DAG_FLOW_TID       0xC005
#define YAF_P0F_FLOW_TID       0xC006
#define YAF_FPEXPORT_FLOW_TID  0xC007
#define YAF_PAYLOAD_FLOW_TID   0xC008
#define YTF_BIF                0xFF0F
#define YTF_REV                0x0010
#define YAF_HTTP_FLOW_TID      0xC600
#define YAF_IRC_FLOW_TID       0xC200
#define YAF_POP3_FLOW_TID      0xC300
#define YAF_TFTP_FLOW_TID      0xC400
#define YAF_SLP_FLOW_TID       0xC500
#define YAF_FTP_FLOW_TID       0xC700
#define YAF_IMAP_FLOW_TID      0xC800
#define YAF_RTSP_FLOW_TID      0xC900
#define YAF_SIP_FLOW_TID       0xCA00
#define YAF_SMTP_FLOW_TID      0xCB00
#define YAF_SSH_FLOW_TID       0xCC00
#define YAF_NNTP_FLOW_TID      0xCD00
#define YAF_DNS_FLOW_TID       0xCE00
#define YAF_DNSQR_FLOW_TID     0xCF00
#define YAF_DNSA_FLOW_TID      0xCE01
#define YAF_DNSAAAA_FLOW_TID   0xCE02
#define YAF_DNSCN_FLOW_TID     0xCE03
#define YAF_DNSMX_FLOW_TID     0xCE04
#define YAF_DNSTXT_FLOW_TID    0xCE07
#define YAF_DNSNS_FLOW_TID     0xCE05
#define YAF_DNSPTR_FLOW_TID    0xCE06
#define YAF_SSL_FLOW_TID       0xCE0A
#define YAF_SSL_CERT_FLOW_TID  0xCE0B
#define YAF_MYSQL_FLOW_TID     0xCE0C
#define YAF_MYSQLTXT_FLOW_TID  0xCE0D
#define YAF_DHCP_FLOW_TID      0xC201
#define YAF_STATS_FLOW_TID     0xC005
#define YAF_NEW_SSL_FLOW_TID   0xCA0A

#define INSERT_TCP "INSERT INTO tcp(id, tcpSequenceNumber, "\
    "reverseTcpSequenceNumber, initialTCPFlags, reverseInitialTCPFlags, "\
    "unionTCPFlags, reverseUnionTCPFlags) VALUES(?,?,?,?,?,?,?)"

#define INSERT_FS "INSERT INTO flowstats(id, tcpurg, smallpkt, largepktct,"\
    "nonempty, maxpktsize, datalen," \
    "avgitime, firstpktlen, firsteight, stddevlen, stddevtime,"\
    "revtcpurg, revsmallpkt, revlargepktct, revnonempty,"\
    "revmaxpktsize, revdatalen, revavgitime, "\
    "revfirstpktlen, revstddevlen, revstddevtime)" \
    "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

#define INSERT_P0F "INSERT INTO p0f(id, osName, osFingerPrint, osVersion, "\
    "reverseOsName, reverseOsFingerPrint, reverseOsVersion) "\
    "VALUES(?,?,?,?,?,?,?)"
#define INSERT_HTTP "INSERT INTO http(id, listType, listTypeValue) "\
    "VALUES(?,?,?)"
#define INSERT_POP3 "INSERT INTO pop3(id, listType, listTypeValue) "\
    "VALUES(?,?,?)"
#define INSERT_IRC "INSERT INTO irc(id, listType, listTypeValue) "\
    "VALUES(?,?,?)"
#define INSERT_TFTP "INSERT INTO tftp(id, tftpFileName, tftpMode) "\
    "VALUES(?,?,?)"
#define INSERT_SLP "INSERT INTO slp(id, slpVersion, slpMessageType, listType,"\
    " listTypeValue) VALUES(?,?,?,?,?)"
#define INSERT_FTP "INSERT INTO ftp(id, listType, listTypeValue) "\
    "VALUES(?,?,?)"
#define INSERT_IMAP "INSERT INTO imap(id, listType, listTypeValue) "\
    "VALUES(?,?,?)"
#define INSERT_SIP "INSERT INTO sip(id, listType, listTypeValue) "\
    "VALUES(?,?,?)"
#define INSERT_SMTP "INSERT INTO smtp(id, listType, listTypeValue) "\
    "VALUES(?,?,?)"
#define INSERT_SSH "INSERT INTO ssh(id, listType, listTypeValue) "\
    "VALUES(?,?,?)"
#define INSERT_NNTP "INSERT INTO nntp(id, listType, listTypeValue) "\
    "VALUES(?,?,?)"
#define INSERT_SSL "INSERT INTO ssl_tls(id, compressionMethod, clientVersion, "\
    "serverCipher) VALUES(?,?,?,?)"
#define INSERT_SSLCERT "INSERT INTO sslcert(id, certChain, certVersion, signature, "\
    "IssuerCountryName, IssuerOrgName, IssuerOrgUnitName, IssuerCommonName, "\
    "IssuerZipCode, IssuerState, IssuerLocalityName, IssuerStreetAddress, "\
    "subjectCountryName, subjectOrgName, subjectOrgUnitName, "\
    "subjectZipCode, subjectState, subjectCommonName, subjectLocalityName, "\
    "subjectStreetAddress) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
#define INSERT_RTSP "INSERT INTO rtsp(id, listType, listTypeValue) "\
    "VALUES(?,?,?)"
#define INSERT_MYSQL "INSERT INTO mysql(id, username, commandText, commandCode) " \
    "VALUES(?,?,?,?)"
#define INSERT_DHCP "INSERT INTO dhcp(id, os, vc, ros, rvc) VALUES(?,?,?,?,?)"
#define INSERT_SSL2 "INSERT INTO tls(id, ie, cert_no, data) VALUES(?,?,?,?)"
#define INSERT_DNS "INSERT INTO dns(id, tid, qr, type, auth, nx, section, ttl, "\
    "rrname, rrval) VALUES(?,?,?,?,?,?,?,?,?,?)"

/* Full YAF flow record. */
typedef struct yfIpfixFlow_st {
    uint64_t    flowStartMilliseconds;
    uint64_t    flowEndMilliseconds;
    uint64_t    octetTotalCount;
    uint64_t    reverseOctetTotalCount;
    uint64_t    packetTotalCount;
    uint64_t    reversePacketTotalCount;
    uint8_t     sourceIPv6Address[16];
    uint8_t     destinationIPv6Address[16];
    uint32_t    sourceIPv4Address;
    uint32_t    destinationIPv4Address;
    uint16_t    sourceTransportPort;
    uint16_t    destinationTransportPort;
    uint16_t    flowAttributes;
    uint16_t    reverseFlowAttributes;
    uint8_t     protocolIdentifier;
    uint8_t     flowEndReason;
    uint16_t    silkAppLabel;
    int32_t     reverseFlowDeltaMilliseconds;
    uint32_t    tcpSeqNo;
    uint32_t    revTcpSeqNo;
    uint8_t     iflags;
    uint8_t     uflags;
    uint8_t     riflags;
    uint8_t     ruflags;
    /* MAC Specific Info */
    uint16_t    vlanId;
    uint16_t    reverseVlanId;
    uint32_t    ingress;
    uint32_t    egress;
    fbSubTemplateMultiList_t subTemplateMultiList;
} yfIpfixFlow_t;


typedef struct yfSSLFlow_st {
    fbBasicList_t sslCipherList;
    uint32_t      sslServerCipher;
    uint8_t       sslClientVersion;
    uint8_t       sslCompressionMethod;
} yfSSLFlow_t;


typedef struct yfRTSPFlow_st {
    fbBasicList_t rtspURL;
    fbBasicList_t rtspVersion;
    fbBasicList_t rtspReturnCode;
    fbBasicList_t rtspContentLength;
    fbBasicList_t rtspReturn;
    fbBasicList_t rtspContentType;
    fbBasicList_t rtspTransport;
    fbBasicList_t rtspCSeq;
    fbBasicList_t rtspLocation;
    fbBasicList_t rtspPacketsReceived;
    fbBasicList_t rtspUserAgent;
    fbBasicList_t rtspJitter;
} yfRTSPFlow_t;

typedef struct yfSIPFlow_st {
    fbBasicList_t sipInvite;
    fbBasicList_t sipCommand;
    fbBasicList_t sipVia;
    fbBasicList_t sipMaxForwards;
    fbBasicList_t sipAddress;
    fbBasicList_t sipContentLength;
    fbBasicList_t sipUserAgent;
} yfSIPFlow_t;

typedef struct yfSMTPFlow_st {
    fbBasicList_t smtpHello;
    fbBasicList_t smtpFrom;
    fbBasicList_t smtpTo;
    fbBasicList_t smtpContentType;
    fbBasicList_t smtpSubject;
    fbBasicList_t smtpFilename;
    fbBasicList_t smtpContentDisposition;
    fbBasicList_t smtpResponse;
    fbBasicList_t smtpEnhanced;
} yfSMTPFlow_t;

typedef struct yfMySQLFlow_st {
    fbSubTemplateList_t mysqlList;
    fbVarfield_t mysqlUsername;
} yfMySQLFlow_t;

typedef struct yfMySQLTxtFlow_st {
    fbVarfield_t  mysqlCommandText;
    uint8_t       mysqlCommandCode;
    uint8_t       padding[7];
} yfMySQLTxtFlow_t;


typedef struct yfSSHFlow_st {
    fbBasicList_t sshVersion;
} yfSSHFlow_t;

typedef struct yfNNTPFlow_st {
    fbBasicList_t nntpResponse;
    fbBasicList_t nntpCommand;
} yfNNTPFlow_t;

typedef struct yfIRCFlow_st {
    fbBasicList_t ircMsg;
} yfIRCFlow_t;

typedef struct yfPOP3Flow_st {
    fbBasicList_t pop3msg;
} yfPOP3Flow_t;

typedef struct yfTFTPFlow_st {
    fbVarfield_t tftpFilename;
    fbVarfield_t tftpMode;
} yfTFTPFlow_t;

typedef struct yfSLPFlow_st {
    fbBasicList_t slpString;
    uint8_t     slpVersion;
    uint8_t     slpMessageType;
} yfSLPFlow_t;

typedef struct yfFTPFlow_st {
    fbBasicList_t ftpReturn;
    fbBasicList_t ftpUser;
    fbBasicList_t ftpPass;
    fbBasicList_t ftpType;
    fbBasicList_t ftpRespCode;
} yfFTPFlow_t;

typedef struct yfIMAPFlow_st {
    fbBasicList_t imapCapability;
    fbBasicList_t imapLogin;
    fbBasicList_t imapStartTLS;
    fbBasicList_t imapAuthenticate;
    fbBasicList_t imapCommand;
    fbBasicList_t imapExists;
    fbBasicList_t imapRecent;
} yfIMAPFlow_t;

typedef struct yfP0fFlow_st {
    fbVarfield_t    osName;
    fbVarfield_t    osVersion;
    fbVarfield_t    osFingerPrint;
    fbVarfield_t    reverseOsName;
    fbVarfield_t    reverseOsVersion;
    fbVarfield_t    reverseOsFingerPrint;
} yfP0fFlow_t;

typedef struct yfFPExportFlow_st {
    fbVarfield_t    firstPacketBanner;
    fbVarfield_t    secondPacketBanner;
    fbVarfield_t    reverseFirstPacketBanner;
} yfFPExportFlow_t;

typedef struct yfPayloadFlow_st {
    fbVarfield_t payload;
    fbVarfield_t reversePayload;
} yfPayloadFlow_t;

typedef struct yfHTTPFlow_st {
    fbBasicList_t server;
    fbBasicList_t userAgent;
    fbBasicList_t get;
    fbBasicList_t connection;
    fbBasicList_t referer;
    fbBasicList_t location;
    fbBasicList_t host;
    fbBasicList_t contentLength;
    fbBasicList_t age;
    fbBasicList_t response;
    fbBasicList_t acceptLang;
    fbBasicList_t accept;
    fbBasicList_t contentType;
    fbBasicList_t version;
    fbBasicList_t httpCookie;
    fbBasicList_t httpSetCookie;
} yfHTTPFlow_t;

typedef struct yfSSLCertFlow_st {
    fbVarfield_t sslSignature;
    fbVarfield_t sslICountryName;
    fbVarfield_t sslIOrgName;
    fbVarfield_t sslIOrgUnitName;
    fbVarfield_t sslIZipCode;
    fbVarfield_t sslIState;
    fbVarfield_t sslICommonName;
    fbVarfield_t sslILocalityName;
    fbVarfield_t sslIStreetAddress;
    fbVarfield_t sslSCountryName;
    fbVarfield_t sslSOrgName;
    fbVarfield_t sslSOrgUnitName;
    fbVarfield_t sslSZipCode;
    fbVarfield_t sslSState;
    fbVarfield_t sslSCommonName;
    fbVarfield_t sslSLocalityName;
    fbVarfield_t sslSStreetAddress;
    uint8_t     sslVersion;
} yfSSLCertFlow_t;

typedef struct yfEntropyFlow_st {
    uint8_t     entropy;
    uint8_t     reverseEntropy;
} yfEntropyFlow_t;

typedef struct yfTcpFlow_st {
    uint32_t    tcpSequenceNumber;
    uint8_t     initialTCPFlags;
    uint8_t     unionTCPFlags;
    uint8_t     reverseInitialTCPFlags;
    uint8_t     reverseUnionTCPFlags;
    uint32_t    reverseTcpSequenceNumber;
} yfTcpFlow_t;

typedef struct yfMacFlow_st {
    uint8_t     sourceMacAddress[6];
    uint8_t     destinationMacAddress[6];
} yfMacFlow_t;

typedef struct yfDNSFlow_st {
    fbSubTemplateList_t   dnsQRList;
} yfDNSFlow_t;

typedef struct yfDNSQRFlow_st {
    fbSubTemplateList_t rrlist;
    fbVarfield_t        dnsQName;
    uint32_t            dnsTTL;
    uint16_t            dnsQRType;
    uint8_t             dnsQueryResponse;
    uint8_t             dnsAuthoritative;
    uint8_t             dnsNXDomain;
    uint8_t             dnsRRSection;
    uint16_t            dnsID;
    uint8_t             padding[4];
} yfDNSQRFlow_t;

typedef struct yfDNSAFlow_st {
    uint32_t ip;
} yfDNSAFlow_t;

typedef struct yfDNSAAAAFlow_st {
    uint8_t  ip[16];
} yfDNSAAAAFlow_t;

typedef struct yfDNSCNameFlow_st {
    fbVarfield_t cname;
} yfDNSCNameFlow_t;

typedef struct yfDNSMXFlow_st {
    fbVarfield_t exchange;
    uint16_t     preference;
    uint8_t      padding[6];
} yfDNSMXFlow_t;

typedef struct yfDNSNSFlow_st {
    fbVarfield_t nsdname;
} yfDNSNSFlow_t;

typedef struct yfDNSPTRFlow_st {
    fbVarfield_t ptrdname;
} yfDNSPTRFlow_t;

typedef struct yfDNSTXTFlow_st {
  fbVarfield_t txt_data;
} yfDNSTXTFlow_t;

typedef struct yfDNSSOAFlow_st {
    fbVarfield_t mname;
    fbVarfield_t rname;
    uint32_t serial;
    uint32_t refresh;
    uint32_t retry;
    uint32_t expire;
    uint32_t minimum;
    uint8_t padding[4];
} yfDNSSOAFlow_t;

typedef struct yfDNSSRVFlow_st {
    fbVarfield_t dnsTarget;
    uint16_t dnsPriority;
    uint16_t dnsWeight;
    uint16_t dnsPort;
    uint8_t padding[2];
} yfDNSSRVFlow_t;

typedef struct yfSSL2Flow_st {
    fbBasicList_t        sslCipherList;
    uint32_t             sslServerCipher;
    uint8_t              sslClientVersion;
    uint8_t              sslCompressionMethod;
    uint8_t              padding[2];
    fbSubTemplateList_t  sslCertList;
} yfSSL2Flow_t;

typedef struct yfDHCP_FP_Flow_st {
    fbVarfield_t dhcpFP;
    fbVarfield_t dhcpVC;
    fbVarfield_t reverseDhcpFP;
    fbVarfield_t reverseDhcpVC;
} yfDHCP_FP_Flow_t;

typedef struct yfSSL2CertFlow_st {
    fbSubTemplateList_t     issuer;
    fbSubTemplateList_t     subject;
    fbSubTemplateList_t     extension;
    fbVarfield_t            sig;
    fbVarfield_t            serial;
    fbVarfield_t            not_before;
    fbVarfield_t            not_after;
    fbVarfield_t            pkalg;
    uint16_t                pklen;
    uint8_t                 version;
    uint8_t                 padding[5];
} yfSSL2CertFlow_t;

typedef struct yfSSLObjValue_st {
    fbVarfield_t            obj_value;
    uint8_t                 obj_id;
    uint8_t                 padding[7];
} yfSSLObjValue_t;


typedef struct yfFlowStats_st {
    uint64_t dataByteCount;
    uint64_t averageInterarrivalTime;
    uint64_t standardDeviationInterarrivalTime;
    uint32_t tcpUrgTotalCount;
    uint32_t smallPacketCount;
    uint32_t nonEmptyPacketCount;
    uint32_t largePacketCount;
    uint16_t firstNonEmptyPacketSize;
    uint16_t maxPacketSize;
    uint16_t standardDeviationPayloadLength;
    uint8_t  firstEightNonEmptyPacketDirections;
    uint8_t  padding[1];
    /* reverse Fields */
    uint64_t reverseDataByteCount;
    uint64_t reverseAverageInterarrivalTime;
    uint64_t reverseStandardDeviationInterarrivalTime;
    uint32_t reverseTcpUrgTotalCount;
    uint32_t reverseSmallPacketCount;
    uint32_t reverseNonEmptyPacketCount;
    uint32_t reverseLargePacketCount;
    uint16_t reverseFirstNonEmptyPacketSize;
    uint16_t reverseMaxPacketSize;
    uint16_t reverseStandardDeviationPayloadLength;
    uint8_t  padding2[2];
} yfFlowStats_t;


static void printFlags(
    uint8_t flags,
    char *out);

gboolean yfMyTCPInsert(
    MYSQL *conn,
    yfTcpFlow_t *tcpRecord,
    uint16_t tcpTmplID,
    uint64_t flowID);

gboolean yfMyP0FInsert(
    MYSQL *conn,
    yfP0fFlow_t *p0frec,
    uint16_t p0fTmplID,
    uint64_t flowID);

gboolean yfMyHTTPInsert(
    MYSQL *conn,
    yfHTTPFlow_t *httprec,
    uint16_t httpTmplID,
    uint64_t flowID);

gboolean yfMyPOP3Insert(
    MYSQL *conn,
    yfPOP3Flow_t *pop3flow,
    uint16_t tmplID,
    uint64_t flowID);
gboolean yfMyIRCInsert(
    MYSQL *conn,
    yfIRCFlow_t *ircflow,
    uint16_t tmplID,
    uint64_t flowID);

gboolean yfMyTFTPInsert(
    MYSQL *conn,
    yfTFTPFlow_t *tftpflow,
    uint16_t tmplID,
    uint64_t flowID);

gboolean yfMySLPInsert(
    MYSQL *conn,
    yfSLPFlow_t *slpflow,
    uint16_t tmplID,
    uint64_t flowID);

gboolean yfMyFTPInsert(
    MYSQL *conn,
    yfFTPFlow_t *ftpflow,
    uint16_t tmplID,
    uint64_t flowID);

gboolean yfMyIMAPInsert(
    MYSQL *conn,
    yfIMAPFlow_t *imapflow,
    uint16_t tmplID,
    uint64_t flowID);

gboolean yfMySIPInsert(
    MYSQL *conn,
    yfSIPFlow_t *sipflow,
    uint16_t tmplID,
    uint64_t flowID);

gboolean yfMySMTPInsert(
    MYSQL *conn,
    yfSMTPFlow_t *smtpflow,
    uint16_t tmplID,
    uint64_t flowID);

gboolean yfMySSHInsert(
    MYSQL *conn,
    yfSSHFlow_t *sshflow,
    uint16_t tmplID,
    uint64_t flowID);

gboolean yfMyNNTPInsert(
    MYSQL *conn,
    yfNNTPFlow_t *nntpflow,
    uint16_t tmplID,
    uint64_t flowID);

gboolean yfMySSLInsert(
    MYSQL *conn,
    yfSSLFlow_t *sslflow,
    uint16_t tmplID,
    uint64_t flowID);

gboolean yfMyDNSInsert(
    MYSQL *conn,
    yfDNSFlow_t *dnsflow,
    uint16_t tmplID,
    uint64_t flowID);

gboolean yfMyRTSPInsert(
    MYSQL *conn,
    yfRTSPFlow_t *rtspflow,
    uint16_t tmplID,
    uint64_t flowID);

gboolean yfMySSLCertInsert(
    MYSQL *conn,
    yfSSLCertFlow_t *sslcert,
    uint16_t tmplID,
    uint64_t flowID,
    int w);

gboolean yfMySQLInsert(
    MYSQL *conn,
    yfMySQLFlow_t *mysqlflow,
    uint16_t tmplID,
    uint64_t flowID);

gboolean yfMyNewSSLInsert(
    MYSQL *conn,
    yfSSL2Flow_t *sslflow,
    uint16_t tmplID,
    uint64_t flowID);

gboolean yfDHCPInsert(
    MYSQL               *conn,
    yfDHCP_FP_Flow_t    *dhcp,
    uint16_t            tmplID,
    uint64_t            flowID);

gboolean yfFlowStatsInsert(
    MYSQL *conn,
    yfFlowStats_t *fs,
    uint16_t tmplID,
    uint64_t flowID);
