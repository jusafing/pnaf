/*
 *
 ** @file CERT_IE.h
 ** Definition of the CERT "standard" information elements extension to
 ** the IETF standard RFC 5102 information elements
 **
 ** ------------------------------------------------------------------------
 ** Copyright (C) 2009-2011 Carnegie Mellon University. All Rights Reserved.
 ** ------------------------------------------------------------------------
 ** Authors: CERT Network Situational Awareness Development Group
 ** <netsa-help@cert.org>
 ** ------------------------------------------------------------------------
 ** GNU General Public License (GPL) Rights pursuant to Version 2, June 1991
 ** Government Purpose License Rights (GPLR) pursuant to DFARS 252.227-7013
 ** ------------------------------------------------------------------------
 */


#ifndef CERT_IE_H_
#define CERT_IE_H_

#define CERT_PEN 6871

#define HTTPSERVER 110
#define HTTPUSERAGENT 111
#define HTTPGET 112
#define HTTPCONNECTION 113
#define HTTPVERSION 114
#define HTTPREFERER 115
#define HTTPLOCATION 116
#define HTTPHOST 117
#define HTTPCONTENTLENGTH 118
#define HTTPAGE 119
#define HTTPACCEPT 120
#define HTTPACCEPTLANGUAGE 121
#define HTTPCONTENTTYPE 122
#define HTTPRESPONSE 123
#define HTTPCOOKIE 220
#define HTTPSETCOOKIE 221
#define POP3MSG 124
#define IRCMSG 125
#define TFTPFILENAME 126
#define TFTPMODE 127
#define SLPSTRING 130
#define FTPRETURN 131
#define FTPUSER 132
#define FTPPASS 133
#define FTPTYPE 134
#define FTPRESPCODE 135
#define IMAPCAPABILITY 136
#define IMAPLOGIN 137
#define IMAPSTARTTLS 138
#define IMAPAUTHENTICATE 139
#define IMAPCOMMAND 140
#define IMAPEXISTS 141
#define IMAPRECENT 142
#define RTSPURL 143
#define RTSPVERSION 144
#define RTSPRETURNCODE 145
#define RTSPCONTENTLENGTH 146
#define RTSPRETURN 147
#define RTSPCONTENTTYPE 148
#define RTSPTRANSPORT 149
#define RTSPCSEQ 150
#define RTSPLOCATION 151
#define RTSPPACKETSRECEIVED 152
#define RTSPUSERAGENT 153
#define RTSPJITTER 154
#define SIPINVITE 155
#define SIPCOMMAND 156
#define SIPVIA 157
#define SIPMAXFORWARDS 158
#define SIPADDRESS 159
#define SIPCONTENTLENGTH 160
#define SIPUSERAGENT 161
#define SMTPHELLO 162
#define SMTPFROM 163
#define SMTPTO 164
#define SMTPCONTENTTYPE 165
#define SMTPSUBJECT 166
#define SMTPFILENAME 167
#define SMTPCONTENTDISPOSITION 168
#define SMTPRESPONSE 169
#define SMTPENHANCED 170
#define SSHVERSION 171
#define NNTPRESPONSE 172
#define NNTPCOMMAND 173


/**
 * IPFIX information elements in 6871/CERT_PEN space for YAF
 * these elements are included within the capabilities of YAF
 * primarily, but may be used within other CERT software as
 * well
 */
static fbInfoElement_t yaf_info_elements[] = {
    FB_IE_INIT("initialTCPFlags", CERT_PEN, 14, 1, FB_IE_F_ENDIAN | FB_IE_F_REVERSIBLE),
    FB_IE_INIT("unionTCPFlags", CERT_PEN, 15, 1, FB_IE_F_ENDIAN | FB_IE_F_REVERSIBLE),
    FB_IE_INIT("reverseFlowDeltaMilliseconds", CERT_PEN, 21, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("payload", CERT_PEN, 18, FB_IE_VARLEN, FB_IE_F_REVERSIBLE),
    FB_IE_INIT("payloadEntropy", CERT_PEN, 35, 1, FB_IE_F_REVERSIBLE),
    FB_IE_INIT("silkAppLabel", CERT_PEN, 33, 2, FB_IE_F_ENDIAN),
    FB_IE_INIT("osFingerPrint", CERT_PEN, 107, FB_IE_VARLEN, FB_IE_F_REVERSIBLE),
    FB_IE_INIT("osName", CERT_PEN, 36, FB_IE_VARLEN, FB_IE_F_REVERSIBLE),
    FB_IE_INIT("osVersion", CERT_PEN, 37, FB_IE_VARLEN, FB_IE_F_REVERSIBLE),
    FB_IE_INIT("flowAttributes", CERT_PEN, 40, 2, FB_IE_F_ENDIAN | FB_IE_F_REVERSIBLE),
    FB_IE_INIT("firstPacketBanner", CERT_PEN, 38, FB_IE_VARLEN, FB_IE_F_REVERSIBLE),
    FB_IE_INIT("secondPacketBanner", CERT_PEN, 39, FB_IE_VARLEN, FB_IE_F_REVERSIBLE),
    FB_IE_INIT("expiredFragmentCount", CERT_PEN, 100, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("assembledFragmentCount", CERT_PEN, 101, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("meanFlowRate", CERT_PEN, 102, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("meanPacketRate", CERT_PEN, 103, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("flowTableFlushEventCount", CERT_PEN, 104, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("flowTablePeakCount", CERT_PEN, 105, 4, FB_IE_F_ENDIAN),
    /* flow stats */
    FB_IE_INIT("smallPacketCount", CERT_PEN, 500, 4, FB_IE_F_ENDIAN | FB_IE_F_REVERSIBLE),
    FB_IE_INIT("nonEmptyPacketCount", CERT_PEN, 501, 4, FB_IE_F_ENDIAN | FB_IE_F_REVERSIBLE),
    FB_IE_INIT("dataByteCount", CERT_PEN, 502, 8, FB_IE_F_ENDIAN | FB_IE_F_REVERSIBLE),
    FB_IE_INIT("averageInterarrivalTime", CERT_PEN, 503, 8, FB_IE_F_ENDIAN | FB_IE_F_REVERSIBLE),
    FB_IE_INIT("standardDeviationInterarrivalTime", CERT_PEN, 504, 8, FB_IE_F_ENDIAN | FB_IE_F_REVERSIBLE),
    FB_IE_INIT("firstNonEmptyPacketSize", CERT_PEN, 505, 2, FB_IE_F_ENDIAN | FB_IE_F_REVERSIBLE),
    FB_IE_INIT("maxPacketSize", CERT_PEN, 506, 2, FB_IE_F_ENDIAN | FB_IE_F_REVERSIBLE),
    FB_IE_INIT("firstEightNonEmptyPacketDirections", CERT_PEN, 507, 1, FB_IE_F_ENDIAN | FB_IE_F_REVERSIBLE),
    FB_IE_INIT("standardDeviationPayloadLength", CERT_PEN, 508, 2, FB_IE_F_ENDIAN | FB_IE_F_REVERSIBLE),
    FB_IE_INIT("tcpUrgentCount", CERT_PEN, 509, 4, FB_IE_F_ENDIAN|FB_IE_F_REVERSIBLE),
    FB_IE_INIT("largePacketCount", CERT_PEN, 510, 4, FB_IE_F_ENDIAN|FB_IE_F_REVERSIBLE),
    /* end flow stats */
    FB_IE_INIT("httpServerString", CERT_PEN, 110, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("httpUserAgent", CERT_PEN, 111, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("httpGet", CERT_PEN, 112, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("httpConnection", CERT_PEN, 113, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("httpVersion", CERT_PEN, 114, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("httpReferer", CERT_PEN, 115, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("httpLocation", CERT_PEN, 116, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("httpHost", CERT_PEN, 117, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("httpContentLength", CERT_PEN, 118, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("httpAge", CERT_PEN, 119, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("httpAccept", CERT_PEN, 120, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("httpAcceptLanguage", CERT_PEN, 121, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("httpContentType", CERT_PEN, 122, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("httpResponse", CERT_PEN, 123, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("pop3TextMessage", CERT_PEN, 124, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("ircTextMessage", CERT_PEN, 125, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("tftpFilename", CERT_PEN, 126, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("tftpMode", CERT_PEN, 127, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("slpVersion", CERT_PEN, 128, 1, FB_IE_F_ENDIAN),
    FB_IE_INIT("slpMessageType", CERT_PEN, 129, 1, FB_IE_F_ENDIAN),
    FB_IE_INIT("slpString", CERT_PEN, 130, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("ftpReturn", CERT_PEN, 131, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("ftpUser", CERT_PEN, 132, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("ftpPass", CERT_PEN,133, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("ftpType", CERT_PEN,134, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("ftpRespCode", CERT_PEN,135, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("imapCapability", CERT_PEN, 136, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("imapLogin", CERT_PEN, 137, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("imapStartTLS", CERT_PEN, 138, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("imapAuthenticate", CERT_PEN, 139, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("imapCommand", CERT_PEN, 140, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("imapExists", CERT_PEN, 141, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("imapRecent", CERT_PEN, 142, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("rtspURL", CERT_PEN, 143, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("rtspVersion", CERT_PEN, 144, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("rtspReturnCode", CERT_PEN, 145, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("rtspContentLength", CERT_PEN, 146, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("rtspCommand", CERT_PEN, 147, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("rtspContentType", CERT_PEN, 148, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("rtspTransport", CERT_PEN, 149, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("rtspCSeq", CERT_PEN, 150, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("rtspLocation", CERT_PEN, 151, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("rtspPacketsReceived", CERT_PEN, 152, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("rtspUserAgent", CERT_PEN, 153, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("rtspJitter", CERT_PEN, 154, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sipInvite", CERT_PEN, 155, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sipCommand", CERT_PEN, 156, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sipVia", CERT_PEN, 157, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sipMaxForwards", CERT_PEN, 158, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sipAddress", CERT_PEN, 159, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sipContentLength", CERT_PEN, 160, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sipUserAgent", CERT_PEN, 161, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("smtpHello", CERT_PEN, 162, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("smtpFrom", CERT_PEN, 163, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("smtpTo", CERT_PEN, 164, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("smtpContentType", CERT_PEN, 165, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("smtpSubject", CERT_PEN, 166, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("smtpFilename", CERT_PEN, 167, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("smtpContentDisposition", CERT_PEN, 168, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("smtpResponse", CERT_PEN, 169, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("smtpEnhanced", CERT_PEN, 170, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sshVersion", CERT_PEN, 171, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("nntpResponse", CERT_PEN, 172, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("nntpCommand", CERT_PEN, 173, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsQueryResponse", CERT_PEN, 174, 1, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsQRType", CERT_PEN, 175, 2, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsAuthoritative", CERT_PEN, 176, 1, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsNXDomain", CERT_PEN, 177, 1, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsRRSection", CERT_PEN, 178, 1, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsQName", CERT_PEN, 179, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsCName", CERT_PEN, 180, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsMXPreference", CERT_PEN, 181, 2, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsMXExchange", CERT_PEN, 182, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsNSDName", CERT_PEN, 183, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsPTRDName", CERT_PEN, 184, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsTTL", CERT_PEN, 199, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCipher", CERT_PEN, 185, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslClientVersion", CERT_PEN, 186, 1, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslServerCipher", CERT_PEN, 187, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCompressionMethod", CERT_PEN, 188, 1, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertVersion", CERT_PEN, 189, 1, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertSignature", CERT_PEN, 190, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertIssuerCountryName", CERT_PEN, 191, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertIssuerOrgName", CERT_PEN, 192, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertIssuerOrgUnitName", CERT_PEN, 193, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertIssuerZipCode", CERT_PEN, 194, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertIssuerState", CERT_PEN, 195, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertIssuerCommonName", CERT_PEN, 196, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertIssuerLocalityName", CERT_PEN, 197, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertIssuerStreetAddress", CERT_PEN, 198, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertSubCountryName", CERT_PEN, 200, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertSubOrgName", CERT_PEN, 201, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertSubOrgUnitName", CERT_PEN, 202, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertSubZipCode", CERT_PEN, 203, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertSubState", CERT_PEN, 204, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertSubCommonName", CERT_PEN, 205, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertSubLocalityName", CERT_PEN, 206, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertSubStreetAddress", CERT_PEN, 207, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsTXTData", CERT_PEN, 208, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsSOASerial", CERT_PEN, 209, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsSOARefresh", CERT_PEN, 210, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsSOARetry", CERT_PEN, 211, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsSOAExpire", CERT_PEN, 212, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsSOAMinimum", CERT_PEN, 213, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsSOAMName", CERT_PEN, 214, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsSOARName", CERT_PEN, 215, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsSRVPriority", CERT_PEN, 216, 2, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsSRVWeight", CERT_PEN, 217, 2, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsSRVPort", CERT_PEN, 218, 2, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsSRVTarget", CERT_PEN, 219, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("httpCookie", CERT_PEN, 220, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("httpSetCookie", CERT_PEN, 221, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("smtpSize", CERT_PEN, 222, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("mysqlUsername", CERT_PEN, 223, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("mysqlCommandCode", CERT_PEN, 224, 1, FB_IE_F_ENDIAN),
    FB_IE_INIT("mysqlCommandText", CERT_PEN, 225, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsID", CERT_PEN, 226, 2, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsAlgorithm", CERT_PEN, 227, 1, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsKeyTag", CERT_PEN, 228, 2, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsSigner", CERT_PEN, 229, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsSignature", CERT_PEN, 230, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsDigest", CERT_PEN, 231, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsPublicKey", CERT_PEN, 232, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsSalt", CERT_PEN, 233, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsHashData", CERT_PEN, 234, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsIterations", CERT_PEN, 235, 2, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsSignatureExpiration", CERT_PEN, 236, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsSignatureInception", CERT_PEN, 237, 4, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsDigestType", CERT_PEN, 238, 1, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsLabels", CERT_PEN, 239, 1, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsTypeCovered", CERT_PEN, 240, 2, FB_IE_F_ENDIAN),
    FB_IE_INIT("dnsFlags", CERT_PEN, 241, 2, FB_IE_F_ENDIAN),
    FB_IE_INIT("dhcpFingerPrint", CERT_PEN, 242, FB_IE_VARLEN,
               FB_IE_F_REVERSIBLE),
    FB_IE_INIT("dhcpVendorCode", CERT_PEN, 243, FB_IE_VARLEN,
               FB_IE_F_REVERSIBLE),
    FB_IE_INIT("sslCertSerialNumber", CERT_PEN, 244, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslObjectType", CERT_PEN, 245, 1, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslObjectValue", CERT_PEN, 246, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertValidityNotBefore", CERT_PEN, 247, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslCertValidityNotAfter", CERT_PEN, 248, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslPublicKeyAlgorithm", CERT_PEN, 249, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_INIT("sslPublicKeyLength", CERT_PEN, 250, 2, FB_IE_F_ENDIAN),
    FB_IE_INIT("smtpDate", CERT_PEN, 251, FB_IE_VARLEN, FB_IE_F_ENDIAN),
    FB_IE_NULL
};



#endif
