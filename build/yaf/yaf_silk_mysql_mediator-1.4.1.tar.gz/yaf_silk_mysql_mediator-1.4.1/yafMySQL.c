/**
 * @file yafMySQL.c
 *
 * This sets up the database and creates tables for yaf 2 MySQL mediators to use
 *
 *
 * @Author: Emily
 * @Date: 05.3.11

 ** @OPENSOURCE_HEADER_START@
 ** Use of the YAF system and related source code is subject to the terms
 ** of the following licenses:
 **
 ** GNU Public License (GPL) Rights pursuant to Version 2, June 1991
 ** Government Purpose License Rights (GPLR) pursuant to DFARS 252.227.7013
 **
 ** NO WARRANTY
 **
 ** ANY INFORMATION, MATERIALS, SERVICES, INTELLECTUAL PROPERTY OR OTHER
 ** PROPERTY OR RIGHTS GRANTED OR PROVIDED BY CARNEGIE MELLON UNIVERSITY
 ** PURSUANT TO THIS LICENSE (HEREINAFTER THE "DELIVERABLES") ARE ON AN
 ** "AS-IS" BASIS. CARNEGIE MELLON UNIVERSITY MAKES NO WARRANTIES OF ANY
 ** KIND, EITHER EXPRESS OR IMPLIED AS TO ANY MATTER INCLUDING, BUT NOT
 ** LIMITED TO, WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE,
 ** MERCHANTABILITY, INFORMATIONAL CONTENT, NONINFRINGEMENT, OR ERROR-FREE
 ** OPERATION. CARNEGIE MELLON UNIVERSITY SHALL NOT BE LIABLE FOR INDIRECT,
 ** SPECIAL OR CONSEQUENTIAL DAMAGES, SUCH AS LOSS OF PROFITS OR INABILITY
 ** TO USE SAID INTELLECTUAL PROPERTY, UNDER THIS LICENSE, REGARDLESS OF
 ** WHETHER SUCH PARTY WAS AWARE OF THE POSSIBILITY OF SUCH DAMAGES.
 ** LICENSEE AGREES THAT IT WILL NOT MAKE ANY WARRANTY ON BEHALF OF
 ** CARNEGIE MELLON UNIVERSITY, EXPRESS OR IMPLIED, TO ANY PERSON
 ** CONCERNING THE APPLICATION OF OR THE RESULTS TO BE OBTAINED WITH THE
 ** DELIVERABLES UNDER THIS LICENSE.
 **
 ** Licensee hereby agrees to defend, indemnify, and hold harmless Carnegie
 ** Mellon University, its trustees, officers, employees, and agents from
 ** all claims or demands made against them (and any related losses,
 ** expenses, or attorney's fees) arising out of, or relating to Licensee's
 ** and/or its sub licensees' negligent use or willful misuse of or
 ** negligent conduct or willful misconduct regarding the Software,
 ** facilities, or other rights or assistance granted by Carnegie Mellon
 ** University under this License, including, but not limited to, any
 ** claims of product liability, personal injury, death, damage to
 ** property, or violation of any laws or regulations.
 **
 ** Carnegie Mellon University Software Engineering Institute authored
 ** documents are sponsored by the U.S. Department of Defense under
 ** Contract FA8721-05-C-0003. Carnegie Mellon University retains
 ** copyrights in all material produced under this contract. The U.S.
 ** Government retains a non-exclusive, royalty-free license to publish or
 ** reproduce these documents, or allow others to do so, for U.S.
 ** Government purposes only pursuant to the copyright license under the
 ** contract clause at 252.227.7013.
 **
 ** @OPENSOURCE_HEADER_END@
 ** ------------------------------------------------------------------------

 */




#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <my_global.h>
#include <mysql.h>
#include <glib.h>
#include <unistd.h>

static char * md_logfile = NULL;
static char * md_ehost = "localhost";
static char * md_mysql_name = "root";
static char * md_mysql_pass = "";
static char * md_mysql_db = "eflows";
static gboolean insert_index = FALSE;
FILE *mdlog = NULL;

static GOptionEntry md_core_option[] = {
    {"out", 'o', 0, G_OPTION_ARG_STRING, &md_ehost,
     "Select Host/I.P. of MySQL DB [localhost]", "host"},
    {"name", 'n', 0, G_OPTION_ARG_STRING, &md_mysql_name,
     "Specify MySQL user name [root]", "user name"},
    {"pass", 'p', 0, G_OPTION_ARG_STRING, &md_mysql_pass,
     "Specify MySQL password []", "password"},
    {"database", 'd', 0, G_OPTION_ARG_STRING, &md_mysql_db,
     "Name of database to create/use", "database"},
    {"log", 'l', 0, G_OPTION_ARG_STRING, &md_logfile,
     "Filename to log errors and messages", "logfile"},
    {"insert-index", 0, 0, G_OPTION_ARG_NONE, &insert_index,
     "create index in the database of all DPI ID's and "
     "\n\t\t\t\tInformation Element Names", NULL},
    { NULL }
};

/**
 * mdParseOptions
 *
 * parses the command line options
 *
 */
static void mdParseOptions (
    int *argc,
    char **argv[])
{

    GOptionContext *ctx = NULL;
    GError *err = NULL;

    ctx = g_option_context_new(" - yafMySQL Options");

    g_option_context_add_main_entries(ctx, md_core_option, NULL);

    g_option_context_set_help_enabled(ctx, TRUE);

    if (!g_option_context_parse(ctx, argc, argv, &err)) {
        fprintf(stderr, "option parsing failed: %s\n", err->message);
        exit(1);
    }

    if (md_logfile != NULL) {
        mdlog = fopen(md_logfile, "a+");
        if (mdlog == NULL) {
            fprintf(stderr, "Can not open log file %s for logging", md_logfile);
            exit(1);
        }
    } else {
        mdlog = stdout;
    }

    g_option_context_free(ctx);
}


int main (int argc, char *argv[]) {

    MYSQL *conn;
    int i;
    char query[400];
    char cwd[1024];

    mdParseOptions(&argc, &argv);

    conn = mysql_init(NULL);
    if (conn == NULL) {
        fprintf(stderr, "Error Initializing Connection %u: %s\n", mysql_errno(conn),
               mysql_error(conn));
        exit(1);
    }

    if (mysql_real_connect(conn, md_ehost, md_mysql_name, md_mysql_pass, NULL,
                           0, NULL, 0) == NULL)
    {
        fprintf(stderr, "Error Connecting %u: %s\n", mysql_errno(conn),
               mysql_error(conn));
        exit(1);
    }

    sprintf(query, "create database %s", md_mysql_db);
    if (mysql_query(conn, query)) {
        fprintf(mdlog, "Error %u: %s\n", mysql_errno(conn), mysql_error(conn));
    }

    sprintf(query, "use %s", md_mysql_db);
    if (mysql_query(conn, query)) {
        fprintf(stderr, "Error %u: %s\n", mysql_errno(conn), mysql_error(conn));
        exit(1);
    }

    if ( mysql_query(conn, "CREATE TABLE flows(id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY, srcip4 INT unsigned, dstip4 INT unsigned, srcport MEDIUMINT unsigned, dstport MEDIUMINT unsigned, protocol TINYINT unsigned, vlan mediumint unsigned, srcip6 BINARY(16), dstip6 binary(16), flowStartMilliseconds DATETIME, flowEndMilliseconds DATETIME, octetTotalCount bigint unsigned, reverseOctetTotalCount bigint unsigned, packetTotalCount bigint unsigned, reversePacketTotalCount bigint unsigned, silkAppLabel mediumint unsigned, flowEndReason tinyint unsigned, ObservationDomain int unsigned, flowAttributes MEDIUMINT, reverseFlowAttributes MEDIUMINT, ingressInterface MEDIUMINT, egressInterface MEDIUMINT)")) {
        fprintf(mdlog, "Error creating flow table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "Flow Table Created\n");
    }

    if (mysql_query(conn, "create table tcp(id BIGINT PRIMARY KEY, tcpSequenceNumber INT UNSIGNED, reverseTcpSequenceNumber INT UNSIGNED, initialTCPFlags VARCHAR(10), reverseInitialTCPFlags VARCHAR(10), unionTCPFlags VARCHAR(10), reverseUnionTCPFlags VARCHAR(10))")) {
        fprintf(mdlog, "Error creating TCP Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "TCP Table Created\n");
    }

    if (mysql_query(conn, "create table p0f( id BIGINT PRIMARY KEY, osName VARCHAR(100), osVersion VARCHAR(50), osFingerPrint VARCHAR(50), reverseOsName VARCHAR(100), reverseOsVersion VARCHAR(50), reverseOsFingerPrint VARCHAR(50))")) {
        fprintf(mdlog, "Error creating p0f Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "p0f Table Created\n");
    }

    if (mysql_query(conn, "create table tftp(id BIGINT PRIMARY KEY, tftpFilename VARCHAR(50),tftpMode VARCHAR(25))")) {
        fprintf(mdlog, "Error creating TFTP Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "TFTP Table Created\n");
    }

    if ( mysql_query(conn, "create table irc(id BIGINT NOT NULL, listType INT NOT NULL, listTypeValue VARCHAR(150) NOT NULL)")) {
        fprintf(mdlog, "Error creating IRC Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "IRC Table Created\n");
    }

    if (mysql_query(conn, "create table pop3(id BIGINT NOT NULL, listType INT NOT NULL, listTypeValue VARCHAR(150) NOT NULL)")) {
        fprintf(mdlog, "Error creating POP3 Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "POP3 Table Created\n");
    }

    if (mysql_query(conn, "create table slp(id BIGINT NOT NULL, slpVersion TINYINT UNSIGNED, slpMessageType TINYINT UNSIGNED, listType INT, listTypeValue VARCHAR(150))")) {
        fprintf(mdlog, "Error creating SLP Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "SLP Table Created\n");
    }

    if (mysql_query(conn, "create table http(id BIGINT NOT NULL, listType INT NOT NULL, listTypeValue VARCHAR(150) NOT NULL)")) {
        fprintf(mdlog, "Error creating HTTP Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "HTTP Table Created\n");
    }

    if (mysql_query(conn, "create table nntp(id BIGINT NOT NULL, listType INT NOT NULL, listTypeValue VARCHAR(150) NOT NULL)")) {
        fprintf(mdlog, "Error creating NNTP Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "NNTP Table Created\n");
    }

    if(mysql_query(conn, "create table ftp(id BIGINT NOT NULL, listType INT NOT NULL, listTypeValue VARCHAR(150) NOT NULL)")) {
        fprintf(mdlog, "Error creating FTP Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "FTP Table Created\n");
    }

    if(mysql_query(conn, "create table ssh(id BIGINT NOT NULL, listType INT NOT NULL, listTypeValue VARCHAR(150) NOT NULL)")) {
        fprintf(mdlog, "Error creating SSH Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "SSH Table Created\n");
    }

    if (mysql_query(conn, "create table smtp(id BIGINT NOT NULL, listType INT NOT NULL, listTypeValue VARCHAR(150) NOT NULL)")) {
        fprintf(mdlog, "Error creating SMTP Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "SMTP Table Created\n");
    }

    if (mysql_query(conn, "create table sip(id BIGINT NOT NULL, listType INT NOT NULL, listTypeValue VARCHAR(150) NOT NULL)")) {
        fprintf(mdlog, "Error creating SIP Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "SIP Table Created\n");
    }

    if (mysql_query(conn, "create table rtsp(id BIGINT NOT NULL, listType INT NOT NULL, listTypeValue VARCHAR(150) NOT NULL)")) {
        fprintf(mdlog, "Error creating RTSP Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "RTSP Table Created\n");
    }

    if (mysql_query(conn, "create table imap(id BIGINT NOT NULL, listType INT NOT NULL, listTypeValue VARCHAR(150) NOT NULL)")) {
        fprintf(mdlog, "Error creating IMAP Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "IMAP Table Created\n");
    }

    if (mysql_query(conn, "create table dns(id BIGINT NOT NULL, tid MEDIUMINT UNSIGNED, qr TINYINT UNSIGNED, type MEDIUMINT UNSIGNED, auth TINYINT UNSIGNED, nx TINYINT UNSIGNED, section TINYINT unsigned, ttl INT unsigned, rrname VARCHAR(256), rrval VARCHAR(256))")) {
        fprintf(mdlog, "Error creating DNS Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "DNS Table Created\n");
    }

    if (mysql_query(conn, "create table tls(id BIGINT NOT NULL, ie MEDIUMINT UNSIGNED, cert_no TINYINT unsigned, data VARCHAR(500))")) {
        fprintf(mdlog, "Error creating TLS Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "TLS Table Created\n");
    }

    /* OLD YAF */
    /*    if (mysql_query(conn, "create table ssl_tls(id BIGINT NOT NULL, serverCipher BIGINT UNSIGNED, clientVersion TINYINT UNSIGNED, compressionMethod TINYINT UNSIGNED)")) {
        fprintf(mdlog, "Error creating SSL/TLS Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "SSL/TLS Table Created\n");
    }

    if (mysql_query(conn, "create table sslcert(id BIGINT NOT NULL, signature VARCHAR(50), certVersion TINYINT UNSIGNED, certChain TINYINT UNSIGNED, IssuerCountryName VARCHAR(10), IssuerOrgName VARCHAR(100), IssuerOrgUnitName VARCHAR(100), IssuerZipCode VARCHAR(10), IssuerState VARCHAR(10), IssuerCommonName VARCHAR(100), IssuerLocalityName VARCHAR(100), IssuerStreetAddress VARCHAR(100), subjectCountryName VARCHAR(10), subjectOrgName VARCHAR(100), subjectOrgUnitName VARCHAR(100), subjectZipCode VARCHAR(10), subjectState VARCHAR(10), subjectCommonName VARCHAR(100), subjectLocalityName VARCHAR(100), subjectStreetAddress VARCHAR(100))")) {
        fprintf(mdlog, "Error creating SSL Certificate Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "SSL Certificate Table Created\n");
    }
    */

    if (mysql_query(conn, "create table mysql(id BIGINT NOT NULL, username VARCHAR(75), commandText VARCHAR(250), commandCode INT)")) {
        fprintf(mdlog, "Error creating MySQL Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "MySQL Table Created\n");
    }

    if (mysql_query(conn, "create table dhcp(id BIGINT NOT NULL, os VARCHAR(250), vc VARCHAR(250), ros VARCHAR(250), rvc VARCHAR(250))")) {
        fprintf(mdlog, "Error creating DHCP Table: %s\n", mysql_error(conn));
    } else {
        fprintf(mdlog, "DHCP Table Created\n");
    }

    if (mysql_query(conn,"CREATE TABLE flowstats(id BIGINT unsigned,"
                    "tcpurg BIGINT unsigned, smallpkt BIGINT unsigned,"
                    "largepktct BIGINT unsigned, nonempty BIGINT unsigned,datalen BIGINT unsigned,"
                    "avgitime BIGINT unsigned,firstpktlen INT "
                    "unsigned, maxpktsize "
                    "INT unsigned, firsteight SMALLINT unsigned, "
                    "stddevlen BIGINT unsigned, stddevtime BIGINT "
                    "unsigned, revtcpurg BIGINT unsigned, revsmallpkt "
                    "BIGINT unsigned, revnonempty BIGINT unsigned, "
                    "revdatalen BIGINT unsigned, revavgitime BIGINT "
                    "unsigned, revfirstpktlen INT unsigned, "
                    "revlargepktct BIGINT unsigned, revmaxpktsize INT "
                    "unsigned, revstddevlen BIGINT unsigned, "
                    "revstddevtime BIGINT unsigned)"))
    {
        fprintf(mdlog, "Error creating flow statistics table: %s\n",
                mysql_error(conn));
    } else {
        fprintf(mdlog, "Successfully created Flow Statistics Table.\n");
    }

    if (insert_index) {
        if (mysql_query(conn, "create table dpi_index(id BIGINT NOT NULL, name VARCHAR(75))")) {
            fprintf(mdlog, "Error creating Index Table: %s\n",
                    mysql_error(conn));
        } else {
            fprintf(mdlog, "DPI Index Table Created\n");
        }

        if (getcwd(cwd, sizeof(cwd)) != NULL) {
            sprintf(query, "LOAD DATA LOCAL INFILE '%s/index.txt' INTO TABLE dpi_index FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n'", cwd);
            if (mysql_query(conn, query)) {
                fprintf(mdlog, "Error Importing Index Rows %s\n",
                        mysql_error(conn));
            } else {
                fprintf(mdlog, "Index Import Successful.  See index table\n");
            }
        } else {
            fprintf(mdlog, "Can't get Current Working Directory to find "
                    "index.txt\n");
        }

    }


    fprintf(mdlog, "Done!\n");
    mysql_close(conn);
    if (mdlog) {
        fclose(mdlog);
    }
}
