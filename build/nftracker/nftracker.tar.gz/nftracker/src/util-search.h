int init_sigs (void);
int add_sig_file (signature *sig);
int del_all_sigs_file (void);
int add_sig_pdf(void);
int add_sig_zip(void);
int add_sig_html(void);
int add_sig_doc(void);
int add_sig_exe(void);
int add_sig_deb(void);
