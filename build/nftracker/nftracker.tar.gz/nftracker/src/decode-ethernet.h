void prepare_eth (packetinfo *pi);

