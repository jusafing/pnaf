void prepare_udp (packetinfo *pi);
void parse_udp (packetinfo *pi);
void udp_guess_direction(packetinfo *pi);
