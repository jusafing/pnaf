void log_files_csv (packetinfo *pi, bstring filetype);
