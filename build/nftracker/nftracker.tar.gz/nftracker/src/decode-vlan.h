void check_vlan (packetinfo *pi);
