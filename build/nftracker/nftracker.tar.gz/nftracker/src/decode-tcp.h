void prepare_tcp (packetinfo *pi);
void parse_tcp (packetinfo *pi);
