void parse_ip6 (packetinfo *pi);
void prepare_ip6ip (packetinfo *pi);
void prepare_ip6 (packetinfo *pi);
