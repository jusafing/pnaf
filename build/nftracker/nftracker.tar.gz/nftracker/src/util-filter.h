inline int filter_packet(const int af, void *ip);
