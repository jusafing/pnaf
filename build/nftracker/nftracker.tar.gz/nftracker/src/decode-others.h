void prepare_other (packetinfo *pi);
void parse_other (packetinfo *pi);
