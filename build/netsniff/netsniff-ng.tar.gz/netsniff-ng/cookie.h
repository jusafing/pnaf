#ifndef COOKIE_H
#define COOKIE_H

extern void to_std_log(FILE **fp);

#endif /* COOKIE_H */
